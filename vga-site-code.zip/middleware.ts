import { NextResponse, type NextRequest } from "next/server";
import { AUTH_COOKIE, gateEnabled, verifyToken } from "@/lib/auth";

/**
 * Staging sign-in gate. Active only when SITE_AUTH_USER/SITE_AUTH_PASS are set (see lib/auth.ts).
 * Runs in the Node.js runtime so it reads the container's environment at request time and can use node:crypto.
 */
export const config = {
  runtime: "nodejs",
  matcher: [
    // everything except: Next internals, the sign-in flow, the liveness probe, robots, fonts, icons, the brand folder
    "/((?!_next/static|_next/image|login|api/login|api/logout|healthz|robots.txt|fonts/|images/brand/|favicon|icon-|apple-touch-icon|manifest.webmanifest|og-default).*)",
  ],
};

export function middleware(req: NextRequest) {
  if (!gateEnabled()) return NextResponse.next();
  if (verifyToken(req.cookies.get(AUTH_COOKIE)?.value)) return NextResponse.next();

  const accept = req.headers.get("accept") || "";
  const wantsPage = req.method === "GET" && accept.includes("text/html");
  if (!wantsPage) {
    return NextResponse.json({ ok: false, message: "Sign in required." }, { status: 401, headers: { "cache-control": "no-store" } });
  }
  const url = req.nextUrl.clone();
  const next = url.pathname + url.search;
  url.pathname = "/login";
  url.search = next && next !== "/" ? `?next=${encodeURIComponent(next)}` : "";
  const res = NextResponse.redirect(url, 307);
  res.headers.set("cache-control", "no-store");
  return res;
}
