# Veteran Gaming Australia — website

Complete rebuild of www.veterangamingaustralia.org.au as a Next.js 15 (App Router) + React 19 + TypeScript + Tailwind CSS site. All content, images, documents and links from the previous Wix site were crawled on 5 September 2026 and migrated into typed data files and Markdown; the design is new and built around the VGA shield logo.

- **Migration review (decisions for VGA):** `docs/MIGRATION-REVIEW.md`
- **QA report (old page → new destination, links, images):** `docs/QA-REPORT.md`
- **Content manifest of the previous site:** `docs/CONTENT-MANIFEST.md`
- **Design system:** `docs/DESIGN-SYSTEM.md`
- **Content management / CMS recommendation:** `docs/CMS-RECOMMENDATION.md`
- **Deployment (NAS + Cloudflare Tunnel):** `docs/DEPLOYMENT.md`

## Structure

```
app/                 routes (App Router): page.tsx per URL, layout.tsx, sitemap.ts, robots.ts, not-found.tsx
  api/forms/[form]/  contact / newsletter / membership submissions (SMTP and/or webhook)
  healthz/           liveness probe
components/          ui/ layout/ home/ programs/ hubs/ events/ community/ gallery/ sponsors/ team/ forms/ esports/ support/
content/news/*.md    posts (news, newsletters, galleries) — front-matter + Markdown
content/privacy-policy.md
data/*.ts            site facts, navigation, redirects, hubs, team, programs, esports, events, sponsors, shop, education, support, stats, about
data/generated/      built by scripts/build-content.mjs (posts.ts, pages.ts) and the image pipeline (images.ts/json)
lib/                 seo (metadata + JSON-LD), markdown renderer, content helpers, forms delivery, utils
public/images/       migrated photography & logos, organised by section; public/docs/ PDFs; public/fonts/ self-hosted fonts
styles → app/globals.css, tailwind.config.ts
tools/harness/       no-registry render/screenshot harness used for QA in the build sandbox (not needed in production)
tools/qa/            migration verifier (writes docs/QA-REPORT.md) and content-manifest generator
```

## Develop

```bash
npm install
cp .env.example .env      # fill in FORMS_* for form delivery
npm run dev               # http://localhost:3000 (runs the content build first)
npm run typecheck
npm run build && npm start
```

`npm run content` regenerates `data/generated/posts.ts` and `pages.ts` from `content/`. Image entries live in `data/generated/images.json` → `images.ts` (key = path under `/public/images` without extension).

## Editing content

See `docs/CMS-RECOMMENDATION.md` for the file-by-file guide. Short version: add a Markdown file to `content/news/` for a post; edit the relevant `data/*.ts` list for hubs, team, events, sponsors, programs, products.

## Forms

`POST /api/forms/{contact|newsletter|membership}` accepts JSON or multipart (membership includes a verification file ≤ 10 MB). Delivery is by SMTP (`FORMS_SMTP_*`) and/or webhook (`FORMS_WEBHOOK_URL`). With neither configured the API returns 503 and the forms show the enquiries email as a fallback. Submissions are never written to disk or logged. A honeypot field and a per-IP rate limit (12 per 10 minutes) protect against bots.

## Staging sign-in gate

Set `SITE_AUTH_USER`, `SITE_AUTH_PASS` and `SITE_AUTH_SECRET` to require a sign-in for the whole site (`middleware.ts`, `app/login`, `app/api/login`). Unset = open site.

## Redirects & SEO

`data/redirects.ts` → `next.config.ts` `redirects()` (301). `app/sitemap.ts` and `app/robots.ts` generate `/sitemap.xml` and `/robots.txt`. Set `SITE_NOINDEX=1` on staging hosts.

## Deploy

`Dockerfile` (multi-stage, standalone output, non-root, healthcheck) + `docker-compose.yml` (image from GHCR, port 8798) + `.github/workflows/build-image.yml` (builds and pushes `ghcr.io/<owner>/vga-site` on push to `main`). Details and the live deployment record are in `docs/DEPLOYMENT.md`.
