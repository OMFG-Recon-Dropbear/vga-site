/** Only ever send people back to a same-site path (shared by the login page and the API route). */
export function safeNext(next: unknown): string {
  return typeof next === "string" && /^\/(?!\/)[^\s]*$/.test(next) && !next.startsWith("/login") && !next.startsWith("/api/") ? next : "/";
}
