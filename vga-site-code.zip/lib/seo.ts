import type { Metadata } from "next";
import { site } from "@/data/site";
import { absoluteUrl } from "./utils";

type MetaInput = {
  title: string;
  description: string;
  path: string;
  image?: string; // absolute or site-relative
  type?: "website" | "article";
  publishedTime?: string;
  modifiedTime?: string;
  noIndex?: boolean;
};

export function buildMetadata(m: MetaInput): Metadata {
  const url = absoluteUrl(m.path);
  const image = absoluteUrl(m.image ?? "/og-default.jpg");
  return {
    title: m.title,
    description: m.description,
    alternates: { canonical: url },
    openGraph: {
      title: m.title,
      description: m.description,
      url,
      siteName: site.name,
      locale: "en_AU",
      type: m.type ?? "website",
      images: [{ url: image, width: 1200, height: 630, alt: m.title }],
      ...(m.type === "article" ? { publishedTime: m.publishedTime, modifiedTime: m.modifiedTime } : {}),
    },
    twitter: { card: "summary_large_image", title: m.title, description: m.description, images: [image] },
    robots: m.noIndex ? { index: false, follow: false } : undefined,
  };
}

/** Organisation schema. Fields limited to what VGA has published. */
export function organizationJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "NGO",
    name: site.name,
    alternateName: site.shortName,
    url: site.url,
    logo: absoluteUrl("/images/brand/vga-logo.png"),
    foundingDate: String(site.founded),
    description: site.description,
    email: site.email,
    areaServed: { "@type": "Country", name: "Australia" },
    nonprofitStatus: "NonprofitType",
    sameAs: Object.values(site.socials),
  };
}

export function websiteJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: site.name,
    url: site.url,
  };
}

export function breadcrumbJsonLd(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: absoluteUrl(it.path),
    })),
  };
}

export function articleJsonLd(a: { title: string; description: string; path: string; image?: string; datePublished: string; dateModified?: string }) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: a.title,
    description: a.description,
    mainEntityOfPage: absoluteUrl(a.path),
    image: a.image ? [absoluteUrl(a.image)] : undefined,
    datePublished: a.datePublished,
    dateModified: a.dateModified ?? a.datePublished,
    author: { "@type": "Organization", name: site.name, url: site.url },
    publisher: { "@type": "Organization", name: site.name, logo: { "@type": "ImageObject", url: absoluteUrl("/images/brand/vga-logo.png") } },
  };
}

export function eventJsonLd(e: { name: string; startDate: string; endDate?: string; location?: string; description: string; path: string; image?: string; online?: boolean }) {
  return {
    "@context": "https://schema.org",
    "@type": "Event",
    name: e.name,
    startDate: e.startDate,
    endDate: e.endDate,
    description: e.description,
    url: absoluteUrl(e.path),
    image: e.image ? [absoluteUrl(e.image)] : undefined,
    eventAttendanceMode: e.online ? "https://schema.org/OnlineEventAttendanceMode" : "https://schema.org/OfflineEventAttendanceMode",
    organizer: { "@type": "Organization", name: site.name, url: site.url },
    location: e.online
      ? { "@type": "VirtualLocation", url: site.socials.discord }
      : e.location
        ? { "@type": "Place", name: e.location, address: e.location }
        : undefined,
  };
}

export function jsonLdScript(data: unknown): string {
  return JSON.stringify(data).replace(/</g, "\\u003c");
}
