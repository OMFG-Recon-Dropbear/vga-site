import { site } from "@/data/site";

/** Join class names, dropping falsy values. */
export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

/** Format an ISO date (YYYY-MM-DD or YYYY-MM) in Australian English. */
export function formatDate(iso: string | undefined, opts: { month?: "short" | "long"; day?: boolean } = {}): string {
  if (!iso) return "";
  const monthOnly = /^\d{4}-\d{2}$/.test(iso);
  const d = new Date(monthOnly ? `${iso}-01T00:00:00` : `${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  const month = opts.month ?? "long";
  const formatter = new Intl.DateTimeFormat("en-AU", {
    year: "numeric",
    month,
    ...(monthOnly || opts.day === false ? {} : { day: "numeric" }),
  });
  return formatter.format(d);
}

export function isoDateTime(iso: string): string {
  return /^\d{4}-\d{2}$/.test(iso) ? `${iso}-01` : iso;
}

export function absoluteUrl(path: string): string {
  if (/^https?:\/\//.test(path)) return path;
  return `${site.url.replace(/\/$/, "")}${path.startsWith("/") ? path : `/${path}`}`;
}

export function isExternal(href: string): boolean {
  return /^https?:\/\//i.test(href) || href.startsWith("mailto:") || href.startsWith("tel:");
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function truncate(text: string, max = 160): string {
  if (text.length <= max) return text;
  const cut = text.slice(0, max);
  return `${cut.slice(0, cut.lastIndexOf(" "))}…`;
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("en-AU").format(n);
}
