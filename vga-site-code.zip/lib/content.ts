import { posts } from "@/data/generated/posts";
import type { Post } from "./content-types";
import { images, type ImageKey } from "@/data/generated/images";

export type { Post };

export const categories = [
  { slug: "news", label: "News", match: "News" },
  { slug: "newsletter", label: "Newsletters", match: "Newsletter" },
  { slug: "galleries", label: "Galleries", match: "Galleries" },
] as const;

export type CategorySlug = (typeof categories)[number]["slug"];

export function allPosts(): Post[] {
  return posts;
}

export function getPost(slug: string): Post | undefined {
  return posts.find((p) => p.slug === slug);
}

export function postsByCategory(slug: CategorySlug): Post[] {
  const cat = categories.find((c) => c.slug === slug);
  if (!cat) return [];
  return posts.filter((p) => p.category === cat.match);
}

export function categorySlug(category: string): CategorySlug {
  return (categories.find((c) => c.match === category)?.slug ?? "news") as CategorySlug;
}

export function latestPosts(n = 3, opts: { excludeGalleries?: boolean } = {}): Post[] {
  return posts.filter((p) => !opts.excludeGalleries || p.category !== "Galleries").slice(0, n);
}

export function relatedPosts(post: Post, n = 3): Post[] {
  const same = posts.filter((p) => p.slug !== post.slug && p.category === post.category);
  const others = posts.filter((p) => p.slug !== post.slug && p.category !== post.category);
  return [...same, ...others].slice(0, n);
}

/** Gallery albums: every "Galleries" post plus the sim-racing screenshots and newsletter photo set. */
export type Album = {
  slug: string;
  title: string;
  date: string;
  location?: string;
  program?: string;
  cover: ImageKey;
  images: ImageKey[];
  postSlug?: string;
  description?: string;
};

export function albums(): Album[] {
  const fromPosts: Album[] = posts
    .filter((p) => p.category === "Galleries" && p.gallery && p.gallery.length)
    .map((p) => ({
      slug: p.gallerySlug ?? p.slug,
      title: p.title === "Other Graphics" ? "Community moments 2025–26" : p.title,
      date: p.date,
      cover: (p.hero ?? p.gallery![0]) as ImageKey,
      images: p.gallery!.filter((k) => k in images) as ImageKey[],
      postSlug: p.slug,
      description: p.excerpt,
      location: albumLocations[p.gallerySlug ?? p.slug],
      program: albumPrograms[p.gallerySlug ?? p.slug],
    }));
  const newsletter = posts.find((p) => p.slug === "vga-may-august-newsletter");
  const extra: Album[] = [
    {
      slug: "may-august-2026",
      title: "May – August 2026",
      date: "2026-08-07",
      cover: "gallery/newsletter-may-aug-2026/07",
      images: (Object.keys(images).filter((k) => k.startsWith("gallery/newsletter-may-aug-2026/")) as ImageKey[]).concat([
        "hubs/hampton-rsl-esports-hub",
        "hubs/defence-base-social-gaming",
        "news/repatriation-commissioner-visit",
        "news/gaming-pc-raffle-2026",
        "news/care-package-delivery-2026",
      ]),
      postSlug: newsletter?.slug,
      description: "Photos from the VGA May–August 2026 newsletter: the five-year volunteer celebration, community events across Australia, new hubs and the Oceania Veteran Esports League.",
      location: "Across Australia",
      program: "Community events",
    },
    {
      slug: "sim-racing",
      title: "Team VGA sim racing",
      date: "2024-12-01",
      cover: "esports/vga-race-car",
      images: (["esports/team-vga-banner", "esports/vga-race-car"] as ImageKey[]).concat(
        Object.keys(images).filter((k) => k.startsWith("esports/sim-racing/")) as ImageKey[]
      ),
      description: "Liveries, rigs and race screenshots from Team VGA's sim racing program.",
      program: "Esports — sim racing",
      location: "Online",
    },
  ];
  return [...fromPosts, ...extra].sort((a, b) => (a.date < b.date ? 1 : -1));
}

const albumLocations: Record<string, string> = {
  "comicon-brisbane-2024": "Brisbane Convention & Exhibition Centre, QLD",
  "queensland-mental-health-week-2023": "Queensland",
};
const albumPrograms: Record<string, string> = {
  "care-packages-2024": "Care packages",
  "comicon-brisbane-2024": "Community events",
  "veteran-health-week-2024": "Community events",
  "queensland-mental-health-week-2023": "Community events",
  "christmas-celebrations-december-2022": "Community events",
  "community-moments": "Community events",
};

export function getAlbum(slug: string): Album | undefined {
  return albums().find((a) => a.slug === slug);
}
