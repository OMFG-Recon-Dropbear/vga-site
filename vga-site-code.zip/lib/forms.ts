import "server-only";
import { site } from "@/data/site";

export type Delivery = {
  form: string;
  subject: string;
  replyTo: string;
  fields: Record<string, string>;
  file?: { filename: string; content: Buffer; contentType: string };
};

/**
 * Delivers a form submission to VGA. Two independent channels, both optional:
 *  - SMTP (FORMS_SMTP_HOST/PORT/USER/PASS, FORMS_TO_EMAIL, FORMS_FROM_EMAIL) — email with the file attached
 *  - Webhook (FORMS_WEBHOOK_URL [+ FORMS_WEBHOOK_SECRET]) — JSON post (file as base64)
 * If neither is configured the API responds 503 and the form shows the email fallback.
 * Nothing is written to disk and submissions are not logged.
 */
export async function deliver(d: Delivery): Promise<{ ok: boolean; message: string; status?: number }> {
  const smtpHost = process.env.FORMS_SMTP_HOST;
  const webhook = process.env.FORMS_WEBHOOK_URL;
  if (!smtpHost && !webhook) {
    return { ok: false, status: 503, message: `Online forms aren’t connected yet. Please email ${site.email} instead.` };
  }
  const errors: string[] = [];
  const text = Object.entries(d.fields)
    .filter(([k]) => k !== "website")
    .map(([k, v]) => `${k}: ${v}`)
    .join("\n");

  if (smtpHost) {
    try {
      const nodemailer = (await import("nodemailer")).default;
      const port = Number(process.env.FORMS_SMTP_PORT ?? 587);
      const transport = nodemailer.createTransport({
        host: smtpHost,
        port,
        secure: port === 465,
        auth: process.env.FORMS_SMTP_USER && process.env.FORMS_SMTP_PASS ? { user: process.env.FORMS_SMTP_USER, pass: process.env.FORMS_SMTP_PASS } : undefined,
      });
      await transport.sendMail({
        from: process.env.FORMS_FROM_EMAIL ?? site.email,
        to: process.env.FORMS_TO_EMAIL ?? site.email,
        replyTo: d.replyTo,
        subject: `[VGA website] ${d.subject}`,
        text: `${d.subject}\n\n${text}\n\n— Sent from the VGA website (${d.form} form)`,
        attachments: d.file ? [{ filename: d.file.filename, content: d.file.content, contentType: d.file.contentType }] : undefined,
      });
    } catch (e) {
      errors.push(`smtp: ${(e as Error).message}`);
    }
  }
  if (webhook) {
    try {
      const res = await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(process.env.FORMS_WEBHOOK_SECRET ? { "X-Form-Secret": process.env.FORMS_WEBHOOK_SECRET } : {}) },
        body: JSON.stringify({
          form: d.form,
          subject: d.subject,
          fields: d.fields,
          file: d.file ? { filename: d.file.filename, contentType: d.file.contentType, base64: d.file.content.toString("base64") } : undefined,
          receivedAt: new Date().toISOString(),
        }),
      });
      if (!res.ok) errors.push(`webhook: HTTP ${res.status}`);
    } catch (e) {
      errors.push(`webhook: ${(e as Error).message}`);
    }
  }
  const channels = (smtpHost ? 1 : 0) + (webhook ? 1 : 0);
  if (errors.length === channels) {
    console.error(`[forms] delivery failed for ${d.form}: ${errors.join("; ")}`);
    return { ok: false, status: 502, message: `We couldn’t deliver your message. Please email ${site.email} instead.` };
  }
  return { ok: true, message: "Delivered" };
}
