export type PostCategory = "News" | "Newsletter" | "Galleries" | string;

export type Attachment = { label: string; href: string };

export type Post = {
  slug: string;
  title: string;
  date: string; // YYYY-MM-DD
  updated?: string;
  category: PostCategory;
  hero?: string; // image key
  excerpt: string;
  sourceUrl?: string;
  gallerySlug?: string;
  gallery?: string[]; // image keys
  attachments?: Attachment[];
  readingTime: number;
  body: string; // markdown
};
