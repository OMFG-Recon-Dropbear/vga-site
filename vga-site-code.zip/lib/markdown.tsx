import React from "react";
import Link from "next/link";
import Image from "next/image";
import { images, type ImageKey } from "@/data/generated/images";
import { isExternal } from "./utils";

/**
 * A deliberately small Markdown renderer (no dependencies) for VGA's editorial content.
 * Supports: # headings (2–4), paragraphs, "- " lists, "1. " lists, > quotes, --- rules,
 * ![alt](image:key) images from the manifest, [text](href) links, **bold**, *italic*, `code`.
 */

type Block =
  | { type: "h"; level: number; text: string }
  | { type: "p"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] }
  | { type: "quote"; text: string }
  | { type: "hr" }
  | { type: "img"; alt: string; src: string };

export function parseMarkdown(md: string): Block[] {
  const lines = md.replace(/\r\n/g, "\n").split("\n");
  const blocks: Block[] = [];
  let i = 0;
  const flushPara = (buf: string[]) => {
    const text = buf.join(" ").trim();
    if (text) blocks.push({ type: "p", text });
  };
  let para: string[] = [];
  while (i < lines.length) {
    const line = lines[i];
    const t = line.trim();
    if (!t) {
      flushPara(para);
      para = [];
      i++;
      continue;
    }
    const h = t.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      flushPara(para); para = [];
      blocks.push({ type: "h", level: Math.min(Math.max(h[1].length, 2), 4), text: h[2] });
      i++; continue;
    }
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(t)) {
      flushPara(para); para = [];
      blocks.push({ type: "hr" });
      i++; continue;
    }
    const img = t.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
    if (img) {
      flushPara(para); para = [];
      blocks.push({ type: "img", alt: img[1], src: img[2] });
      i++; continue;
    }
    if (/^>\s?/.test(t)) {
      flushPara(para); para = [];
      const q: string[] = [];
      while (i < lines.length && /^>\s?/.test(lines[i].trim())) { q.push(lines[i].trim().replace(/^>\s?/, "")); i++; }
      blocks.push({ type: "quote", text: q.join(" ") });
      continue;
    }
    if (/^[-*•]\s+/.test(t)) {
      flushPara(para); para = [];
      const items: string[] = [];
      while (i < lines.length) {
        const lt = lines[i].trim();
        if (/^[-*•]\s+/.test(lt)) { items.push(lt.replace(/^[-*•]\s+/, "")); i++; continue; }
        if (!lt) {
          // allow blank lines between items when the next non-blank line is another item
          let j = i + 1;
          while (j < lines.length && !lines[j].trim()) j++;
          if (j < lines.length && /^[-*•]\s+/.test(lines[j].trim())) { i = j; continue; }
        }
        break;
      }
      blocks.push({ type: "ul", items });
      continue;
    }
    if (/^\d+[.)]\s+/.test(t)) {
      flushPara(para); para = [];
      const items: string[] = [];
      while (i < lines.length) {
        const lt = lines[i].trim();
        if (/^\d+[.)]\s+/.test(lt)) { items.push(lt.replace(/^\d+[.)]\s+/, "")); i++; continue; }
        if (!lt) {
          let j = i + 1;
          while (j < lines.length && !lines[j].trim()) j++;
          if (j < lines.length && /^\d+[.)]\s+/.test(lines[j].trim())) { i = j; continue; }
        }
        break;
      }
      blocks.push({ type: "ol", items });
      continue;
    }
    para.push(t);
    i++;
  }
  flushPara(para);
  return blocks;
}

/** Inline formatting: links, bold, italic, code, bare URLs. */
export function renderInline(text: string, keyPrefix = "i"): React.ReactNode[] {
  const nodes: React.ReactNode[] = [];
  const re = /(\[([^\]]+)\]\(([^)\s]+)\))|(\*\*([^*]+)\*\*)|(\*([^*]+)\*)|(`([^`]+)`)|(https?:\/\/[^\s<)]+)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) nodes.push(text.slice(last, m.index));
    if (m[1]) nodes.push(<MdLink key={`${keyPrefix}${k++}`} href={m[3]}>{m[2]}</MdLink>);
    else if (m[4]) nodes.push(<strong key={`${keyPrefix}${k++}`}>{m[5]}</strong>);
    else if (m[6]) nodes.push(<em key={`${keyPrefix}${k++}`}>{m[7]}</em>);
    else if (m[8]) nodes.push(<code key={`${keyPrefix}${k++}`} className="rounded bg-ink-800 px-1.5 py-0.5 text-[0.9em] text-gold-100">{m[9]}</code>);
    else if (m[10]) nodes.push(<MdLink key={`${keyPrefix}${k++}`} href={m[10]}>{m[10]}</MdLink>);
    last = re.lastIndex;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return nodes;
}

function MdLink({ href, children }: { href: string; children: React.ReactNode }) {
  if (isExternal(href)) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer">
        {children}
      </a>
    );
  }
  return <Link href={href}>{children}</Link>;
}

export function Markdown({ content, className = "prose-vga", baseLevel = 2 }: { content: string; className?: string; baseLevel?: 2 | 3 }) {
  const blocks = parseMarkdown(content);
  // Normalise heading levels so the document outline has no gaps: the levels actually used are ranked and
  // mapped to baseLevel, baseLevel+1, … (e.g. a post written with "##" and "####" renders h2 and h3).
  const used = Array.from(new Set(blocks.filter((b) => b.type === "h").map((b) => (b as { level: number }).level))).sort((a, b) => a - b);
  const levelMap = new Map(used.map((l, i) => [l, Math.min(6, baseLevel + i)]));
  return (
    <div className={className}>
      {blocks.map((b, idx) => {
        switch (b.type) {
          case "h": {
            const Tag = (`h${levelMap.get(b.level) ?? b.level}` as unknown) as "h2";
            return <Tag key={idx}>{renderInline(b.text, `h${idx}`)}</Tag>;
          }
          case "p":
            return <p key={idx}>{renderInline(b.text, `p${idx}`)}</p>;
          case "ul":
            return (
              <ul key={idx}>
                {b.items.map((it, j) => (
                  <li key={j}>{renderInline(it, `l${idx}-${j}`)}</li>
                ))}
              </ul>
            );
          case "ol":
            return (
              <ol key={idx}>
                {b.items.map((it, j) => (
                  <li key={j}>{renderInline(it, `o${idx}-${j}`)}</li>
                ))}
              </ol>
            );
          case "quote":
            return <blockquote key={idx}>{renderInline(b.text, `q${idx}`)}</blockquote>;
          case "hr":
            return <hr key={idx} />;
          case "img": {
            if (b.src.startsWith("image:")) {
              const key = b.src.slice(6) as ImageKey;
              const asset = images[key];
              if (!asset) return null;
              return (
                <figure key={idx}>
                  <Image src={asset.src} width={asset.width} height={asset.height} alt={b.alt || asset.alt} sizes="(min-width: 1024px) 760px, 100vw" className="w-full rounded-md" />
                  {b.alt ? <figcaption>{b.alt}</figcaption> : null}
                </figure>
              );
            }
            // eslint-disable-next-line @next/next/no-img-element
            return <img key={idx} src={b.src} alt={b.alt} loading="lazy" />;
          }
        }
      })}
    </div>
  );
}

/** Plain-text version of a markdown string (for meta descriptions). */
export function markdownToText(md: string): string {
  return md
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/[#>*`_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
