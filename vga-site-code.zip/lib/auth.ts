import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Optional site-wide sign-in gate (used on the staging preview).
 * Enabled only when SITE_AUTH_USER and SITE_AUTH_PASS are set at runtime; production leaves them unset.
 * Sessions are a signed, expiring token in an httpOnly cookie — no server-side storage.
 */
export const AUTH_COOKIE = "vga_access";
const THIRTY_DAYS = 60 * 60 * 24 * 30;

export function gateEnabled(): boolean {
  return Boolean(process.env.SITE_AUTH_USER && process.env.SITE_AUTH_PASS);
}

function secret(): string {
  return process.env.SITE_AUTH_SECRET || `${process.env.SITE_AUTH_USER}:${process.env.SITE_AUTH_PASS}:vga`;
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

function safeEqual(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

export function checkCredentials(user: string, pass: string): boolean {
  if (!gateEnabled()) return false;
  return safeEqual(user.trim(), process.env.SITE_AUTH_USER as string) && safeEqual(pass, process.env.SITE_AUTH_PASS as string);
}

export function issueToken(now = Date.now()): { value: string; maxAge: number } {
  const exp = Math.floor(now / 1000) + THIRTY_DAYS;
  const payload = `${process.env.SITE_AUTH_USER}|${exp}`;
  return { value: `${exp}.${sign(payload)}`, maxAge: THIRTY_DAYS };
}

export function verifyToken(token: string | undefined, now = Date.now()): boolean {
  if (!token || !gateEnabled()) return false;
  const dot = token.indexOf(".");
  if (dot < 1) return false;
  const exp = Number(token.slice(0, dot));
  if (!Number.isFinite(exp) || exp * 1000 < now) return false;
  return safeEqual(token.slice(dot + 1), sign(`${process.env.SITE_AUTH_USER}|${exp}`));
}

export { safeNext } from "./auth-shared";
