import type { Config } from "tailwindcss";

/**
 * VGA design tokens.
 * Colour values are derived from the supplied VGA logo (greyscale figure + shield, muted gold keyline)
 * and the starting palette in the brief. See docs/DESIGN-SYSTEM.md for the rationale and contrast table.
 */
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}", "./data/**/*.{ts,tsx}"],
  theme: {
    container: {
      center: true,
      padding: { DEFAULT: "1.25rem", sm: "1.5rem", lg: "2rem" },
      screens: { "2xl": "1320px" },
    },
    extend: {
      colors: {
        ink: {
          950: "#0B0C0E",
          900: "#151719", // page background
          850: "#1B1E21", // card surface
          800: "#202326", // elevated surface
          700: "#2B2F32", // secondary surface / borders
          600: "#3E4347",
          500: "#5A6065",
          400: "#7C8287",
          300: "#94989B", // muted text (AA on ink-900)
          200: "#B8BBBE",
          100: "#D9DAD8",
          50: "#F1F0EB", // off-white text
        },
        gold: {
          50: "#FAF4D9",
          100: "#F1E7B3",
          200: "#E9D58E", // highlight (from logo)
          300: "#DCC780",
          400: "#D2BB78",
          500: "#C9B172", // primary VGA gold (from logo)
          600: "#B39B5E",
          700: "#9D8754", // deep gold (from logo)
          800: "#7A6941",
          900: "#54482C",
        },
        discord: "#5865F2",
      },
      fontFamily: {
        display: ['"Barlow Condensed"', '"Arial Narrow"', "Impact", "sans-serif"],
        sans: ["Inter", "system-ui", "-apple-system", '"Segoe UI"', "Roboto", "Helvetica", "Arial", "sans-serif"],
        mono: ['"JetBrains Mono"', "ui-monospace", "SFMono-Regular", "Menlo", "Consolas", "monospace"],
      },
      fontSize: {
        "display-xl": ["clamp(3rem, 8vw, 6.5rem)", { lineHeight: "0.95", letterSpacing: "0.01em", fontWeight: "700" }],
        "display-lg": ["clamp(2.5rem, 5.5vw, 4.5rem)", { lineHeight: "0.98", letterSpacing: "0.01em", fontWeight: "700" }],
        "display-md": ["clamp(2rem, 4vw, 3.25rem)", { lineHeight: "1", letterSpacing: "0.01em", fontWeight: "700" }],
        "display-sm": ["clamp(1.5rem, 2.6vw, 2.125rem)", { lineHeight: "1.05", letterSpacing: "0.01em", fontWeight: "600" }],
        eyebrow: ["0.75rem", { lineHeight: "1", letterSpacing: "0.22em", fontWeight: "600" }],
      },
      spacing: {
        18: "4.5rem",
        22: "5.5rem",
        30: "7.5rem",
      },
      borderRadius: {
        DEFAULT: "4px",
        md: "6px",
        lg: "10px",
        xl: "14px",
      },
      boxShadow: {
        card: "0 1px 0 0 rgba(255,255,255,0.03) inset, 0 10px 30px -12px rgba(0,0,0,0.6)",
        lift: "0 24px 48px -20px rgba(0,0,0,0.7), 0 0 0 1px rgba(201,177,114,0.35)",
        glow: "0 0 0 1px rgba(201,177,114,0.5), 0 0 40px -8px rgba(201,177,114,0.35)",
      },
      backgroundImage: {
        "grid-faint":
          "linear-gradient(to right, rgba(255,255,255,0.035) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.035) 1px, transparent 1px)",
        "gold-sheen": "linear-gradient(135deg, #E9D58E 0%, #C9B172 45%, #9D8754 100%)",
      },
      backgroundSize: {
        grid: "56px 56px",
      },
      transitionTimingFunction: {
        out: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        scan: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100%)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s cubic-bezier(0.22, 1, 0.36, 1) both",
      },
      screens: {
        xs: "430px",
      },
    },
  },
  plugins: [],
};

export default config;
