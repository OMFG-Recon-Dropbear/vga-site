---
title: "Care Package - Clay"
slug: "care-package-clay"
date: "2023-05-29"
category: "News"
hero: "news/care-package-clay"
excerpt: "We received an email off Peter who is a current serving Petty Officer in the Royal Australian Navy about a possible care package for one of his Sailors who had been going through tough times with Mental Health. After hav"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/care-package-clay"
---

We received an email off Peter who is a current serving Petty Officer in the Royal Australian Navy about a possible care package for one of his Sailors who had been going through tough times with Mental Health. After having a chat with Peter we identified Clay already had a PS5 however he was also a big fan of Wolverine. Our team 3d printed an awesome Wolverine Helmet and gave it a custom paint job to match the comics and wrote a kind message of support to help him know he is loved and cared for. We also included a PS5 giftcard and a Merch pack and sent it on it’s way. We received an email from Peter about a week later.

---

Peter: “Good Morning, I just wanted to let you know that Clay has received his welfare package this morning and is very grateful for the support from yourselves at VGA.

Clay is very appreciative of the contents and especially the Wolverine mask, he would like to pass on his thanks for your efforts in support by sending him this package.

I would also like to say a big thank you for helping to support one of my members with this package, it was great to see him smile when he opened it when he is going through a lot with his mental health issues”

---

We love that these care packages help bring a smile and joy to a Veterans face where it may seem like dark days, these care packages as a token in helping light and uplift their spirits in knowing they are loved and cared for. We thank Peter who showed great leadership as Clay’s Chain of Command in recognising the positive aspect this can have and for touching base with us.
