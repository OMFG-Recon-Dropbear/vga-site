---
title: "Care Package - Tyron"
slug: "care-package-tyron"
date: "2023-02-22"
category: "News"
hero: "news/care-package-tyron"
excerpt: "When we receive requests, we learn so much about the different people out there serving/who served, and it's always amazing getting to know more about Veterans. In today's Care Package update, we received a request from "
sourceUrl: "https://www.veterangamingaustralia.org.au/post/care-package-tyron"
---

When we receive requests, we learn so much about the different people out there serving/who served, and it's always amazing getting to know more about Veterans. In today's Care Package update, we received a request from a Petty Officer who works with the initial employment training for aviation technical trades for Army, Navy & Air Force.

---

Tyron: I have spent the previous 3 years in a downward spiral. Deployments, MWD-U and PTSD. All resulted in me being hospitalised for server depression and PTSD in 2022. I use gaming as my selfcare, I get to focus on something else for a hour and forget about the world. Gaming and golf is literally the only hobbies I have what I rely on for escape.

---

Once Tyron had received word of a care package coming his way, his reply was;

WOW, to say I’m grateful is an understatement.

It has been a very difficult couple of years, and things are just starting to turn around for me.

I’m very excited I have found VGA, and look forward to engaging and meeting everyone on discord.

We love helping Veterans and these care packages help our most regional Veterans to connect and find a like minded community within Veteran Gaming Australia. We look forward to having plenty of fun, laughs & banter together with Tyron.
