---
title: "Our Team At Air Space and Power Centre"
slug: "our-team-at-air-space-and-power-centre"
date: "2023-10-31"
category: "News"
hero: "news/air-space-power-centre"
excerpt: "Our ACT team brought a great event to the Air Space and Power Centre, with a focus on enhancing mental health mindsets with relaxation, creativity, mindfulness and discussions with geek cultures in support. Plenty of ama"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/our-team-at-air-space-and-power-centre"
---

Our ACT team brought a great event to the Air Space and Power Centre, with a focus on enhancing mental health mindsets with relaxation, creativity, mindfulness and discussions with geek cultures in support. Plenty of amazing Miniature Figurine Painting was conducted with the introduction and advancement of techniques and how it can assist wellbeing as a mindfulness activity.

With plenty of up-and-coming Picassos in the Miniature Figurine Painting scene, we loved bringing a geek culture mindfulness activity to the workspace of future Space Exploration.
