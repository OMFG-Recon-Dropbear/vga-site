---
title: "Care Package - Patrick"
slug: "care-package-patrick"
date: "2023-03-07"
category: "News"
hero: "news/care-package-patrick"
excerpt: "We love helping Veterans connect and find the social connections, we recently had a care package request from Patrick who has been with the community for some time and gone through some significant Mental Health challeng"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/care-package-patrick"
---

We love helping Veterans connect and find the social connections, we recently had a care package request from Patrick who has been with the community for some time and gone through some significant Mental Health challenges.

---

Patrick: I’ve been dealing with mental health issues for about 6 months prior to my discharge. Since leaving the ADF it's been a struggle. Just as I feel like I’m getting back on my feet i get kicked back to the ground. Bills have been piling up rent is overdue and I’ve been unable to secure meaningful employment of any kind. Receiving a care package would honestly give me a little hope that everything will be ok. It will give me a healthy outlet instead of being constantly in my own head.

---

![](image:news/care-package-patrick-contents)

Once Patrick had received word of a care package coming his way, his reply was;

WOW, your sending me a care package?

This means the absolute world to me right now.

We love helping Veterans and know this will go a long way in helping light that spark moving forward.
