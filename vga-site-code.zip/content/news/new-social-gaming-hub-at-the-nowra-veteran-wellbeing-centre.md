---
title: "New Social Gaming Hub at the Nowra Veteran Wellbeing Centre"
slug: "new-social-gaming-hub-at-the-nowra-veteran-wellbeing-centre"
date: "2023-08-17"
category: "News"
hero: "hubs/nowra-hub-meeting"
excerpt: "**We are proud to be bringing in a new Social Gaming Hub at the Nowra Veteran Wellbeing Centre.**"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/new-social-gaming-hub-at-the-nowra-veteran-wellbeing-centre"
---

**We are proud to be bringing in a new Social Gaming Hub at the Nowra Veteran Wellbeing Centre.**

Earlier last month we sat in with Brodie and Jason from the RSL Lifecare Nowra Veteran Wellbeing Centre who were looking to bring a similar concept to the Gaming Hub we had installed at the Riverina Veteran Wellbeing Centre earlier in the year. After a quick chat we could see the passion and enthusiasm Brodie, Jason and the Team at the Centre have towards Veteran & Families health & wellbeing. While Veteran Wellbeing Centres are often helping with the wellbeing, advocacy, education & employment services, this new hub will add a new level of fun, social interaction & family engagement.

Nowra Veteran Wellbeing Centre over the next couple weeks will have a new VGA Social Gaming Hub setup which includes; Xbox Series S, 2 years of Game Pass Ultimate, [Logitech G](https://www.facebook.com/LogitechG.NO)920 Steering Wheel/Pedals (from our kind Sponsors: Logitech G ), 4 x Controllers, Gaming Headset, Miniature figurines, Paint Brushes & accessories.

We look forward to the fun socials, activities and events that will be had around this hub.
