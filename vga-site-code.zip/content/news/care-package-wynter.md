---
title: "Care Package - Wynter"
slug: "care-package-wynter"
date: "2023-06-29"
category: "News"
hero: "news/care-package-wynter"
excerpt: "When we receive requests, we learn so much about the different people out there serving/who served, and it's always amazing getting to know more about Veterans. In today's Care Package update, we received a request from "
sourceUrl: "https://www.veterangamingaustralia.org.au/post/care-package-wynter"
---

When we receive requests, we learn so much about the different people out there serving/who served, and it's always amazing getting to know more about Veterans. In today's Care Package update, we received a request from Wynter a Veteran who served in the Army who has been going through financial hardships while suffering from mental health.

---

Wynter : “I'm just wondering if I could get any help in fixing my gaming laptop it's 8yrs old and is dying but it's all I got atm...I've tried tech repair myself but I belive the 2 hdds inside are dying...plus think the CPU needs to be cleaned and new thermal paste...let alone a good internal clean out plus a new battery....I've done what I could to look after it...I tried to get quotes from tech stores and pc repairers in WA as the warranty has expired plus I don't want to send to East Coast back the company MSI as it not only coast me more but sending it back and fourth run the risk of it being damaged...I know it maybe a big ask it's the thing that keeps me occupied considering I'm going through medical treatments...which I can't work atm till the drs clear me...”

---

Arc Up Energy donated a 1 year old Gaming Laptop they weren’t using and with this we sent it to Wynter who was very appreciative of the care package as it allowed him to continue gaming with mates and regular chats and discussions within the Veteran Gaming Australia Discord.

We love helping Veterans and these care packages can help our most regional Veterans to connect and find a like minded community within Veteran Gaming Australia. We know times can be tough and we will do our best to assist any and all Veterans.
