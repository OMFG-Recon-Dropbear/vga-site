---
title: "VGA MAY-AUGUST NEWSLETTER"
slug: "vga-may-august-newsletter"
date: "2026-08-07"
category: "Newsletter"
hero: "news/darwin-history-tour"
excerpt: "During May, Veteran Gaming Australia sent a brand-new Xbox console package to the winner of the 9–12 years category of the National ANZAC Day Colouring Competition."
sourceUrl: "https://www.veterangamingaustralia.org.au/post/vga-may-august-newsletter"
---

#### Activities, Events, Advocacy & Community Updates

#### MAY 2026

#### National ANZAC Day Colouring Competition – Xbox Prize

During May, Veteran Gaming Australia sent a brand-new Xbox console package to the winner of the 9–12 years category of the National ANZAC Day Colouring Competition.

The competition received more than 580 entries, making it fantastic to see so many young Australians getting involved.

VGA was proud to support a great initiative that engages younger generations with ANZAC Day

while also giving one young winner a very exciting package to enjoy.

Key points:

- More than 580 competition entries.

- VGA supported the 9–12 years category.

- New Xbox console package sent to the winning entrant.

- Great opportunity to support engagement of younger Australians with ANZAC Day.

![](image:news/anzac-colouring-competition)

#### Advocacy – Proposed $5,000 Annual Allied Health Cap

During May, VGA CEO Sam Harris reviewed the proposed changes to Veteran allied health funding expected to commence from 1 July 2027.

The proposed framework includes a $5,000 annual cap for Veteran Card holders, with provisions for additional support where there is a "valid clinical need".

VGA raised concerns about how the framework may affect Veterans living with chronic and permanent service-related conditions who rely on allied health treatment as ongoing preventative and maintenance care.

These concerns were raised directly with Minister Matt Keogh and Luke Gosling OAM MP.

**Statement from VGA CEO Sam Harris:**

“As CEO, I’ve been reviewing the proposed changes to Veteran allied health funding due to commence from 1 July 2027, including the introduction of a $5,000 annual cap for Veteran Card holders with provisions for additional support where there is a ‘valid clinical need.’

While the intent around flexibility and sustainability is understood, there are important questions being raised across the Veteran and Veteran family community that need clearer answers.

In particular, how will this framework support Veterans living with chronic and permanent service-related conditions such as PTSD, complex pain, traumatic injury, neurological conditions, and long-term physical impairments?

Current messaging refers to additional support during acute situations and post-surgical rehabilitation. However, many Veterans rely on ongoing allied health care as long-term, preventative, and maintenance treatment.

A major concern is how the ‘valid clinical need’ mechanism will operate for lifelong conditions requiring continuous care and whether preventative care will remain fully supported without delay or deterioration in health outcomes.”

#### Aussie Frontline Reload – Supporting Veterans & Families

VGA booked a table for eight Veterans and Veteran Family members to attend the Aussie Frontline Reload event.

The event provided an opportunity for members of our community to hear from speakers, connect with one another and explore discussions around Veteran health, resilience and wellbeing.

Feedback from those attending included:

- “Each speaker was excellent and the Hills Convention Centre was a good place to connect with each other.”

- Dr Dan Pronk's presentations were highlighted multiple times for their practical and physiological insights into stress, trauma and resilience.

- The event also generated some fantastic conversations around esports, gaming and VR technologies within the Veteran space.

#### 30 May – VGA Five-Year Volunteer Celebration

On 30 May, we held a slightly belated volunteer celebration recognising five years of Veteran Gaming Australia and five years of community and connection.

It wouldn't be a VGA celebration without gaming involved, so naturally the celebration was held surrounded by plenty of retro arcade machines.

The event provided an opportunity to recognise the incredible contribution of our volunteers who continue to give their time to supporting Veterans and Veteran Families across Australia.

VGA remains proudly 100% volunteer run and led.

![](image:gallery/newsletter-may-aug-2026/02)

![](image:gallery/newsletter-may-aug-2026/03)

![](image:gallery/newsletter-may-aug-2026/04)

![](image:gallery/newsletter-may-aug-2026/05)

#### MAY–JULY 2026

#### Community Events Across Australia

Throughout May, June and July, VGA team members were busy across Australia as stallholders, event hosts, participants and supporters of Defence, Veteran and Veteran Family activities.

Our teams supported everything from ADF transition seminars and Invictus Australia sporting activities through to family days, comedy shows, sporting events and our own social activities.

A snapshot included:

- Invictus Australia WA Sports Expo

- Adelaide ADF Transition Seminar

- South Australian Partners of Veterans Association of Australia activities

- Veterans’ Families Day celebrations

- Social events and tickets to Jarryd Goundrey comedy shows

- Aussie Frontline Reload

- NT History of Darwin Tour

- QLD NRL Broncos Game

- Northern Adelaide Veterans and Family Wellbeing Hub Esports Come and Try Day

- Darwin Ice Skating

- 6th Engineer Support Regiment Family Day

One standout social activity was our Darwin Ice Skating event, which saw around 60 Veterans and Veteran Family members getting together and having fun on the ice.

These activities are all part of VGA's broader focus on creating accessible opportunities for social connection, engagement and community for Veterans and their families.

![](image:gallery/newsletter-may-aug-2026/06)

![](image:gallery/newsletter-may-aug-2026/07)

![](image:gallery/newsletter-may-aug-2026/08)

![](image:gallery/newsletter-may-aug-2026/09)

![](image:gallery/newsletter-may-aug-2026/10)

![](image:community/sa-family-day)

![](image:gallery/newsletter-may-aug-2026/12)

![](image:gallery/newsletter-may-aug-2026/13)

#### Consultative Forums & Veteran Sector Engagement

Throughout May to August, VGA participated in numerous consultative forums and discussions relating to the needs, experiences and wellbeing of Veterans and Veteran Families.

These forums provide VGA with opportunities to share what we are seeing and hearing directly from our community and advocate for contemporary, accessible and sustainable approaches to Veteran and Family wellbeing.

#### JUNE 2026

#### New VGA Esports Hub – Hampton RSL Sub-Branch

During June, VGA established a new Esports Hub at the Hampton RSL Sub-Branch.

The hub provides another location where Veterans and Veteran Families can connect through gaming and esports, helping create new opportunities for social connection, teamwork and engagement.

The newly established Hampton Heroes would later represent the hub in the Oceania Veteran Esports League Rocket League Challenger League Qualifiers on Saturday, 1 August 2026.

![](image:hubs/hampton-rsl-esports-hub)

#### New Social Gaming Opportunities on Defence Bases

VGA continued expanding opportunities for current-serving Defence members to connect through gaming, including new social gaming hubs and equipment supporting personnel on Defence establishments.

This included a new social gaming presence at 1st Regiment as well as gaming support for eight Naval patrol boats heading for operational service .

These initiatives extend VGA's social connection model directly into Defence environments, helping personnel access gaming, recreation and connection wherever their service takes them.

![](image:hubs/defence-base-social-gaming)

#### JUNE–JULY 2026

#### Indigenous Knowledge Centre Championships – Final Competition

VGA wrapped up the final Indigenous Knowledge Centre Championships delivered alongside the Queensland Government's State Library of Queensland through the Digital and You program.

The initiative supported the development of digital skills, esports participation and social connection across remote First Nations Queensland communities.

The program was fully funded by the State Library of Queensland.

The Championships demonstrated how gaming and esports can provide an engaging platform for developing digital skills while creating opportunities for connection between communities across large geographic distances.

The final competition also saw the Vipers representing Cherbourg take the win .

#### JULY 2026

#### Invictus Australia Team Selection Camp – Canberra

During July, VGA CEO Sam Harris and National Esports Manager Mark travelled to Canberra to support the Invictus Australia Team Selection Camp as esports coaches .

The camp provided another opportunity to demonstrate the role esports can play within the broader Defence and Veteran sporting environment.

Beyond competition, esports can help develop communication, teamwork, problem-solving and camaraderie while providing an accessible pathway for people who may face barriers to participating in traditional sporting activities.

#### Submission to the Australian Parliament – RCDVS Implementation Bill

VGA made a formal submission regarding the Defence Legislation Amendment (RCDVS Implementation and Related Measures No. 2) Bill 2026 .

Our submission was provided to the Senate Foreign Affairs, Defence and Trade Legislation Committee as Submission 5 .

The submission formed part of VGA's ongoing engagement with reforms following the Royal Commission into Defence and Veteran Suicide and our commitment to ensuring the experiences of contemporary Veterans and Veteran Families are represented in national discussions.

[https://www.aph.gov.au/Parliamentary_Business/Committees/Senate/Foreign_Affairs_Defence_and_Trade/DefenceRCDVSNo2Bill26/Submissions](https://www.aph.gov.au/Parliamentary_Business/Committees/Senate/Foreign_Affairs_Defence_and_Trade/DefenceRCDVSNo2Bill26/Submissions)

#### Australian Repatriation Commissioner & Queanbeyan Veteran and Family Hub

VGA held visits and discussions with Australian Repatriation Commissioner Kahlil Fegan DSC AM and members of the RSL LifeCare Queanbeyan Veteran and Family Hub team.

Discussions focused on Veteran and Veteran Family wellbeing and the proposed $5,000 allied health funding cap, including the need for greater communication and clarity around how the changes may operate for Veterans requiring long-term and ongoing care.

These conversations form part of VGA's broader effort to ensure the concerns being raised within the Veteran community are communicated to key stakeholders.

![](image:news/repatriation-commissioner-visit)

#### OCEANIA VETERAN ESPORTS LEAGUE

101 Participants Across 33 Teams

The Oceania Veteran Esports League has continued to grow, with an impressive 101 Veterans and Veteran Family members registered across 33 teams for the Rocket League competition.

The league provides a structured competitive environment while maintaining VGA's broader focus on connection, camaraderie, teamwork and community.

Participants span the Defence, Veteran and Veteran Family community, bringing people together through a shared interest in esports.

#### AUGUST 2026

#### 1 August – Challenger League Qualifiers

On Saturday, 1 August, the first Oceania Veteran Esports League Rocket League qualifiers were held to determine the Top 8 teams progressing to the Challenger League Finals.

The competition also saw the Hampton Heroes compete from VGA's newly established Hampton RSL Sub-Branch Esports Hub.

Congratulations to the Top 8:

- 108

- Bottom Gear

- BotSquad

- The Fakers

- Bred

- Rock For Brews

- Goal Diggers

- SkidmarkZ

Thank you to every team and competitor who took part in the qualifying round.

![](image:news/ovel-rocket-league-top-8)

#### 8 August – Premier League Qualifiers

On 8 August 2026, 18 teams will compete for a place in the Top 8 of the Oceania Veteran Esports League Premier League.

The competition continues to provide Veterans and Veteran Families with opportunities to test their skills, communicate as a team, build camaraderie and connect with people from across the Defence and Veteran community.

We wish all competitors the best of luck.

The action will be livestreamed on VGA's official Twitch channel.

Link: [https://twitch.tv/veterangamingaus](https://twitch.tv/veterangamingaus)

#### 3 August – VGA Gaming PC Raffle Launch

Our latest VGA fundraising raffle officially launched on 3 August 2026, with an incredible gaming PC setup generously donated by Campbell's Custom Computers.

The prize package gives one lucky winner the chance to take home a fantastic custom gaming setup while directly supporting VGA's work.

Importantly, 100% of raffle proceeds support VGA's 100% volunteer-run and led community-charity programs for Veterans and Veteran Families.

Raffle: [https://www.raffletix.com.au/newgamingpcraffle2026](https://www.raffletix.com.au/newgamingpcraffle2026)

![](image:news/gaming-pc-raffle-2026)

#### MAY–AUGUST 2026 – THE BIGGER PICTURE

The past few months have been incredibly active for Veteran Gaming Australia.

From sending an Xbox to a young ANZAC Day colouring competition winner and celebrating five years of VGA, through to establishing new esports hubs, supporting Defence family days, delivering social activities, coaching esports at the Invictus Australia Team Selection Camp and seeing more than 100 participants join the Oceania Veteran Esports League.

Our team has also continued representing the voices and experiences of our community through consultative forums, Parliamentary submissions and direct discussions with Veteran-sector leaders and government representatives.

At the same time, our volunteers have continued doing what VGA was established to do — creating opportunities for Veterans and Veteran Families to find connection and community through gaming, esports, geek culture and shared experiences.

None of this happens without our volunteers, partners, supporters and, most importantly, the Veterans and families who continue to participate in and shape our community.

#### DIGITAL SOCIALS & DISCORD COMMUNITY

#### Connection Doesn't Stop When Events Finish

Alongside our physical events, esports competitions and community activities across Australia, VGA continues to consistently deliver our regular Digital Social Game Nights, providing Veterans and Veteran Families with accessible ways to connect from wherever they are.

Our Discord community remains active throughout the week and currently averages approximately 70 hours of voice conversations and more than 1,000 messages every week.

Whether someone wants to jump into a scheduled game night, find others playing their favourite game, have a chat or simply remain connected with the community, our digital platforms continue to provide an important and accessible point of connection.

**Weekly Digital Social Schedule:**

#### Tuesday

- Farming Simulator 25 – 8:00pm AEST | Weekly

#### Wednesday

- Rocket League – 8:00pm AEST | Weekly

- Over the Top – 8:30pm AEST | Weekly

#### Thursday

- Arma Reforger Missions – 7:00pm AEST | Weekly

- F1 – 8:00pm AEST | Weekly

#### Friday

- Ready or Not – 5:00pm AEST | Weekly

- No Man's Sky – 7:30pm AEST | Fortnightly

- Gray Zone Warfare – 8:00pm AEST | Fortnightly

#### Saturday

- Squad / Hell Let Loose – 8:30pm AEST | Rotating

#### Sunday

- Arma Reforger Missions – 3:00pm AEST | Weekly

#### 24/7 VGA Community Game Servers

Connection isn't limited to our scheduled social nights either.

VGA maintains a growing range of 24/7 community game servers, giving Veterans and Veteran Families the ability to jump online, play together and connect with the community at a time that works for them.

Our current community servers include:

- Windrose

- Palworld

- StarRupture

- RuneScape

- ARK: Survival Ascended

- Farming Simulator 25

- Arma Reforger

- Project Zomboid

- EVE Online

- DCS

These gaming servers complement our organised weekly socials and help ensure there are opportunities to connect across different games, interests, schedules and locations.

#### More Than Just Game Nights

Our digital socials and 24/7 gaming communities remain a core part of what VGA does.

They provide regular, low-barrier opportunities for Veterans and Veteran Families to connect, build friendships and enjoy the camaraderie of gaming without geography being a barrier.

With approximately 70 hours spent talking in Discord voice channels and 1,000+ messages exchanged each week, the conversations and connections happening between our scheduled events are just as important as the game nights themselves.

From an organised social night to an impromptu session on one of our community servers, there is almost always an opportunity for someone to jump in and connect.

Sometimes connection can be as simple as pressing “Join Game.”

![](image:community/discord-arma-server)

#### DIRECT VETERAN & FAMILY SUPPORT

#### Hospital Visits – Supporting Veterans During Difficult Times

Since May, VGA volunteers have undertaken eight hospital visits to Veterans, spending time having a chat, checking in and providing some small comforts during what can be an isolating and difficult period.

These visits have included dropping off items such as refreshments and chocolates, but importantly, they are also about simply showing up, having a conversation and making sure Veterans and Families know they aren’t forgotten.

For someone spending days or weeks in hospital, sometimes a familiar face and a conversation can make a meaningful difference.

#### More Than $5,000 in Care Packages Since May

Since May, VGA has also provided more than $5,000 worth of care packages and direct assistance to Veterans and Veteran Families experiencing a range of challenging circumstances.

The support provided has been tailored to the individual or family rather than taking a one-size-fits-all approach.

This has included:

- Gaming PC, Gaming consoles and equipment to help Veterans reconnect, socialise and have something positive to engage with.

- Get Well Soon packages for Veteran Family members experiencing significant health challenges.

- Food vouchers for Veterans struggling to put food on the table.

- Care packages and other practical support for Veterans experiencing difficult periods in their lives.

One recent care package was provided to a Veteran doing it particularly tough, both with their health and with social connection.

The package included gaming equipment that will help give them an opportunity to have some fun, but importantly, also provide another pathway to build connections with others and become involved with the VGA community from home.

This is an important part of why our gaming and digital community exists. For Veterans experiencing health challenges, mobility limitations, geographical isolation or difficult periods in their lives, being able to connect online can provide an accessible pathway back into a community.

![](image:news/care-package-delivery-2026)

#### Support Where It's Needed

Not every Veteran or family needs the same thing.

Sometimes support is a gaming console that helps someone reconnect with others. Sometimes it's a food voucher when putting food on the table has become difficult. Sometimes it's a Get Well Soon package for a family going through a significant health challenge.

And sometimes it's simply visiting someone in hospital, sitting down and having a chat.

Alongside our events, esports, social gaming hubs, digital socials and 24/7 gaming communities, VGA continues to provide this practical and personal support to Veterans and Veteran Families when they need it. Where we may not be able to due to limited financials, we refer and assist them in connecting with the relevant organisations and supports that may be best able to assist.

Email: [enquiries@veterangamingaustralia.org.au](mailto:enquiries@veterangamingaustralia.org.au)

© 2025 Veteran Gaming Australia.

Proudly Designed By [Wicked Web](https://www.wickedweb.digital/)

- [Home](/)

- [About Us](/about-us) [The Team](/our-team)

- [Events](/events)

- [Donate](/donate)

- [Sponsors](/sponsors) [Become A Sponsor](/become-a-sponsor)

- [Become A Member](/become-a-member)

- [Programs](/programs) [Game Servers](/programs/game-servers) [Esports Teams](/) [COD Black Ops 6](/call-of-duty) [SIM Racing](/esports/sim-racing) [OVEL](/esports/ovel) [Gaming Hubs](/gaming-hubs)

- [Shop](/shop)

- News [Education](/education) [Articles](/news) [Photo Gallery](/gallery)

- [Contact Us](/contact)
