---
title: "Chris our State Rep meets up with Stack Up & Chronicle RPG"
slug: "chris-our-state-rep-meets-up-with-stack-up-chronicle-rpg"
date: "2023-08-13"
category: "News"
hero: "news/stack-up-gencon"
excerpt: "Last week Chris our Victoria State Rep was at Gencon in the United States which consisted of 4 days of gaming awesomeness. To say our whole Australian team was all jealous we couldn't be there is an understatement howeve"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/chris-our-state-rep-meets-up-with-stack-up-chronicle-rpg"
---

Last week Chris our Victoria State Rep was at Gencon in the United States which consisted of 4 days of gaming awesomeness. To say our whole Australian team was all jealous we couldn't be there is an understatement however we heard it was amazing.

He sent us a photo of him with Will from Chronicle RPG who are large supporters of our community-charity and we love there amazing dices, brushes and miniature accessories they sell and the support they provide.

Alongside he got to meet Community Manager for Stack Up Chad and fellow Veterans at the event who are doing amazing work in the Veteran welfare and support space utilising video games & geek cultures for Veterans in the US.

It is our aim one day to extend our Air Assault program to include Overseas game events like Gencon, Gamescon and the large US gaming events for once in the lifetime trips.

We look forward to planning some socials together outside the timezone differences and a possible upcoming Coalition/Alliance Cup games tournament.

Check out the great work of Chronicle RPG & Stack Up over at: [https://chroniclecards.shop/](https://chroniclecards.shop/)

[https://www.stackup.org/](https://www.stackup.org/)
