---
title: "2024 Care Packages"
slug: "care-packages"
date: "2024-12-23"
category: "Galleries"
hero: "news/new-lease-of-life-article"
excerpt: "Gaming care packages sent to our Veterans at home and abroad on operations to ensure they can have fun and utilize as a healthy outlet to build or assist in re-building social and emotional connections, decompress & keep"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/care-packages"
gallerySlug: "care-packages-2024"
gallery:
  - "news/new-lease-of-life-article"
  - "programs/care-package-bundle"
  - "gallery/care-packages-2024/03"
  - "gallery/care-packages-2024/04"
  - "gallery/care-packages-2024/05"
  - "gallery/care-packages-2024/06"
  - "gallery/care-packages-2024/07"
  - "gallery/care-packages-2024/08"
  - "gallery/care-packages-2024/09"
  - "gallery/care-packages-2024/10"
  - "gallery/care-packages-2024/11"
---

Gaming care packages sent to our Veterans at home and abroad on operations to ensure they can have fun and utilize as a healthy outlet to build or assist in re-building social and emotional connections, decompress & keep an active mind to prevent operational stress.

Do you know a Veteran who deserves a Care Package?
