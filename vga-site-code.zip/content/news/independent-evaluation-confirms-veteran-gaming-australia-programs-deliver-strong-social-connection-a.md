---
title: "Independent Evaluation Confirms Veteran Gaming Australia Programs Deliver Strong Social Connection and Wellbeing Outcomes"
slug: "independent-evaluation-confirms-veteran-gaming-australia-programs-deliver-strong-social-connection-a"
date: "2026-03-04"
category: "News"
hero: "news/vga-social-event-stadium"
excerpt: "Veteran Gaming Australia (VGA) recently completed an independent external evaluation of its Social Connection Events, STEM Learning and Esports program, funded through the Veteran Wellbeing Grants Program."
sourceUrl: "https://www.veterangamingaustralia.org.au/post/independent-evaluation-confirms-veteran-gaming-australia-programs-deliver-strong-social-connection-a"
---

![](image:news/independent-evaluation-group)

Veteran Gaming Australia (VGA) recently completed an independent external evaluation of its Social Connection Events, STEM Learning and Esports program, funded through the Veteran Wellbeing Grants Program.

The evaluation confirms that VGA’s hybrid model of digital and in-person connection is delivering meaningful improvements in social connection, enjoyment, and wellbeing for Veterans and their families across Australia.

#### Who conducted the evaluation

The evaluation was independently delivered by First Person Consulting, using participant surveys, staff feedback, and delivery data collected across seven states and territories.

This independence is critical — the findings are not self-reported impact claims, but externally validated results.

#### Program reach

- Activities delivered across 7 states and territories

- 17 Social Connection Events evaluated

- 256+ direct event participants

- 9,000 Veterans and 10,000+ Veteran family/community members reached nationally through grant-supported activities

#### Key Outcomes

- 98% of participants rated Social Connection Events as Very or Extremely enjoyable

- 100% of Esports Hub participants reported high enjoyment

- 73% of Esports League participants rated their experience 8–10 out of 10

Importantly, enjoyment was consistent regardless of activity type or location.

#### Social Connection

- Veterans reporting feeling Very or Extremely connected increased from: 18% before events → 68% after events

- Average social connection score increased by +1.0 on a 5-point scale

- 63% felt Very or Extremely confident maintaining connections after the event

This confirms VGA events are not just enjoyable — they actively reduce social isolation.

#### Families matter

Nearly one-third of all qualitative feedback highlighted:

- Family participation

- Children engaging together

- Shared positive experiences across generations

Family inclusion emerged as one of the strongest protective and wellbeing factors.

#### Gaming as a bridge, not a barrier

- Veterans consistently described VGA’s online Discord community as a bridge to real-world connection

- Participants felt more comfortable attending in person after engaging online

- Esports and gaming acted as a low-pressure entry point for socially isolated Veterans

#### Why this matters

This evaluation confirms that:

- Social connection is a measurable, achievable outcome

- Gaming and technology can be protective, not harmful, when delivered safely

- Hybrid models (digital + physical) outperform one-off events

Download the full independent evaluation report at: [VGA Evaluation Report (1).pdf](https://1drv.ms/b/c/509c4084b185b367/IQD0Rs2emGZhTq5nL1ZY8nEAAeM5JmW0UX2fvQ3UqJqliHQ?e=SfRQVB)
