---
title: "Comicon Brisbane 2024"
slug: "comicon-brisbane-2024"
date: "2024-09-13"
category: "Galleries"
hero: "gallery/comicon-2024/cover"
excerpt: "Attending oz comic-con Brisbane 2024!"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/comicon-brisbane-2024"
gallerySlug: "comicon-brisbane-2024"
gallery:
  - "gallery/comicon-2024/cover"
  - "shop/shop-banner"
  - "gallery/comicon-brisbane-2024/02"
  - "gallery/comicon-brisbane-2024/03"
  - "gallery/comicon-brisbane-2024/04"
  - "gallery/comicon-brisbane-2024/05"
  - "gallery/comicon-brisbane-2024/06"
  - "gallery/comicon-brisbane-2024/07"
  - "gallery/comicon-brisbane-2024/08"
  - "gallery/comicon-brisbane-2024/09"
  - "gallery/comicon-brisbane-2024/10"
  - "gallery/comicon-brisbane-2024/11"
  - "gallery/comicon-brisbane-2024/12"
  - "gallery/comicon-brisbane-2024/13"
  - "gallery/comicon-brisbane-2024/14"
  - "gallery/comicon-brisbane-2024/15"
  - "gallery/comicon-brisbane-2024/16"
---

Attending oz comic-con Brisbane 2024!

SEPTEMBER 13 & 14, 2025 | BCEC
