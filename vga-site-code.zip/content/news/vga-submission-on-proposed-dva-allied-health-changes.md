---
title: "VGA Submission on Proposed DVA Allied Health Changes"
slug: "vga-submission-on-proposed-dva-allied-health-changes"
date: "2026-09-01"
category: "News"
hero: "news/vga-submission-dva-allied-health"
excerpt: "Veteran Gaming Australia CEO Samuel Harris has made a written submission to the Department of Veterans’ Affairs (DVA) in response to the proposed changes to allied health arrangements for Veteran Card holders from 1 July"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/vga-submission-on-proposed-dva-allied-health-changes"
attachments:
  - label: "VGA Public Written Submission – DVA Allied Health Arrangements – 1 September 2026 (PDF, 1.1 MB)"
    href: "/docs/vga-written-submission-dva-allied-health-arrangements-2026-09-01.pdf"
---

Veteran Gaming Australia CEO Samuel Harris has made a written submission to the Department of Veterans’ Affairs (DVA) in response to the proposed changes to allied health arrangements for Veteran Card holders from 1 July 2027.

While VGA supports reducing unnecessary administration, the submission raises concerns about the proposed $5,000 annual threshold and the potential for it to become a barrier to clinically necessary treatment.

VGA is also seeking clarification around the proposed SRDP and TPI exemptions, ongoing and lifelong maintenance treatment, the 28-day approval process, and the transition arrangements for existing Treatment Cycles and referrals.

Our CEO Sam also raised concerns about the timing and effectiveness of the consultation process:

> “While it is positive that DVA is undertaking consultation on these proposed changes, I question why this consultation is occurring so late in the process. Meaningful consultation should occur well before significant changes are developed or proposed. While I acknowledge that the consultation process is now taking place, there is a legitimate question now as to whether the feedback provided by Veterans, advocates and other stakeholders will genuinely influence the final arrangements and result in meaningful changes where concerns are identified.”

VGA encourages Veterans, Veteran Families and other stakeholders to review the proposed changes and have their say.

View the consultation and have your say: [Changes for allied health from July 2027 | Department of Veterans’ Affairs](https://www.dva.gov.au/about-us/publications/budgets/budget-2026-27/changes-for-allied-health-from-july-2027?utm_source=chatgpt.com)

#### Read the VGA written submission below.
