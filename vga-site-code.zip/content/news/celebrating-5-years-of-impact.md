---
title: "Celebrating 5 Years of Impact"
slug: "celebrating-5-years-of-impact"
date: "2026-04-30"
category: "News"
hero: "news/celebrating-5-years-of-impact"
excerpt: "We are proud to celebrate 5 years of supporting Veterans and Veteran families across Australia through the power of gaming and geek culture."
sourceUrl: "https://www.veterangamingaustralia.org.au/post/celebrating-5-years-of-impact"
attachments:
  - label: "Veteran Gaming Australia's 5 Years in Action Report (PDF, 22 MB)"
    href: "/docs/vga-5-years-in-the-game-impact-report-2026.pdf"
---

We are proud to celebrate 5 years of supporting Veterans and Veteran families across Australia through the power of gaming and geek culture.

What started as a small, community-driven initiative has grown into a national charity delivering meaningful social connection, wellbeing programs, and opportunities for thousands of Veterans and their families.

Over the past five years, VGA has remained committed to its mission, reducing social isolation and fostering a sense of belonging with gaming and geek culture at our helm.

#### 5 Years at a Glance

- 46,000+ Veterans and family members supported

- 60+ volunteers powering programs across Australia

- Hundreds of events, programs, and digital sessions delivered

- Established both online and in-person community hubs nationwide

This milestone is a reflection of the collective effort of the VGA community. From participants and volunteers, to sponsors and partners, every contribution has played a role in shaping what VGA is today.

Our dedicated volunteer team continues to be the backbone of our organisation, delivering programs and supporting our community day in and day out. We also extend our deep appreciation to our grant providers, sponsors, supporters, and sporting partners, whose ongoing backing allows us to continue expanding our reach and impact.

While we are proud of what has been achieved over the past five years, this milestone is just the beginning. VGA remains focused on continuing to grow, innovate, and provide meaningful support to Veterans and their families into the future.

#### Read Our 5-Year Impact Report

To explore the full journey, stories, and outcomes from the past five years, we invite you to read our “5 Years in the Game” Impact Report below.
