---
title: "Veteran Gaming Australia Disappointed Following Unsuccessful DVA Wellbeing Grant Application"
slug: "veteran-gaming-australia-disappointed-following-unsuccessful-dva-wellbeing-grant-application"
date: "2026-07-29"
category: "News"
hero: "brand/vga-logo-on-dark"
excerpt: "Veteran Gaming Australia is disappointed to confirm that our application for the Department of Veterans' Affairs 2025–26 Veteran Wellbeing Grants Program was unsuccessful."
sourceUrl: "https://www.veterangamingaustralia.org.au/post/veteran-gaming-australia-disappointed-following-unsuccessful-dva-wellbeing-grant-application"
---

Veteran Gaming Australia is disappointed to confirm that our application for the Department of Veterans' Affairs 2025–26 Veteran Wellbeing Grants Program was unsuccessful.

While we congratulate the organisations that received funding, we are naturally disappointed given the rapidly growing demand for our community programs and the significant impact this decision will have on expanding social connection opportunities and our community programs for Australian Veterans and Veteran families.

Over the past 12 months alone, Veteran Gaming Australia has:

- Established 14 new Social Gaming and Esports Hubs across Defence bases, Veteran and Family Hubs, and veteran support organisations.

- Delivered more than 40 family-inclusive, in-person social connection events, with our fastest event reaching full capacity in just 15 minutes.

- Increased digital server capacity two fold whilst also delivering over 200 digital social events over the last 12 months.

- Over 70 hours of voice conversations in our digital servers each week between Veterans and family members.

- Seen our online community exchange more than 1,000 messages every week, strengthening peer support and social connectedness.

Unfortunately, the loss of this funding will significantly impact our ability to continue expanding these initiatives at a time when demand has never been greater.

The need for meaningful social connection within the Veteran community continues to grow. Earlier this year, our CEO, Samuel Harris, was honoured with the Suicide Prevention Australia Award for Priority Populations in recognition of his leadership and Veteran Gaming Australia's work supporting Veteran and Family suicide prevention through innovative community programs.

## CEO Statement

Veteran Gaming Australia CEO Samuel Harris said:

"We are at a critical point where requests for our services continue to increase, making this outcome incredibly disappointing. This funding would have strengthened our face-to-face social connection events, which regularly provide Veterans and Veteran Families with the confidence to reconnect with their communities. We've seen countless examples of Veterans who first engaged with us online before attending an event in person. One veteran recently attended his first social outing in 14 months after building confidence through our digital community.

The decision will also significantly impact our Social Gaming Hub and Esports Hub Retrofit Program, where demand has more than doubled throughout 2026, as well as opportunities to further develop Veteran Esports initiatives across Australia. At the same time, our Oceania Veteran Esports League has attracted 101 registrations, demonstrating the growing demand for Esports.

Independent evaluation conducted earlier this year showed participants reporting they felt Very or Extremely Connected increased from 18% before attending our events to 68% afterwards, while 98% of participants rated our Social Connection Events as Very or Extremely Enjoyable. When the evidence clearly demonstrates positive outcomes, it is difficult to understand why programs delivering measurable improvements in connection and health and wellbeing are unable to secure ongoing support."

These outcomes reinforce what we witness every day.

We see Veterans and Families connect. We see mateships and support networks built. We see communities strengthened through shared experiences and connection.

That is why we remain committed to continuing this work.

## How You Can Help

Support has never been more important.

Whether you're a business looking to partner with an organisation creating measurable impact, an individual able to make a donation, or someone who can help spread awareness of our work, every contribution helps us continue delivering programs that keep Veterans and Families socially connected.

Australia loses an average of six Veterans each month to suicide.

Now is not the time to reduce access to proven community-based wellbeing initiatives. It is a time to invest in the programs that create connection, reduce isolation, and provide veterans and families with places where they genuinely belong.

While this outcome is disappointing, Veteran Gaming Australia remains committed to finding new ways to continue delivering the programs our community relies upon.
