---
title: "A Victoria Point army veteran is sharing his love of gaming with"
slug: "a-victoria-point-army-veteran-is-sharing-his-love-of-gaming-with"
date: "2021-12-07"
category: "News"
hero: "news/playstation-controller"
excerpt: "After growing up on an ostrich farm at Greenbank, 19-year-old Samuel Harris followed in the footsteps of his older brother and enlisted in the Australian Defence Force."
sourceUrl: "https://www.veterangamingaustralia.org.au/post/a-victoria-point-army-veteran-is-sharing-his-love-of-gaming-with"
---

After growing up on an ostrich farm at Greenbank, 19-year-old Samuel Harris followed in the footsteps of his older brother and enlisted in the Australian Defence Force.

Mr Harris said it had been his dream to serve the wider Australian community since he was young, and he did so for 14 years.

In September Mr Harris was medically discharged after breaking his neck and has no feeling in his left arm.

"I used to be very physical and very active, so it takes away a lot when you get injured, either physically or mentally," he said.

- Also read: [How video games could make their way to the Olympic Games](https://www.redlandcitybulletin.com.au/story/4962280/how-video-games-could-make-their-way-to-the-olympic-games/?cs=12)

- Also read: [Video games will improve health of elderly](https://www.redlandcitybulletin.com.au/story/7055628/video-games-will-improve-health-of-elderly/)

In his recovery, Mr Harris reached for the gaming controller and never looked back.

"Gaming was utilised a lot in the ADF. It was a coping mechanism, coming back from trips and playing FIFA, Call of Duty or something else with mates," he said.

"It was an instant stress relief. A fun escape to stay in touch with friends and open up lines of communication."

After gaming helped him maintain connections and recover from injury, Mr Harris created Veteran Gaming Australia in April for current and ex-ADF personnel.

The group has more than 1600 members and is growing quickly, which has allowed the organisation to provide more support avenues for psychological help, physical assistance and housing.

"We're helping veterans make social connections because there's a stigma that once you get out of the army you lose connections," he said.

"There's also that opportunity to open a discussion about mental and physical health, and we find that people are more likely to do this when they are having fun playing a game with their mates.

"We can act as the middleman to put these people who might be struggling in touch with the right people to assist them anywhere in Australia."

The group is also creating opportunities for members to take part in global e-sports competitions.

"The most popular games for us are first-person shooters, which can really help people with PTSD, and role-playing games which keep the mind active and act as a form of escapism."

Mr Harris said his favourite games were first-person shooter games like Call of Duty, and even coached players for e-sports tournaments, but also enjoyed playing Just Dance with his daughters.

"I can't climb a mountain with the girls and do those kinds of physical things I used to, but jumping on Just Dance with them is a great way to have fun and connect with them too," he said.
