---
title: "What We Do During Queensland Mental Health Week"
slug: "what-we-do-during-queensland-mental-health-week"
date: "2023-10-18"
category: "News"
hero: "news/qld-mhw-llama-cover"
excerpt: "Every year we love raising awareness around the importance of Mental Health and how community, healthy gaming and geek cultures can play a part in that. This time of year is World Mental Health Day and our Queensland tea"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/what-we-do-during-queensland-mental-health-week"
---

![](image:news/qld-mhw-llama)

Every year we love raising awareness around the importance of Mental Health and how community, healthy gaming and geek cultures can play a part in that. This time of year is World Mental Health Day and our Queensland team was kept busy learning about holistic farm and Llama farm practices as part of Queensland Mental Health Week.

Bringing Veterans and Families together at a Llama Farm, where they got to learn about animals ranging from Llamas, Camels, Horses alongside feeding and patting them. Everyone had a great day out with an enhancement of social connections, fun, education and mental health wellbeing for the whole family. Previous years we had held Esport Game Centre Days however as we educate and practice holistic healthy gaming for advancement of health and wellbeing as a community for Veterans and their Families. This year was something a little different mixed in which was very well received by all.

It is important to keep your mental health in mind and we love helping be apart of raising the awareness of the importance of mental health.
