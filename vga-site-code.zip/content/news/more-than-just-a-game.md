---
title: "MORE THAN JUST A GAME"
slug: "more-than-just-a-game"
date: "2021-10-23"
updated: "2025-02-07"
category: "News"
hero: "news/more-than-a-game-1"
excerpt: "*By Lani Pauli — 2 June 2021. Republished from RSL Queensland.*"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/more-than-just-a-game"
---

*By Lani Pauli — 2 June 2021. Republished from RSL Queensland.*

Virtual worlds are offering veterans the chance to reconnect with comrades, find community and escape reality, and groups like Veteran Gaming Australia (VGA) are leading the way.

The group was founded by Samuel Harris, an Army Corporal who works in Research, Investigation and Stocktaking as a Supply Chain Specialist, with the support of his founding members Cara Musk and Andrew Dubignon, who are both ex-serving. After launching in April 2021, VGA grew to 600 members in the first month and the numbers are still climbing.

“We want to develop a community around a shared love of gaming for current and ex-serving veterans,” Samuel says.

“Our aim is to improve veteran wellbeing and decrease reasons for isolation, hardship and health issues experienced by members of our community.”

“For veterans that are ex-serving, it has definitely helped with social aspects because when you leave service there’s a big void for social communication and interactions. We feel like VGA gives them an outlet for fun and a sense of belonging.”

## A GAME WAY TO RELAX

“I grew up on an ostrich farm. My brothers and I didn’t get many gaming consoles growing up but when we did, we would use that as a way to relax away from the hard lifestyle of living on a farm,” Samuel says.

“After enlisting and being sent on courses or deployed, playing video games became a way to have fun with my mates and relax with a busy schedule. If you’re going outside the wire, when you come back you literally only feel like two things – a shower and sitting down to play a game or playing with your mates.”

Due to their focus on characters, Samuel largely plays role-playing video games on an Xbox or PC. He says there’s more to playing than just staring at a screen for hours.

“They get your mind involved. If you’re experiencing depression for example, it’s a way to get your mind out of that space and into another character, which can be a great thing.

“A lot of our members find it’s a great way to relax, find a moment of release and escape from the pain they might be feeling in their mind.

“Likewise, there’s a lot of people who are experiencing social isolation – whether it be from COVID or physical limitations and injuries – and playing online in the community is a way they can connect back in and form friendships,” he says.

## MAKING IT OFFICIAL

Formalising the group was driven by Samuel’s desire to find a way to reconnect with his own community, keep mentally active and offer the chance to others in a similar place.

“In the time I’ve served, at least 50 to 80 per cent of the groups on courses or deployment with me would bring some type of gaming console or play a game on their mobile phones. So, it’s something a lot of our mates are already doing.”

The group currently and the online gaming live stream service Twitch, where they can watch other members play and talk with the group.‘meet’ through Discord

“We also have a VGA YouTube where we share tips on exercises that assist your body and mind, like breathing strategies and stretches that can be done while gaming.”

VGA member Will McKeever is a 33-year-old veteran who served in the Army Reserves with the 41st RNSWR.

“I suffered a back injury which resulted in three surgeries and contributed to mental health and addiction issues,” he explains.

“While getting inpatient treatment, I saw Sam’s Facebook post about the group and thought I would have a look. I’ve always enjoyed gaming and particularly in the past eight years it has been one of the only ways throughout my journey that I’m able to shut my mind off and not focus on how much I was struggling.

“I’ve noticed the group is made up of a variety of playing all sorts of games, so it doesn’t matter what you play, you can most likely find someone to jam with. I’m lucky to have found something that works for me and can see how this could help other veterans in a similar place. Having an active mind has been crucial for my rehabilitation.”veterans

## A VETERAN WITH NEW PURPOSE

![](image:news/more-than-a-game-2)

Samuel, who will finish serving in July 2021, has been in the Army for 14 years. He was deployed to the 2018 Gold Coast Commonwealth Games and Victoria Bushfire Assist, and completed two tours in Dubai and Afghanistan.

“Some of the highlights of my time in the Army are the mates that I’ve made – and I’m gaining plenty more through the gaming world, too.

“As I transition from service, I’m working to keep my mind active and develop this community as much as we can.

“We’re all on common ground in the group, so there are no ranks. There’s a lot of stress involved in military life but at the end of the day, if you can sit down on the couch with a mate and play a game of FIFA, that stress is gone in an hour or so.

“Other veterans might bottle those feelings up and that causes all sorts of issues. This is a great way to unwind, destress and help with mental anguish.”

Samuel, who has first-hand experience with physical injuries after serving, says gaming also gives veterans freedoms they may not have in their daily life.

“You can pick up a controller or an adjusted controller if needed, and while you might not be able to go to the gym anymore, you can play without limitations. You can get a sense of physical freedom back for a short time and still feel worthwhile and enjoy something that is purely for fun.

“We also have a team behind the scenes available to help with emotional and social wellbeing for community members who need additional support.

According to Samuel, raising awareness is the group’s main focus at the moment.

“Long term we want to turn it into a not-for-profit and develop a community centre for online gamers and streamers to have a space to play from.

“We’re hoping we can be in a place to register as a not-for-profit organisation by the end of the year.”

Anyone interested in joining [Veteran Gaming Australia](https://www.facebook.com/groups/veterangamingaus) can register via the Veteran Gaming Australia Facebook page.

CREDIT: [https://rslqld.org/News/Latest-News/Veteran-Gaming](https://rslqld.org/News/Latest-News/Veteran-Gaming)
