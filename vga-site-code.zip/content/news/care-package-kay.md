---
title: "Care Package - Kay"
slug: "care-package-kay"
date: "2023-07-17"
category: "News"
hero: "news/care-package-kay"
excerpt: "We received an email nomination for a care package for Kate who was a Chief Petty Officer in the Royal Australian Navy who had been described as one of the most compassionate people always looking out for others while su"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/care-package-kay"
---

We received an email nomination for a care package for Kate who was a Chief Petty Officer in the Royal Australian Navy who had been described as one of the most compassionate people always looking out for others while suffering her own demons with mental health battle. Here is what the nomination had to say.

---

“Kate is a kind person who looks after others first. She is always there with a shoulder to cry on, an ear to listen and arms to hold you up. She doesn't let many people see the mental health issues that she deals with daily. This would help her take some time out and play with her son.”

---

When we advised Kate that she had been nominated for a VGA Care Package and this will be inbound to her over the coming weeks she said

“Good evening! Wow, that is amazing news! Thank you so much for this. I can't believe it!!, This will make a great connection for myself and my son. I can not that you and the team enough.”

We love that this care package will help bring her and her family closer together. We also love her kindness for looking out for her mates and being there always even while fighting her own demons. Know that you have a community for full support and we know this will help bring your family closer.
