---
title: "Seeking Clarification on Proposed DVA Allied Health Cap Arrangements"
slug: "seeking-clarification-on-proposed-dva-allied-health-cap-arrangements"
date: "2026-05-13"
category: "News"
hero: "news/seeking-clarification-dva-cap"
excerpt: "Recently, Veteran Gaming Australia CEO Samuel Harris wrote to The Honourable Matt Keogh MP, seeking clarification regarding the proposed $5,000 annual allied health threshold cap announced as part of recent Federal Budge"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/seeking-clarification-on-proposed-dva-allied-health-cap-arrangements"
attachments:
  - label: "Request for Clarification on Proposed DVA Allied Health Cap Arrangements – 13 May 2026 (PDF, 464 KB)"
    href: "/docs/request-for-clarification-dva-allied-health-cap-2026-05-13.pdf"
---

Recently, Veteran Gaming Australia CEO Samuel Harris wrote to The Honourable Matt Keogh MP, seeking clarification regarding the proposed $5,000 annual allied health threshold cap announced as part of recent Federal Budget measures affecting the Veteran community.

While acknowledging and welcoming the Government’s increased investment into allied health provider fee schedules for Veterans, Mr Harris also raised a number of concerns being discussed throughout the Veteran community regarding how the proposed cap may operate in practice for Veterans with ongoing or complex treatment needs.

The correspondence highlighted several key questions surrounding:

• treatment continuity for Veterans requiring long-term care

• approval pathways once the threshold is reached• expected processing timeframes

• review and appeal mechanisms

• clinical exemption considerations

• and how “valid clinical need” may be assessed under the proposed arrangements.

The letter also respectfully sought clarification regarding consultation undertaken with Veteran health specialists, allied health peak bodies, organisations such as the Royal Australian College of General Practitioners, and Veterans themselves who actively utilise allied health services.

Mr Harris acknowledged the importance of sustainable and accountable healthcare systems while emphasising the importance of transparency, consultation, and ensuring that Veterans with chronic or permanent conditions do not face unintended barriers to accessing ongoing multidisciplinary care.

Additionally, following the letter being sent, Veteran Gaming Australia became aware of reports indicating Government funding had been withdrawn for Invictus Australia. This news is disappointing, and we remain hopeful the Government continues supporting organisations such as Invictus Australia that provide critical services, social connection opportunities, wellbeing initiatives, and recovery pathways for Veterans and Veteran families across Australia.

Veteran Gaming Australia supports constructive engagement and collaborative discussions that strengthen health outcomes, wellbeing outcomes, and continuity of care for Veterans and their families.

Veterans, families, providers, and community members wishing to provide feedback or raise concerns regarding the proposed arrangements are encouraged to engage respectfully and constructively with policymakers, Veteran support organisations, and the broader Veteran health sector to help ensure positive outcomes for the Veteran community moving forward.

View the letter sent below.
