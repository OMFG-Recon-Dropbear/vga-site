---
title: "New Social Gaming Hubs at the Riverina Veteran Wellbeing Centre"
slug: "new-social-gaming-hubs-at-the-riverina-veteran-wellbeing-centre"
date: "2023-02-09"
category: "News"
hero: "hubs/riverina-hub-setup-1"
excerpt: "**We are proud to be bringing in two new Social Gaming Hubs at the Riverina Veteran Wellbeing Centre.**"
sourceUrl: "https://www.veterangamingaustralia.org.au/post/new-social-gaming-hubs-at-the-riverina-veteran-wellbeing-centre"
---

**We are proud to be bringing in two new Social Gaming Hubs at the Riverina Veteran Wellbeing Centre.**

Earlier last month we were hit up by Brian from the RSL Lifecare Riverina Veteran Wellbeing Centre who is a passionate gamer himself in regards to the current activities and support services we offer here at VGA. After a quick chat we could see the passion and enthusiasm Brian and the Team at the Centre have towards Veteran & Families health & wellbeing. While Veteran Wellbeing Centres are often helping with the wellbeing, advocacy, education & employment services, these hubs will add a new level of fun, social interaction & family engagement.

We got to hear from Brian and what he thought of these new Social Gaming Hubs and what they can bring to the Riverina-Wagga Wagga region.

First of all Thank you for touching base with us Brian, as a passionate gamer yourself you would understand the many benefits that digital gaming can bring and we would love to hear more on how this may benefit Veterans & Families at the Riverina-Wagga Wagga region and also a bit more about the services of RSL Lifecare Riverina Veteran Wellbeing Centre.

---

Brian:

“Thank you Samuel and the entire team at VGA. Your generous donation will provide an amazing opportunity to our veteran community. The Social Gaming Hubs are going to help connect the local veteran community throughout the Riverina. The Social Gaming Hubs in the RVWC provide a space and the equipment necessary for veterans and their families to unwind, socialise and even have a moment to themselves.

As you said Sam, I’m a passionate gamer and I know firsthand the positive effects gaming can have. The ability to game and socialise with mates who are

across the country or even overseas, is amazing. In my experience, ‘A gaming day can help keep the black dog at bay’.

The Riverina Veteran Wellbeing Centre is a one stop service provider for Veterans and their families. Located at 240 Baylis Street Wagga Wagga, the Centre hosts multiple services covering a range of needs for Veterans and their families. Services directly provided at the Centre include but are not limited to; Claims advocacy, Wellbeing support, social connection, financial assistance, connections to RSL NSW local Sub-Branches, counselling services provided by Open Arms, Veterans sports programs with Invictus Australia and many other options. The Centre is open Monday to Friday 9am to 5pm and is open to walk-ins and enquiries. The Centre is supported by the greater Veteran Services team of RSL Lifecare to cater to any needs that require additional support. Veterans and family members are always welcome for a coffee and chat, alternatively you can connect with us with your queries at [RiverinaVWC@rsllifecare.org.au](mailto:RiverinaVWC@rsllifecare.org.au) .

![](image:hubs/riverina-hub-setup-2)

These Social Gaming Hubs fall under our ‘Wellbeing support’. I have already had people come through our centre looking for a service just like this, now I am happy to say we can provide this service, thanks to you all at VGA.

Thank you all once again from all of us at the Riverina Veteran Wellbeing Centre. We will keep you all updated with how these Social Gaming Hubs are being utilised and hope to tie our veteran community in with more VGA social nights and event.”

---

We love setting up these social gaming hubs in the areas which can benefit Veterans & Families greatly and we look forward to hearing from you down the track on how much fun & interaction these have bought to the community.

- Samuel Harris (Founder)
