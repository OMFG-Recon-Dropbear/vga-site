export type NavLink = { label: string; href: string; description?: string; external?: boolean };
export type NavGroup = { label: string; href: string; items?: NavLink[]; featured?: { title: string; body: string; href: string; cta: string } };

/** Primary navigation (desktop mega-menu + mobile accordion) */
export const mainNav: NavGroup[] = [
  {
    label: "About",
    href: "/about-us",
    items: [
      { label: "Our Story", href: "/about-us", description: "Who we are, why we exist and what we believe about gaming and connection." },
      { label: "Our Team", href: "/our-team", description: "The volunteers, board, ambassadors and state representatives behind VGA." },
      { label: "Our Impact", href: "/impact", description: "Five years of community, the numbers and the independent evaluation." },
      { label: "News & Advocacy", href: "/news", description: "Updates, newsletters and submissions on behalf of Veterans and families." },
    ],
  },
  {
    label: "Programs",
    href: "/programs",
    items: [
      { label: "Programs Overview", href: "/programs", description: "Everything VGA runs — online and in person." },
      { label: "Gaming Hubs", href: "/gaming-hubs", description: "Social gaming and esports hubs across Australia. Find one near you." },
      { label: "Esports", href: "/esports", description: "Oceania Veteran Esports League, Call of Duty and sim racing." },
      { label: "Game Servers & Digital Socials", href: "/programs/game-servers", description: "24/7 community servers and the weekly social game-night schedule." },
      { label: "Care Packages", href: "/programs/care-packages", description: "Gaming care packages for Veterans doing it tough." },
      { label: "Hospital Loan Program", href: "/programs/hospital-loan-program", description: "Free device loans for Veterans in hospital (QLD, VIC, ACT)." },
      { label: "Air Assault", href: "/programs/air-assault", description: "All-expenses-paid trips to major gaming expos for deserving Veterans." },
    ],
    featured: {
      title: "Is there a VGA hub near you?",
      body: "19 social gaming and esports hubs from Cairns to Adelaide — on Defence bases, in Veteran wellbeing centres and RSLs.",
      href: "/gaming-hubs",
      cta: "Find a hub",
    },
  },
  { label: "Events", href: "/events" },
  {
    label: "Community",
    href: "/news",
    items: [
      { label: "News", href: "/news", description: "The latest from VGA, including newsletters and advocacy." },
      { label: "Education", href: "/education", description: "Healthy gaming, 3D printing and online-safety guides." },
      { label: "Photo Gallery", href: "/gallery", description: "Real photos from real VGA events and programs." },
      { label: "Join the Discord", href: "https://discord.gg/veterangamingaustralia", description: "The always-on VGA community. Game nights, voice channels and mates.", external: true },
    ],
  },
  {
    label: "Support VGA",
    href: "/support",
    items: [
      { label: "Donate", href: "/donate", description: "Every donation funds free programs that keep Veterans connected." },
      { label: "Our Sponsors", href: "/sponsors", description: "The legends who back VGA — grants, sponsors and partners by year." },
      { label: "Become a Sponsor", href: "/become-a-sponsor", description: "Sponsorship tiers and what your support delivers." },
      { label: "Shop", href: "/shop", description: "VGA merch — hoodies, polos, patches and the 5-year challenge coin." },
      { label: "Ways to Help", href: "/support", description: "Raffle, Patreon, volunteering and more." },
    ],
  },
];

export const ctaNav = {
  join: { label: "Join VGA", href: "/become-a-member" },
  donate: { label: "Donate", href: "/donate" },
  discord: { label: "Join Discord", href: "https://discord.gg/veterangamingaustralia" },
};

export const footerNav: { heading: string; links: NavLink[] }[] = [
  {
    heading: "About",
    links: [
      { label: "Our Story", href: "/about-us" },
      { label: "Our Team", href: "/our-team" },
      { label: "Our Impact", href: "/impact" },
      { label: "Contact Us", href: "/contact" },
    ],
  },
  {
    heading: "Programs",
    links: [
      { label: "All Programs", href: "/programs" },
      { label: "Gaming Hubs", href: "/gaming-hubs" },
      { label: "Esports & OVEL", href: "/esports" },
      { label: "Game Servers", href: "/programs/game-servers" },
      { label: "Events", href: "/events" },
    ],
  },
  {
    heading: "Community",
    links: [
      { label: "News", href: "/news" },
      { label: "Education", href: "/education" },
      { label: "Photo Gallery", href: "/gallery" },
      { label: "Become a Member", href: "/become-a-member" },
    ],
  },
  {
    heading: "Support",
    links: [
      { label: "Donate", href: "/donate" },
      { label: "Sponsors", href: "/sponsors" },
      { label: "Become a Sponsor", href: "/become-a-sponsor" },
      { label: "Shop", href: "/shop" },
      { label: "Privacy Policy", href: "/privacy-policy" },
    ],
  },
];
