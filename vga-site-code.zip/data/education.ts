import type { ImageKey } from "./generated/images";

/** Education guides — text reproduced from the previous site's Education pages; PDFs preserved in /public/docs. */
export type Guide = {
  slug: string;
  title: string;
  subtitle: string;
  image: ImageKey;
  inlineImage?: ImageKey;
  pdf: string;
  author?: string;
  body: string; // markdown
};

export const educationIntro = [
  "At Veteran Gaming Australia, we believe that gaming should be an enjoyable and enriching experience for everyone involved. Our community is dedicated to promoting healthy, safe, and secure gaming environments where players can connect, collaborate, and have fun without compromise.",
  "We strive to foster a culture that values respect and inclusivity, ensuring all gamers feel welcome and supported. Join us today and discover the positive side of gaming with fellow enthusiasts who share your passion!",
];

export const guides: Guide[] = [
  {
    slug: "healthy-gaming",
    title: "Healthy Gaming",
    subtitle: "Strategies for Healthy Digital Gaming",
    image: "education/healthy-gaming-ergonomics",
    inlineImage: "education/monitor-settings",
    pdf: "/docs/strategies-for-healthy-digital-gaming.pdf",
    author: "Written by Samuel Harris, Veteran, Esports Coach & Founder of Veteran Gaming Australia",
    body: `Welcome to Strategies for Healthy Digital Gaming, where we explore key practices to ensure a balanced and healthy gaming environment in your home.

### Stretching

In addition to ergonomics, incorporating regular stretching into your gaming routine is essential. Every 30 minutes, take breaks to stretch your arms, wrists, hands, fingers, and even go for a short walk or engage in household chores. This practice not only helps prevent physical strain but also refreshes your mind. Consider setting in-game challenges that involve physical activities like stretches or pushups to ensure you stay active during gaming sessions.

### Schedules & Blue Light

Setting schedules is another vital strategy. While gaming can be immersive, sticking to a predetermined schedule allows your body and mind to wind down after playing. This promotes better sleep and overall well-being. Moreover, optimizing your monitor settings, including brightness and blue light filters, can reduce eye strain, headaches, and sleep disturbances.

### Games

Selecting the right game for your mood and being aware of how games affect your emotions is essential. Seek advice from friends and communities, and consult health professionals if needed, to ensure a positive gaming experience that aligns with your mental well-being. Different game genres offer various cognitive and social benefits, so choosing the right game for your needs is essential.

Games can have many positive benefits and some of the benefits of certain genres of games include:

- **RTS** – Critical Thinking, Decision Making, Planning, Teamwork
- **FPS** – Reaction times, Attention Skills, hand-eye co-ordination, depth perception, teamwork
- **MMORPG** – Exploration, Creativity, Imagination, Teamwork, (Escapism when utilised with Health practices)

By implementing these strategies, you can create a healthy digital gaming environment at home that promotes both physical and mental well-being, allowing you to enjoy gaming to the fullest while maintaining a balanced and healthy lifestyle.

Further information on Healthy Digital Gaming for Families can be found on the [Veteran Gaming Australia YouTube channel](https://youtu.be/0tEgIquvyUA?si=K3woWKvy1C5FuZio).`,
  },
  {
    slug: "3d-printing",
    title: "3D Printing",
    subtitle: "3D Printing Basics",
    image: "education/3d-printing",
    inlineImage: "education/3d-printed-skull",
    pdf: "/docs/3d-printing-basics.pdf",
    author: "Guide by Bridget Clinch, Army Veteran, Veteran Gaming Australia Member.",
    body: `The version of 3d printing that I have taken a deep dive into is called Fused Deposition Modelling (FDM) that term was invented in 1989. It has evolved to the point that there’s been for the last few years at least, some semi-reliable and affordable home/hobbyist 3d printers so it isn’t just the domain of industry & government anymore.

There are 3 levels of FDM printers at the moment, the ones that cost more than a car, that the industry uses, are reliable, repeatable and solid. There’s a rapidly evolving middle ground that used to be dominated by Prusa, but now Bambu Labs, Creality and others have entered this realm and taken a few steps forward. These printers are a bit pricier, but still in reach of the home user. This middle ground is the closest to a usable appliance like printer, that should just work most of the time with minimal user input required. At the bottom there is the ultimate cheapest possible printer where everyone else resides, the Creality Ender, the Anycubics, the Artillery, etc. This lowest tier is all basically a different spin on the Prusa i3 clone built as cheaply as possible, with minimal quality control and cheap components. There is also a weird other tier that spans the bottom two, and that is fully open source build it yourself designs that exist both as bills of materials (BOMs) and instructions online, and more recently third party kits of these printers, these are Voron, Rat Rig, VZbot, and a few others. These build-your-own printers give you total control over everything, and can be made with no compromises basically industrial quality & repeatability machines, or cheaper if you can source or already have the components.

The best way to think of an FDM 3d printer is not as a tool or an appliance yet, they’re still a very in development collection of a frame and motors, like a simple robot, that moves a carriage and maybe a platform in 3 axes in a variety of different ways, with a hot melty bit, and a filament feeder bit that moves around as it is told, to melt and deposit plastics in a pre determined path that most of the time, hopefully results in some sort of usable plastic object. Industry has sensors to get better feedback, home users have the cheaper versions, and more recently, even lidar has been added to help them self-calibrate down to home level thanks to Bambu labs. If you’re following, then you may be starting to realise that a nerdy user can integrate additional electronics into existing designs to modify things to do extra features, and plenty of people are doing this online.

These “dumb” sometimes expensive machines really only do what they are told, they heat up bits, and they move around, and they squirt melted plastic like a mr whippy ice cream, they don’t yet have the inbuilt ability to detect anything much other than maybe hitting an endstop, or that a heater isn’t heating right, they will continue to move and spit plastic as they’ve been told regardless. The next part of the equation is that there’s a combination of firmware & software needed to tell the machine what to make. Before I get to that though, one critical component in a home FDM 3d printer’s ability to be useful is the user. The machine always does what it is told, so most problems in reality are user error, the sooner you get your head around that, the better. Most home machines require calibration, levelling the bed, how far each motor or axis moves, how much plastic is being extruded, are just the start, then you get into finer tuning.

### Budget

- Voron Trident kit ~ $1700 - $2100 totally DIY, rock solid once calibrated.
- Bambu Lab X1 Carbon $1849 New kid on the block, closed source, has a lidar to calibrate, just works.
- Bambu Lab P1P $1069 Cut down version of the above, not enclosed, missing some features, but works.
- Prusa mk4 ~ $1400 The established top dog of home printing from Prague. Works, ageing, a bit pricey.
- Prusa mini ~ $800 The budget from the top dog, little cantilever, works, pricey for the size.
- Creality Ender 3 ~ $250 Crapshoot, massive community, huge modding potential, good starter if you’re handy.

Indicative prices at 24 May 2023

As you can see, you can get into basic printing with a reasonable volume at only $250. You could be making things trouble free for a year on that machine, it may not work out of the box, or you could be anywhere in between. If I got that basic printer, I have enough spare parts and know how I could get it working regardless, but if you don’t have stepper motors, belts, soldering and crimping gear, spare mainboards etc lying around in your garage like some kind of weirdo, then you might be thinking you just wasted your money. Plenty of 3d printing journeys end here, search FB marketplace for examples.

So in some ways, the more you spend initially can pay off in terms of functionality and longevity. You really need to weigh up what your priorities are. If you’re starting a business or hobby that just needs to be able to spit out things that work with minimal messing around, then you are going to have to shell out. If you’re a hobbyist who wants to be working on the printer itself as much as making things, then you have a lot more options available.

### Volume required

Most printers have a cubic volume, a small printer is around the 180mm3, mid range is around 200ish mm3, and the big ones start around 300ish mm3 and above. Bigger than 300mm in any one axis then starts to require a much higher strength and precision frame, it can be done of course, but again, it will take magic beans and some know how.

It is surprising how much you can achieve with a smaller printer, the smallest Voron core XY is built around 120mm3 build volume. Prusa mini is 180mm3 and can satisfy nearly every build, including helmets in multi parts. 300mm3 is where you start to be able to print a helmet in one main piece, so if that is your main aim then that’s where you need to start. I initially intended to make a suit of Mandalorian armour, so started with an Anycubic Mega X at that size, and have since modified it to make a really solid and awesome cartesian printer.

### Materials you want to create with

Every printer will print PLA. It prints in the open air, and doesn’t need a heated print bed. It is very easy to make a decent looking print with, and does fine detail well. It has a glass transition temperature at around 60 c though, and under stress will deform over time more than some other plastics. There are versions of PLA that include wood fibres, or are glow in the dark, etc, that require you to change the stock nozzle from a brass one to a hardened steel one, as the filament will abrade the nozzle otherwise.

PETG is becoming more common, it likes a heated bed, but will print in the open, needs a bit of a better hotend, but you can upgrade a printer’s hotend easily. It can be complicated to print with, stringy and takes a lot more calibration, but it has a bit more elasticity than PLA, and a glass transition temp of around 80, so can tolerate heat more, and can be stressed a bit more than PLA and retain its integrity, like for a desk clamp etc.

As the materials get stronger, they require more heat to melt, a hotter print bed, and often an enclosed printer to prevent warping, which can crack a part or cause the print to fail. We’re talking ABS, ASA Polycarbonate, Nylon etc. Many also produce fumes, meaning your printer will need to be put out of any living areas, and/or mitigated with carbon recirculating air filters or extraction systems, which you can build yourself from open source plans. You can also integrate these into your printer's electronics using custom firmware and macros to control these fans manually, or automatically. It sounds complicated, but once you are getting to this level, you either have an industrial printer that takes care of it, or you’ve learned to set up your custom firmware, crimp wires and connectors, etc, and you’re used to finding the info you need on GitHub.

### Kinematics

The most commonly used kinematics are below, there are many more, Google Tripteron if you are interested.

Hopefully home printers will have beds that rotate as well as twist soon, there are prototypes out there, but the sliced files need to be manually edited for them to work at the moment, you may have seen metal propellers being 3d welded/printed in this manner, it isn’t at home yet, but give it time.

**Cartesian:** The standard home FDM printer is based on the Prusa i3. It is a Cartesian style printer, where the bed moves forward and back on the Y axis, the frame moves the print head up and down on the Z axis, and the print carriage goes side to side on the X axis. These are relatively cheap and simple as each axis is its own entity usually driven by one motor, although some more solid ones might have two motors on the Z axis. Cartesians include some cube printers as well as some cantilever designs like the Prusa mini. These can be good all round, keep the price, calibration and maintenance simple, and can do anything with modifications, just not at super speeds.

**Delta:** These are some of the most hypnotic to watch as there are 3 vertical axes all driving movement of the print head in all axes all the time. They are notable for being able to be built to be fast as long as the print head weight is kept minimal. They can be large and built to print taller objects, for example, if you wanted to 3d print rockets, a delta could be your best bet.

**Core XY:** These are the beastiest in terms of kinematics and speed. Two or four motors drive the XY movement with two belts simultaneously, and one to four motors drive the z axis via belts or screws. Being cubey, these enclosures are easier than the others, and electronics are easier to keep external to the enclosed print volume. When built well and tuned with an accelerometer, the core XY machines can achieve extremely high print and acceleration speeds making them several times faster than a well-built and tuned Cartesian.

### Print bed & surface

Cheaper printers still come with a glass or coated glass bed. These are OK for starters, but they can be heavy, and at some stage the coating will wear out or be damaged and it will need replacing, not all plastics will want to stick, or get unstuck easily either. Spring steel beds powdercoated with PEI are a great all round bed for every use case.

Many printers are now coming with PEI beds that magnetically attach to the build plate, some have a smooth and a rough side offering more material versatility.

### Direct drive vs Bowden

Direct drive is where the motor and gears that push the filament to the melty bit are right next to it. Bowden or remote is where the motor is somewhere else on the frame, and it pushes the filament through a Bowden tube to the melty bit. The longer the path of travel, the more it creates issues and the less likely you’ll be able to print with flexible filaments. So if you want to be making your own rubber feet, or bumpers or things like that, it's probably better to choose a direct drive straight up. Any printer can be modified from one to the other once you know what you’re doing though.

### Slicers

The slicer is a piece of software, don’t worry, they’re free, that turns a 3D object file in to g code that your FDM printer can understand. They have a range of settings that change the results of the printed item. The slicer basically slices your object into layers, then breaks those layers up into a series of movements and extrusions for the machine to carry out, which hopefully result in a successful object being created.

Slicers will need a profile put in to them for your printer, and most printers will have a standard profile somewhere online if not in the slicer already. You can easily pick a printer that has similar enough characteristics though, and change the relevant parameters. The two main slicer options seem to be PrusaSlicer & Cura. I have tried Cura, but ended up switching to PrusaSlicer.

You probably should try both and maybe others if they appeal to you, to get a feel for the UI, and also what all the settings are and how they change the result.

### Design

Tinkercad & Microsoft 3d Builder are both useful tools for starting, but both retain their place even when you’ve levelled up to a proper industrial style CAD software. Both can be used for making simple objects and/or merging and splitting larger objects to fit them in your printer.

Fusion 360, Freecad, Onshape and others have free versions with limitations, it really depends on you which one you want to run with. Fusion 360 limits you to 10 open projects for the free version, but it runs on your PC, which can be handy. Onshape doesn’t limit you at all, but is browser based, and all your creations are publicly available for anyone else to copy and work on. Teaching Tech on YouTube has a great intro to onshape, and they have their own online tutorial too that gives you a certificate. Every CAD has tonnes of YouTube tutorials though, so play around and see what you click with.

### Designing for printing & slicing considerations

As objects are laid down a layer at a time, the weakest part is often layer adhesion. So when designing and slicing it is something to be mindful of. However, different materials vary, and it is possible to print small objects in PETG for example, then test them and tune settings to the point where the structure will fail elsewhere, rather than the layers splitting.

### Printing an object

The process for making printer spit out plastic thingemy is as follows. You take your 3d file, usually a .stl file and open it in your slicer. You change any settings to suit the object, hit slice, enjoy the preview of the gcode, maybe look through the layers to see if there is anything that looks off, then you save the file. You take that saved sliced g code file and via USB drive/sd card/browser interface if you have one to your printer. You load your filament or already have some loaded in your printer, you tell your printer to print the file and if you’re lucky, some time later, the object will be ready.

Simple hey.`,
  },
  {
    slug: "facebook-privacy",
    title: "Facebook Privacy",
    subtitle: "Facebook Privacy for Parents & Kids",
    image: "education/facebook-icon",
    inlineImage: "education/facebook-search-settings",
    pdf: "/docs/facebook-privacy-for-parents-and-kids.pdf",
    body: `So your kid has set up a Facebook account, there are plenty of hidden dangers IRT privacy and security, and this guide will go through some of the important tips to help you as parents & your kids to understand what these are and what they influence.

### Account Search

Accounts generally can be searched by email, phone number, name and Google even has an integration setting where others can search on Google for a Facebook email, name, it will appear if the setting is left on.

- Select the top right of Facebook.
- Select Settings & privacy
- Choose Privacy
- Choose who can find you on Facebook
- Phone Number as only me
- Email Address as Only Friends
- It is also good to turn off the setting in Search Engines on how they can find you.

### Web Data Tracking

Facebook often collects data from any website searched on your child's device & app used, this is often used to personalise the experience by providing targeted advertisements on Facebook based on what they have searched or used. To help stop this data collection, the below steps will help:

- Select the top right of Facebook.
- Select Settings & privacy
- Select Privacy Shortcuts
- In Your Facebook Information, select View or Clear your off-Facebook activity
- Select Clear History.
- Turn off Manage Future Activity

### Personal Information

There are settings to help limit what information, such as DOB, phone number, posts and stories, that can be seen on your child's Facebook. This can be found in Profile Information and can be set for each one as Only me, Friends or Everyone. Discuss with them the implications of this information, public and even to friends, where the information may not be required.

### Location Data

Leaving location data on means Facebook can collect data about your location generally at any time when the app is running or not. This is often for targeted advertising services within the region your child may be in.

The best method to stop this from occurring is going in on the mobile phone device itself and within the relevant settings, privacy, location service and turning this setting to only while using the app or never/deny.

### Facial Recognition

This is one of those often sneaky ones in the background left on, while Facebook claims not to sell any Facial recognition data and claims it is for helping identify fake accounts, tagging friends & the likes. The risk with biometric data may seem low, however, with advancements in technology, it starts to gain risks while currently there is also no use for it to be left on.

This can be easily turned off by:

- Select the top right of Facebook
- Select Settings & privacy
- Select Privacy Shortcuts
- Under Privacy, select Control Face Recognition
- Select Edit & choose No

### Two Factor Authentication

This is to help ensure account security and provides another factor to prevent their account from being hacked into. When turned on, this will send a code to your child's phone &/or authenticator app on phone each time they try to login to Facebook. This can be easily done by:

- Select at the top right of Facebook.
- Select Settings & privacy
- Select Security & Login
- Select Set-up two-factor authentication and choose the method that works for your child.

There are also many applications out there which can help in monitoring usage, blocking content on the mobile and apps, such as when it picks up pornography, illegal substances or content with aggressive elements such as hate speech. The right mix is to ensure your children know about all these cyber security practices, talk to them and help educate them and if further support is required such as apps that monitor usage and support to prevent content adopt this in however generally education and understanding how it can affect them, their family & friends if they don’t practice correct cyber security is the best practice.`,
  },
  {
    slug: "instagram-security",
    title: "Instagram Security",
    subtitle: "Instagram Cyber Security for Parents & Kids",
    image: "education/instagram-tablet",
    inlineImage: "education/instagram-icon",
    pdf: "/docs/instagram-cyber-security-for-parents-and-kids.pdf",
    body: `### How old should you be to use Instagram?

Terms of service state you have to be 13, but there's no age-verification process, so it's very easy for kids under 13 to sign up. Common Sense would say 15+ because of the mature content, access to strangers, marketing ploys, and data collection.

### Security settings on Instagram?

There are security settings on Instagram to help with who & what content can be seen/reshared and similar on your kids' profiles, we will share these below.

- In privacy settings you can restrict who can comment, such as only to followers & can restrict certain words with filters.
- Ability to reshare is another of these settings where you can choose who can reshare content posted by your kids, if content is reshared, it has the ability to go to the wider public from their friends' profiles if shared.
- You can add permissions for videos & photos of others posting on your kids' profile, comments & tagging them.

### Monitoring kids' activity on Instagram?

Best tip is to ask your kids to give you a walk through and explain who their friends are, what they are posting and if anything you think is iffy, ask them about it and why. Some tips below also may help in monitoring their activity.

- Set up your Instagram and follow them, that way you can see what they are posting and who is commenting.
- Check in on them at random intervals, going through their Instagram account just to see who/what content they have added.

Instagram is a very heavy image-based platform, this has the ability in kids' minds to influence how they should look, and criteria around other kids are posting photos and doing it so I should do it also. This can also influence validation in the mindset in a way of imagery, such as taking photos of oneself and publishing them for validation through likes, follows, and this can be seen as a type of measuring stick for kids. Discussions around this should be discussed early with your kids, and by implementing the monitors, this can help bring a safer space for your kids.`,
  },
  {
    slug: "tiktok-safety",
    title: "TikTok Safety",
    subtitle: "TikTok Cyber Security for Parents & Kids",
    image: "education/tiktok-icon",
    inlineImage: "education/tiktok-phone",
    pdf: "/docs/tiktok-cyber-security-for-parents-and-kids.pdf",
    body: `### Family Pairing

Family pairing allows parents to link their own account with their children’s to access it remotely. This enables parents to turn on Restricted mode and set screen time limits and disable direct messages right from their own phone. This also can’t be turned off by children without the parents' approval.

**Turn on Family Pairing:**

- Open the parent's TikTok account
- Go to Profile (the person icon in the bottom right corner)
- Hit the three dots in the upper right corner to go to Settings
- Go to Family Pairing. Hit Continue
- Select Parent under Who is Using this TikTok account?
- A QR code will appear
- Follow these steps on your teen's account:
- Log into TikTok
- Go to Settings and select Family Pairing
- Select Teen and then scan the QR code to link accounts
- You will need to select the child's account
- Now you can adjust their settings to your liking

### How to set screen time limits on TikTok

Setting screen times is great and can be easily done on TikTok through the below. Turn on screen time limits:

- Open TikTok
- Go to Profile (the person icon in the bottom right corner)
- Hit the three dots in the upper right corner to go to Settings
- Under Digital wellbeing, select Screen time management
- Select time limit and choose between 40 minutes to 120 minutes
- And then turn it on!

### How to make a TikTok account private

Videos on private accounts can only be seen by the creator and by those who the creator has approved as a follower. Users under 16 automatically have private accounts, but any account can be set to private.

**Set as a private account:**

- Open TikTok
- Go to Profile (the person icon in the bottom right corner)
- Hit the three dots in the upper right corner to go to Settings
- Under Privacy, select Private account

### Restrict comments on videos

You can restrict comments made on videos. Only users over 13 can send and receive comments. Adjust comment settings:

- Open TikTok
- Go to Profile (the person icon in the bottom right corner)
- Hit the three dots in the upper right corner to go to Settings
- Under Privacy, select Who can comment on your videos, and then choose:
- Friends — which limits comments to people your child follows
- Only me — which disables comments from all other users

### How to turn off downloads on TikTok videos

This setting prevents other users from downloading your videos to their phone. Turn off Downloads:

- Open TikTok
- Go to Profile (the person icon in the bottom right corner)
- Hit the three dots in the upper right corner to go to Settings
- Under Privacy, select Downloads.
- Tap next to Video downloads to turn off or on

### How to turn off direct messages on TikTok

You can have it so your children's TikTok can receive messages from anyone, no one, or friends. The direct messaging feature allows users to send TikToks and text, but not images or video. Only users over 16 can send direct messages.

**To restrict direct messages:**

- Open TikTok
- Go to Profile (the person icon in the bottom right corner)
- Hit the three dots in the upper right corner to go to Settings
- Under Privacy, select Who can send you direct messages, and then choose:
- Friends — which limits DMs to people your child follows
- Only me — which disables DMs from all other users

### How to report users and comments

If you experience unjust behaviour, and want to report it this can also be easily done by:

**To report a user:** Go to their profile, select the three dots in the top right corner, select report, select why you are reporting them.

**To report a comment:** Select the comment, then select report, follow instructions to detail why you’re reporting the comment.`,
  },
];
