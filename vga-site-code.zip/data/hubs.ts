/**
 * Gaming hubs — taken from the interactive map on the previous site's Gaming Hubs page (19 pins),
 * captured 5 Sep 2026. Titles, addresses, descriptions and coordinates are reproduced as published.
 * "type" and "state" are derived from the published description and address; suburb labels are from the address.
 */
export type HubType = "Esports Hub" | "Social Gaming Hub";
export type AuState = "QLD" | "NSW" | "ACT" | "VIC" | "TAS" | "SA" | "WA" | "NT";

export type Hub = {
  slug: string;
  title: string;
  address: string;
  suburb: string;
  state: AuState;
  type: HubType;
  equipment: string; // as published in the map pin description
  latitude: number;
  longitude: number;
};

export const hubs: Hub[] = [
  { slug: "51st-battalion-fnqr-edmonton", title: "51st Battalion, The Far North Queensland Regiment", address: "1 Macbar Ct, Edmonton QLD 4869", suburb: "Edmonton (Cairns)", state: "QLD", type: "Social Gaming Hub", equipment: "Xbox with Game Pass", latitude: -17.0022659, longitude: 145.7458648 },
  { slug: "keith-payne-vc-unit-greenslopes", title: "Keith Payne VC Unit", address: "Nicholson St, Greenslopes QLD 4120", suburb: "Greenslopes (Brisbane)", state: "QLD", type: "Social Gaming Hub", equipment: "Nintendo Switch with games", latitude: -27.5145911, longitude: 153.0483801 },
  { slug: "mates4mates-stafford", title: "Mates4Mates Stafford Veteran Wellbeing Centre", address: "274 Stafford Rd, Stafford QLD 4053", suburb: "Stafford (Brisbane)", state: "QLD", type: "Social Gaming Hub", equipment: "Nintendo Switch with games", latitude: -27.4109332, longitude: 153.0191614 },
  { slug: "rsl-mount-isa", title: "RSL Mount Isa Sub Branch", address: "Bligh St, The Gap QLD 4825", suburb: "Mount Isa", state: "QLD", type: "Social Gaming Hub", equipment: "Xbox with Game Pass", latitude: -20.7240948, longitude: 139.4971206 },
  { slug: "vga-redland-bay", title: "VGA Redland Bay", address: "Redland Bay Community Hall, 5-9 Weinam St, Redland Bay QLD 4165", suburb: "Redland Bay", state: "QLD", type: "Esports Hub", equipment: "4 × gaming PCs", latitude: -27.615907, longitude: 153.3076345 },
  { slug: "blamey-community-group-kapooka", title: "Blamey Community Group", address: "Sturt Ave, Kapooka NSW 2661", suburb: "Kapooka (Wagga Wagga)", state: "NSW", type: "Social Gaming Hub", equipment: "Nintendo Switch with games", latitude: -35.1512782, longitude: 147.3029641 },
  { slug: "rsl-lifecare-dee-why", title: "RSL LifeCare Dee Why Veteran Wellbeing Centre", address: "932 Pittwater Rd, Dee Why NSW 2099", suburb: "Dee Why (Sydney)", state: "NSW", type: "Social Gaming Hub", equipment: "3 × Nintendo Switch, virtual reality and games", latitude: -33.750309, longitude: 151.2900078 },
  { slug: "joint-movement-section-randwick", title: "Joint Movement Section Randwick", address: "373a Avoca St, Kingsford NSW 2032", suburb: "Kingsford (Sydney)", state: "NSW", type: "Social Gaming Hub", equipment: "Xbox with Game Pass", latitude: -33.9306704, longitude: 151.2386096 },
  { slug: "rsl-lifecare-shoalhaven-nowra", title: "RSL LifeCare Shoalhaven Veteran and Family Hub", address: "Dumaresq Village, 124 Wallace St, Nowra NSW 2541", suburb: "Nowra", state: "NSW", type: "Esports Hub", equipment: "4 × gaming PCs, Xbox with Game Pass, Nintendo Switch with games", latitude: -34.8895087, longitude: 150.6084904 },
  { slug: "rsl-lifecare-riverina-wagga", title: "RSL LifeCare Riverina Veteran Wellbeing Centre", address: "240 Baylis St, Wagga Wagga NSW 2650", suburb: "Wagga Wagga", state: "NSW", type: "Esports Hub", equipment: "4 × gaming PCs, Nintendo Switch with games", latitude: -35.1102448, longitude: 147.3701382 },
  { slug: "sydney-veteran-lodge", title: "Sydney Veteran Lodge", address: "91 Darcy Rd, Wentworthville NSW 2145", suburb: "Wentworthville (Sydney)", state: "NSW", type: "Social Gaming Hub", equipment: "Nintendo Switch with games", latitude: -33.8027211, longitude: 150.9714596 },
  { slug: "rsl-lifecare-central-coast-wyong", title: "RSL LifeCare Central Coast Veteran and Family Hub", address: "31 Hely St, Wyong NSW 2259", suburb: "Wyong (Central Coast)", state: "NSW", type: "Social Gaming Hub", equipment: "Xbox with Game Pass", latitude: -33.2805964, longitude: 151.425542 },
  { slug: "simpson-barracks-yallambie", title: "Simpson Barracks Community Centre", address: "Molloy Rd, Yallambie VIC 3085", suburb: "Yallambie (Melbourne)", state: "VIC", type: "Social Gaming Hub", equipment: "Xbox, sim racing wheel and games", latitude: -37.7236426, longitude: 145.092974 },
  { slug: "vasey-rsl-care-hawthorn", title: "Vasey RSL Care", address: "172 Burwood Rd, Hawthorn VIC 3122", suburb: "Hawthorn (Melbourne)", state: "VIC", type: "Social Gaming Hub", equipment: "Xbox with Game Pass", latitude: -37.8220889, longitude: 145.0284529 },
  { slug: "wodonga-rsl", title: "Wodonga RSL", address: "27 Reid St, Wodonga VIC 3690", suburb: "Wodonga", state: "VIC", type: "Social Gaming Hub", equipment: "Xbox with Game Pass", latitude: -36.1229624, longitude: 146.8924747 },
  { slug: "veterans-australia-nt-freds-pass", title: "Veterans Australia NT", address: "135 Bees Creek Rd, Freds Pass NT 0822", suburb: "Freds Pass (Darwin)", state: "NT", type: "Social Gaming Hub", equipment: "Nintendo Switch and 3D printer", latitude: -12.5468296, longitude: 131.0595697 },
  { slug: "rsl-lifecare-queanbeyan", title: "RSL LifeCare Queanbeyan Veteran & Family Hub", address: "251 Crawford St, Queanbeyan NSW 2620", suburb: "Queanbeyan (Canberra region)", state: "NSW", type: "Esports Hub", equipment: "4 × Xbox with Game Pass", latitude: -35.3544211, longitude: 149.2343657 },
  { slug: "lives-lived-well-adelaide", title: "Lives Lived Well Adelaide Veterans’ and Families’ Wellbeing Hub", address: "44 John Rice Ave, Elizabeth Vale SA 5112", suburb: "Elizabeth Vale (Adelaide)", state: "SA", type: "Social Gaming Hub", equipment: "1 × Xbox with Game Pass", latitude: -34.7481129, longitude: 138.6675593 },
  { slug: "9th-brigade-resilience-training-centre", title: "9th Brigade Resilience & Training Centre", address: "60 Anzac Hwy, Everard Park SA 5035", suburb: "Everard Park (Adelaide)", state: "SA", type: "Social Gaming Hub", equipment: "1 × Xbox with Game Pass", latitude: -34.95196, longitude: 138.5739013 },
];

export const hubStates = Array.from(new Set(hubs.map((h) => h.state))) as AuState[];

/** Published in the Aug 2026 newsletter but not yet on the previous site's map — listed separately, not plotted. */
export const recentHubMentions: { title: string; note: string; source: string }[] = [
  { title: "Hampton RSL Sub-Branch Esports Hub", note: "Established June 2026 (VGA May–August 2026 newsletter). Address not yet published.", source: "/news/vga-may-august-newsletter" },
  { title: "1st Regiment social gaming presence", note: "New social gaming presence on a Defence base, June 2026 (newsletter). Location not published.", source: "/news/vga-may-august-newsletter" },
];
