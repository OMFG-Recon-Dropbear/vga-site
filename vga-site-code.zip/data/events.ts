import type { ImageKey } from "./generated/images";
import type { AuState } from "./hubs";

/**
 * Events. The previous site's Wix Events app held a single entry, "VGA Test Event" (a test listing —
 * see MIGRATION-REVIEW.md), so there are no verified upcoming in-person events to publish. In-person
 * events are announced on VGA's Facebook page and Discord (as the previous Home and Programs pages say).
 *
 * Past events below are those documented on the previous site (posts, galleries and the Aug 2026 newsletter),
 * with the dates and locations as published. Nothing here is invented.
 */
export type EventRegion = AuState | "Online" | "National";

export type VgaEvent = {
  slug: string;
  title: string;
  date: string; // ISO date (YYYY-MM-DD) or YYYY-MM when only the month was published
  endDate?: string;
  displayDate: string; // as published
  location?: string;
  region: EventRegion;
  summary: string;
  image?: ImageKey;
  href?: string; // more detail (news post or gallery)
  registrationUrl?: string;
  kind: "In person" | "Online" | "Esports";
  source: string;
};

export const upcomingEvents: VgaEvent[] = [];

export const pastEvents: VgaEvent[] = [
  {
    slug: "ovel-rocket-league-premier-qualifiers-2026",
    title: "OVEL Rocket League — Premier League Qualifiers",
    date: "2026-08-08",
    displayDate: "8 August 2026",
    location: "Online — livestreamed on VGA's Twitch channel",
    region: "Online",
    kind: "Esports",
    summary: "18 teams competed for a place in the Top 8 of the Oceania Veteran Esports League Premier League.",
    href: "/news/vga-may-august-newsletter",
    source: "VGA May–August 2026 newsletter",
  },
  {
    slug: "vga-gaming-pc-raffle-launch-2026",
    title: "VGA Gaming PC Raffle launch",
    date: "2026-08-03",
    displayDate: "3 August 2026",
    region: "National",
    kind: "Online",
    summary: "VGA's latest fundraising raffle launched with a custom gaming PC setup generously donated by Campbell's Custom Computers. 100% of proceeds support VGA's volunteer-run programs.",
    image: "news/gaming-pc-raffle-2026",
    href: "https://www.raffletix.com.au/newgamingpcraffle2026",
    source: "VGA May–August 2026 newsletter",
  },
  {
    slug: "ovel-rocket-league-challenger-qualifiers-2026",
    title: "OVEL Rocket League — Challenger League Qualifiers",
    date: "2026-08-01",
    displayDate: "Saturday 1 August 2026",
    location: "Online",
    region: "Online",
    kind: "Esports",
    summary: "The first Oceania Veteran Esports League Rocket League qualifiers determined the Top 8 teams progressing to the Challenger League Finals, including the Hampton Heroes from VGA's new Hampton RSL Sub-Branch Esports Hub.",
    image: "news/ovel-rocket-league-top-8",
    href: "/news/vga-may-august-newsletter",
    source: "VGA May–August 2026 newsletter",
  },
  {
    slug: "invictus-australia-team-selection-camp-2026",
    title: "Invictus Australia Team Selection Camp — esports coaching",
    date: "2026-07",
    displayDate: "July 2026",
    location: "Canberra",
    region: "ACT",
    kind: "In person",
    summary: "VGA CEO Sam Harris and National Esports Manager Mark travelled to Canberra to support the Invictus Australia Team Selection Camp as esports coaches.",
    href: "/news/vga-may-august-newsletter",
    source: "VGA May–August 2026 newsletter",
  },
  {
    slug: "darwin-ice-skating-2026",
    title: "Darwin Ice Skating",
    date: "2026-06",
    displayDate: "May–July 2026",
    location: "Darwin",
    region: "NT",
    kind: "In person",
    summary: "Around 60 Veterans and Veteran Family members got together and had fun on the ice — a standout social activity of the period.",
    href: "/news/vga-may-august-newsletter",
    source: "VGA May–August 2026 newsletter",
  },
  {
    slug: "community-events-may-july-2026",
    title: "Community events across Australia",
    date: "2026-06",
    displayDate: "May–July 2026",
    region: "National",
    kind: "In person",
    summary:
      "VGA teams were stallholders, hosts, participants and supporters at: Invictus Australia WA Sports Expo; Adelaide ADF Transition Seminar; South Australian Partners of Veterans Association activities; Veterans’ Families Day celebrations; Jarryd Goundrey comedy shows; Aussie Frontline Reload; NT History of Darwin Tour; QLD NRL Broncos game; Northern Adelaide Veterans and Family Wellbeing Hub Esports Come and Try Day; Darwin Ice Skating; and the 6th Engineer Support Regiment Family Day.",
    image: "news/vga-social-event-stadium",
    href: "/news/vga-may-august-newsletter",
    source: "VGA May–August 2026 newsletter",
  },
  {
    slug: "five-year-volunteer-celebration-2026",
    title: "VGA Five-Year Volunteer Celebration",
    date: "2026-05-30",
    displayDate: "30 May 2026",
    region: "National",
    kind: "In person",
    summary: "A slightly belated volunteer celebration recognising five years of Veteran Gaming Australia — held, naturally, surrounded by plenty of retro arcade machines.",
    image: "gallery/newsletter-may-aug-2026/02",
    href: "/news/vga-may-august-newsletter",
    source: "VGA May–August 2026 newsletter",
  },
  {
    slug: "aussie-frontline-reload-2026",
    title: "Aussie Frontline Reload",
    date: "2026-05",
    displayDate: "May 2026",
    location: "Hills Convention Centre",
    region: "National",
    kind: "In person",
    summary: "VGA booked a table for eight Veterans and Veteran Family members to hear from speakers, connect with one another and explore discussions around Veteran health, resilience and wellbeing.",
    href: "/news/vga-may-august-newsletter",
    source: "VGA May–August 2026 newsletter",
  },
  {
    slug: "veteran-health-week-2024",
    title: "Veteran Health Week 2024",
    date: "2024-10",
    displayDate: "October 2024",
    region: "National",
    kind: "In person",
    summary: "Photos from VGA's Veteran Health Week 2024 activities — retro arcade sessions, hub visits and social gaming.",
    image: "gallery/vhw-2024/cover",
    href: "/gallery/veteran-health-week-2024",
    source: "Gallery post, 21 Oct 2024",
  },
  {
    slug: "oz-comic-con-brisbane-2024",
    title: "Oz Comic-Con Brisbane 2024",
    date: "2024-09-13",
    endDate: "2024-09-14",
    displayDate: "13–14 September 2024",
    location: "Brisbane Convention & Exhibition Centre (BCEC)",
    region: "QLD",
    kind: "In person",
    summary: "VGA attended Oz Comic-Con Brisbane with a stand — cosplay, community and plenty of photos.",
    image: "gallery/comicon-2024/cover",
    href: "/gallery/comicon-brisbane-2024",
    source: "Gallery post, 14 Sep 2024",
  },
  {
    slug: "air-space-power-centre-2023",
    title: "Miniature figurine painting at the Air, Space and Power Centre",
    date: "2023-11-01",
    displayDate: "1 November 2023",
    region: "ACT",
    kind: "In person",
    summary: "Our ACT team brought a mindfulness-focused miniature figurine painting event to the Air, Space and Power Centre.",
    image: "news/air-space-power-centre",
    href: "/news/our-team-at-air-space-and-power-centre",
    source: "News post, 1 Nov 2023",
  },
  {
    slug: "queensland-mental-health-week-2023",
    title: "Queensland Mental Health Week 2023 — farm day",
    date: "2023-10",
    displayDate: "October 2023",
    region: "QLD",
    kind: "In person",
    summary: "Veterans and families together at a llama farm — learning about and feeding llamas, camels and horses, with social connection for the whole family.",
    image: "news/qld-mhw-2023-cover",
    href: "/gallery/queensland-mental-health-week-2023",
    source: "Posts, 19 and 26 Oct 2023",
  },
  {
    slug: "christmas-celebrations-2022",
    title: "Christmas Celebrations December 2022",
    date: "2022-12",
    displayDate: "December 2022",
    region: "National",
    kind: "In person",
    summary: "Event images from various Veteran Gaming Christmas parties, December 2022.",
    image: "gallery/christmas-2022/cover",
    href: "/gallery/christmas-celebrations-december-2022",
    source: "Gallery post, 22 Dec 2022",
  },
];

export const eventRegionsWithData = (): EventRegion[] => {
  const all = [...upcomingEvents, ...pastEvents].map((e) => e.region);
  const order: EventRegion[] = ["ACT", "NSW", "QLD", "VIC", "SA", "WA", "NT", "TAS", "Online", "National"];
  return order.filter((r) => all.includes(r));
};

export const eventsNotice = {
  heading: "How VGA events are announced",
  body: "Due to our events being in high demand and some even being fully booked in 15 minutes of listings, we often only advertise on our public Facebook and Discord.",
  facebook: "https://www.facebook.com/VeteranGamingAustralia",
  discord: "https://discord.gg/veterangamingaustralia",
};
