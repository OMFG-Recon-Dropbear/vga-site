/** OVEL (Oceania Veteran Esports League) — Call of Duty: Black Ops 6 season, as published on the previous /ovel page. */
export const ovel = {
  title: "Oceania Veteran Esports League (OVEL)",
  game: "Call of Duty: Black Ops 6",
  overview: [
    "The Oceania Veteran Esports League (OVEL) is a premier competitive gaming event for Veterans. This league fosters camaraderie, strengthens social networks, and promotes health and well-being with Esports. By providing a structured and engaging environment, we aim to unite Veterans across Australia and the broader Oceania region, offering them a platform to showcase their skills, build lasting connections, and engage in healthy competition.",
    "The OVEL is built on a foundation of respect, teamwork, and fair play. Across a five-week season, teams will battle in Call of Duty: Black Ops 6 using a double-elimination format, culminating in an exciting final showdown. With dedicated training opportunities, organised streaming coverage, and exclusive prizes, this league is set to become a standout event in the calendar.",
    "Whether you're a seasoned competitor or new to esports, the OVEL welcomes all skill levels and aims to grow the Veteran gaming scene while providing meaningful social engagement.",
  ],
  infoPdf: "/docs/ovel-call-of-duty-black-ops-6-league-information.pdf",
  format: {
    game: "Call of Duty: Black Ops 6",
    mode: "4v4 Competitive Format",
    teams: "Maximum of 5 members per team (4 active + 1 sub)",
    elimination: "Double elimination bracket",
    matchLength: "Best-of-5 for all matches",
    matchFormat: ["Game 1: Hardpoint", "Game 2: Search and Destroy", "Game 3: Control", "Game 4: Hardpoint", "Game 5: Search and Destroy"],
    finals: [
      "Teams who do not make the grand final will compete in a 3rd place playoff match in Week 5",
      "The two teams who climbed their way through the double elimination bracket will face off in the Grand Final immediately after",
    ],
    standings: ["Win/Loss record", "Map differential"],
    schedule: {
      duration: "5 weeks (with potential extension for additional teams)",
      matchDays: "Saturdays or Sundays",
      time: "3:30 PM – 5:30 PM AEST",
      training: "Digital training opportunities will be held twice a week (Wednesdays 7:30pm – 9:30pm and Thursday from 3:00 PM – 5:00 PM AEST) starting two weeks prior to the league’s commencement. Sessions may be coordinated outside these time slots for specific team training upon request.",
      expectedStart: "Saturday 24th May 2025",
    },
  },
  prizes: {
    winners: ["Logitech G733 Wireless Headset (RRP: $299)", "1st Place VGA Medallion", "The sub or player who plays the fewest games on the winning team receives a Corsair HS35 Gaming Headset"],
    runnersUp: ["2nd or 3rd Place VGA Medallion"],
  },
  rules: [
    { heading: "Eligibility", items: ["Open to Veterans who served in the Australian Defence Force only.", "Based on feedback, we may expand this to include families and other leagues in the future."] },
    { heading: "Platforms & Peripherals", items: ["Players may compete on PC or Console", "Use of Controller, Keyboard & Mouse is permitted"] },
    { heading: "Match Conduct", items: ["Players must remain professional and respectful at all times.", "No toxic behavior, harassment, or hate speech."] },
    { heading: "Cheating & Exploits", items: ["Any form of cheating (including use of devices like cronus, XIM and other similar devices), hacking, or exploiting game bugs is strictly prohibited.", "Offenders will be immediately disqualified."] },
    { heading: "Disconnects & Technical Issues", items: ["If a player disconnects mid-match, the team may continue without them or use their sub.", "If a major technical issue occurs, the match may be restarted at the discretion of VGA."] },
    { heading: "Forfeits", items: ["If a team forfeits two matches, they will be placed under review by the admins and contacted to discuss ways to prevent future forfeits.", "If a team forfeits three or more matches, the team may be removed from competition at the discretion of the VGA Tournament Host.", "A forfeit is considered a 3-0 win."] },
    { heading: "Communication & Representation", items: ["Each team must have a Point of Contact (POC) who liaises with VGA.", "VGA will schedule matches and provide notice at least 3 days in advance.", "Teams and organisations are encouraged to stream their matches. VGA will stream all matches wherever possible on our official channel, including exclusive logos/display screens advertising teams and representative organisations."] },
    { heading: "Life Outside Community", items: ["When communicating in Discord, on Xbox, Battle.net, or PlayStation, remember that members have lives outside the community.", "Harassment for any reason (e.g., unresponsiveness, disagreement, etc.) will not be tolerated and can result in muting, suspension, or expulsion from the League."] },
    { heading: "Disruption of Communication", items: ["Keep all communication in Discord respectful and professional.", "Do not spam tag or disrupt normal communication."] },
    { heading: "Harassment", items: ["VGA welcomes players of all skill levels, ages, and backgrounds.", "Racist, sexist, graphic, homophobic, or skill-shaming content will not be tolerated.", "Offenders may face disciplinary action from League Admins."] },
    { heading: "In-Game Conduct", items: ["Players must conduct themselves in a sportsmanlike manner."] },
    { heading: "Cheating & Integrity", items: ["Players must uphold league standards.", "Cheating of any kind will result in disciplinary action."] },
    { heading: "Prohibited Actions", items: ["Stream Sniping: Monitoring or receiving information from an opponent’s Twitch stream or the VGA Twitch channel during matches.", "Account Sharing: Fielding a non-rostered player or using a secondary/Smurf account.", "DDOS Attacks: Using network attack tools to knock an opponent offline or sharing player IP information.", "Match Fixing: Any deliberate attempt to manipulate match results (e.g., sitting in spawn, forfeiting for better playoff positioning, etc.)."] },
    { heading: "Reporting Violations", items: ["Violations should be reported via the #support channel in the VGA Discord with evidence."] },
    { heading: "Disciplinary Action", items: ["Admins reserve the right to take necessary action."] },
  ],
  agreements: [
    { heading: "Killcams", items: ["Killcams must be on."] },
    { heading: "Stryder Attachments", items: ["ONLY Sight, Fast Mag 2, Rear Grip Allowed"] },
    { heading: "Scorestreaks", items: ["Only Hellstorm allowed (Hardpoint)", "RCXD, Hellstorm allowed (SND)"] },
    { heading: "Equipment", items: ["2 Trophies may be run by a team at a given time.", "3rd and 4th player may use trophies, but they cannot throw them.", "Smokes are NOT allowed in all modes."] },
    { heading: "Operators (Not Allowed)", items: ["Toy Man", "Front Man", "Joyride", "Obsidian", "Shadow Work", "Numbers Woods", "Nocturne", "Terminator"] },
  ],
  registration: {
    deadline: "POCs must email us advising of their discord username and Team Captains Discord username, POC and Team Captain may be the same person. All team registrations must be submitted by the 11th May 2025.",
    howToJoin:
      "Complete the registration form and our team will be in contact to organise further details. This league is for Veterans who served in the Australian Defence Force, Coalition Nation Veterans who reside in Australia and Veterans who served in an Oceania region Military Nation.",
    submission:
      "Once you have received confirmation email from our team on registration, POCs/Team Captains must submit their rosters on the VGA Discord under OC Veterans Esports League | Team Registration.",
    required: [
      "Team Name ie. RSL VIC Frankston Sub-Branch",
      "Player Roster (4 Active + 1 Sub, including who is POC/Captain of team, Discord usernames and Activision usernames eg. POC - Joe Bloggs Discord: joebloggs, Team: Captain: Adjay - Adjay#1025983, Loli - Loli#101948).",
      "We will touch base with POC to grab full names of players in helping us generate team information.",
    ],
    closing: "Let’s make this an amazing league and showcase our shared passion for esports.",
  },
  /** Standings table exactly as published (the page did not say which season). */
  standings: {
    note: "Standings as last published by VGA (season not stated).",
    columns: ["Team", "Rank", "Losses", "Total points"],
    rows: [
      { team: "VGA", rank: 1, losses: 0, points: 4 },
      { team: "Shoalhaven Veteran and Family Hub", rank: 2, losses: 0, points: 0 },
      { team: "Riverina Veteran and Family Hub", rank: 3, losses: 1, points: 0 },
    ],
  },
};

/** Rocket League OVEL — VGA May–August 2026 newsletter */
export const ovelRocketLeague2026 = {
  participants: "101 Veterans and Veteran Family members registered across 33 teams for the Rocket League competition.",
  challengerQualifiers: {
    date: "Saturday 1 August 2026",
    summary: "The first Oceania Veteran Esports League Rocket League qualifiers were held to determine the Top 8 teams progressing to the Challenger League Finals. The competition also saw the Hampton Heroes compete from VGA's newly established Hampton RSL Sub-Branch Esports Hub.",
    top8: ["108", "Bottom Gear", "BotSquad", "The Fakers", "Bred", "Rock For Brews", "Goal Diggers", "SkidmarkZ"],
  },
  premierQualifiers: {
    date: "8 August 2026",
    summary: "18 teams will compete for a place in the Top 8 of the Oceania Veteran Esports League Premier League. The action will be livestreamed on VGA's official Twitch channel.",
  },
};

/** Sim racing — previous /sim-racing page */
export const simRacing = {
  heading: "Sim Racing",
  rosterTitle: "Members who have completed 3+ races for VGA (2024)",
  roster: [
    { name: "John Fillingham", handle: "ILOGICAL SPORTS" },
    { name: "Michael Arlett", handle: "VGA BUNYIP MCLUVIN" },
    { name: "Alexander Dyson", handle: "SMITH VGA 4DADS" },
    { name: "Samuel F.A. Smith", handle: "5fAs" },
    { name: "Gordon McCulloch", handle: "GORDONMcCULLOCH" },
    { name: "Jobe Joslin VGA", handle: "JOBLIN" },
    { name: "Matthew Shanahan", handle: "MATTY460" },
    { name: "Blake Norman", handle: "DENIMCHICKON" },
    { name: "Scott Mackay VGA", handle: "SCRUFF71" },
    { name: "Liana Healy VGA", handle: "WASCALY" },
    { name: "John Cashen VGA", handle: "CASHYE" },
    { name: "Tim Hancock VGA", handle: "SKA'" },
    { name: "Robert Anderson", handle: "ROBERTANDERSEN13" },
    { name: "Peter Baxter VGA", handle: "PETER BAXTER" },
  ],
};

export const callOfDuty = {
  heading: "Call of Duty",
  status: "Coming soon",
  note: "The previous site's Call of Duty page said only “COMING SOON”. Black Ops 6 competition currently runs through OVEL.",
};
