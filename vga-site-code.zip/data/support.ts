/**
 * Donate, membership and privacy content — reproduced from the previous site's Donate, Become a Member,
 * Support Us (pricing plans) and Privacy Policy pages.
 */
export const donate = {
  heading: "Your donation creates real impact",
  intro: "Every donation helps Veteran Gaming Australia provide free programs that reduce social isolation and strengthen connection for Veterans and their families.",
  fundsLead: "Your support helps fund:",
  funds: [
    { icon: "🎮", text: "Free gaming and social connection activities" },
    { icon: "🏆", text: "Veteran and Family Esports programs" },
    { icon: "🏥", text: "Veteran hospital visits" },
    { icon: "🎨", text: "Creative workshops, including miniature painting and 3D printing" },
    { icon: "📦", text: "Care packages and wellbeing support" },
    { icon: "🎄", text: "Christmas gifts for Veterans and families experiencing hardship" },
    { icon: "🤝", text: "Community events across Australia" },
    { icon: "💬", text: "24/7 digital community and social connection" },
  ],
  /**
   * Campaign figures exactly as displayed by the previous site's Wix donation widget on 5 Sep 2026.
   * They will not update automatically on this site — update them here (or remove the campaign block)
   * once a donation provider is connected.
   */
  campaign: {
    title: "Support our campaign",
    subtitle: "Help us keep Veterans & families connected",
    raised: 105,
    goal: 20000,
    donations: 2,
    currency: "A$",
    asOf: "2026-09-05",
  },
  impactHeading: "Our impact since 2021",
};

export const membership = {
  heading: "Become a member",
  intro:
    "Are you currently serving, a transitioned veteran or a family member of someone who served and meets the eligibility criteria below? You can join for free membership to our awesome gaming community-charity.",
  promise: "We provide a fun and supportive community with a focus on social and emotional well-being.",
  eligibility: [
    "Must be a current or ex-serving member of the Australian Defence Force or New Zealand Defence Force. A minimum of 1 day of service is required. If New Zealand Defence Force service you must reside in Australia.",
    "Immediate family members aged 18+ (spouses, sons/daughters) of current or ex-serving members.",
  ],
  process: "To join, please fill out the online application form and one of our staff members will be in touch by phone or email with important information to connect with the VGA community.",
  cost: "Membership is FREE and gives you access to exclusive items, discounts and discord role.",
  verificationNotice: "As part of this membership you will be required to verify who you are, or if you are a spouse/child of the Service Member.",
  verificationTypes: ["DVA White/Gold Card", "Service History", "Enlistment/Discharge Certificate", "DPN Email With Full Name"],
  dpnNote: "If you select DPN email, you will need to email us from your DPN email address. Just upload a screenshot of the email.",
  discordNote: "Please join our Discord and provide your Discord username so we can give you the verified role.",
  services: ["Army", "Navy", "Air Force"],
  status: ["Current Serving", "Transitioned", "Family Member (spouse)", "Family Member (child)"],
  genders: ["Male", "Female", "Other"],
};

export const patreon = {
  heading: "Support us through Patreon",
  url: "https://www.patreon.com/veterangamingaustralia",
};

export const privacyPolicy = {
  title: "Privacy Policy",
  entity: "VETERAN GAMING AU",
  contactEmail: "enquiries@veterangamingaustralia.com.au", // as published on the previous privacy page (differs from the .org.au contact address — see MIGRATION-REVIEW.md)
};
