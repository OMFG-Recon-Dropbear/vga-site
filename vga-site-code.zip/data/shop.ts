import type { ImageKey } from "./generated/images";

/**
 * Shop catalogue — products, prices and descriptions as published in the previous Wix store (Sep 2026).
 * DECISION REQUIRED: checkout. The Wix store's cart/checkout cannot be moved to this site, so each
 * product links to its existing product page for purchase until VGA nominates a commerce platform
 * (see MIGRATION-REVIEW.md). Set NEXT_PUBLIC_SHOP_URL to point "Shop" elsewhere when that changes.
 */
export type Product = {
  slug: string;
  name: string;
  price: string;
  description?: string;
  details?: string[];
  images: ImageKey[];
  options?: string;
  buyUrl: string;
  sku?: string;
};

const wix = (slug: string) => `https://www.veterangamingaustralia.org.au/product-page/${slug}`;

export const products: Product[] = [
  {
    slug: "pro-series-hoodie",
    name: "Pro Series Hoodie",
    price: "A$69.95",
    description:
      "Our Pro Series Hoodie is crafted with 240GSM fabric, delivering the perfect blend of style, comfort, and durability. Whether you’re gaming, out and about, or at an event, it’s a great way to represent in style.",
    images: ["shop/pro-series-hoodie"],
    options: "Sizes",
    buyUrl: wix("pro-series-hoodie"),
  },
  {
    slug: "2025-vga-pro-series-polo-womens",
    name: "2025 VGA Pro Series Polo — Womens",
    price: "A$59.95",
    description: "Our 2025 VGA Pro Series Polo features 150GSM Cooldry, 100% polyester fabric for all-day comfort and performance. Show your style with its military camo-inspired precision design, grab yours today!",
    images: ["shop/pro-series-polo-womens"],
    options: "Womens sizes",
    buyUrl: wix("2025-vga-pro-series-polo-womens"),
  },
  {
    slug: "2025-vga-pro-series-polo-mens",
    name: "2025 VGA Pro Series Polo — Mens",
    price: "A$59.95",
    description: "Our 2025 VGA Pro Series Polo features 150GSM Cooldry, 100% polyester fabric for all-day comfort and performance. Show your style with its military camo-inspired precision design, grab yours today!",
    images: ["shop/pro-series-polo-womens"],
    options: "Mens sizes",
    buyUrl: wix("2025-vga-pro-series-polo-mens"),
  },
  {
    slug: "vga-lapel-pin",
    name: "VGA Lapel Pin",
    price: "A$10.00",
    description: "Enamel VGA Lapel Pin, perfect for evening wear-coats.",
    images: ["shop/vga-lapel-pin"],
    buyUrl: wix("vga-lapel-pin"),
  },
  {
    slug: "vga-green-patch",
    name: "VGA Green Patch",
    price: "A$20.00",
    sku: "201502",
    description: "VGA Green Woven Velcro Patch",
    images: ["shop/vga-green-patch"],
    buyUrl: wix("vga-green-patch"),
  },
  {
    slug: "vga-gold-patch",
    name: "VGA Gold Patch",
    price: "A$20.00",
    sku: "201501",
    description: "Gold VGA Velcro Patch",
    images: ["shop/vga-gold-patch"],
    buyUrl: wix("vga-gold-patch"),
  },
  {
    slug: "vga-long-sleeve-fishing-shirt",
    name: "VGA Long Sleeve Fishing Shirt",
    price: "A$60.00",
    sku: "21554345658",
    description: "Breathable Long Sleeve Shirt. 165gsm, 100% polyester.",
    images: ["shop/vga-long-sleeve-fishing-shirt"],
    options: "Mens sizes",
    buyUrl: wix("vga-long-sleeve-fishing-shirt"),
  },
  {
    slug: "vga-army-camo-long-sleeve",
    name: "VGA Army Camo Long Sleeve",
    price: "A$60.00",
    sku: "21554345657",
    description: "Breathable Long Sleeve Shirt. 165gsm, 100% polyester.",
    images: ["shop/vga-army-camo-long-sleeve"],
    options: "Sizes",
    buyUrl: wix("vga-army-camo-long-sleeve"),
  },
  {
    slug: "vga-5yearcelebrationcoin",
    name: "VGA 5 Year Celebration Challenge Coin",
    price: "A$35.00",
    sku: "632835642834575",
    description:
      "Celebrate five years of connection, community, and shared experiences with our limited-edition 5-Year Celebration Challenge Coin. Struck in a premium antique gold finish, this 50mm coin represents the journey, growth, and impact of our community over the past five years. Featuring both our original (OG) logo and alternate logo, it captures where we started and how far we’ve come. Whether you’ve been with us since day one or recently joined the journey, this coin is a meaningful keepsake to honour the friendships, support, and moments that define VGA.",
    details: [
      "50mm diameter",
      "Antique gold finish",
      "Dual-sided design featuring OG logo and alternate logo",
      "Limited 5-year commemorative release",
      "Front of coin will have black outline around VGA Logo to make it pop",
      "Price includes postage anywhere within Australia where Australia Post operates. Image is a concept of the coin design and may differ slightly.",
    ],
    images: ["shop/5-year-coin-front", "shop/5-year-coin-back"],
    buyUrl: wix("vga-5yearcelebrationcoin"),
  },
];

/** Wix loyalty program as published on the previous /loyalty page (members-only feature of the old platform). */
export const loyaltyProgram = {
  steps: [
    { title: "Sign Up", body: "Sign up as a member to start enjoying the loyalty program" },
    { title: "Earn Points", body: "Order a plan: get 1,000 points. Purchase a product: get 1 point for every A$1 spent. Sign up to the site: get 50 points." },
    { title: "Redeem Rewards", body: "Flexible reward — 20 points = A$1 discount" },
  ],
};
