/**
 * Organisation-level facts. Every value here was taken from the previous public website
 * (www.veterangamingaustralia.org.au, crawled 5 Sep 2026) unless a "source" note says otherwise.
 */
export const site = {
  name: "Veteran Gaming Australia",
  shortName: "VGA",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.veterangamingaustralia.org.au",
  tagline: "Improving Veteran wellbeing through gaming.",
  description:
    "Founded in 2021, Veteran Gaming Australia’s mission is to develop a community around a shared love of gaming for current and ex-service Veterans and Veteran Families.",
  founded: 2021,
  // Home page (previous site)
  mission:
    "Founded in 2021, Veteran Gaming Australia’s mission is to develop a community around a shared love of gaming for current and ex-service Veterans and Veteran Families. Our aim is to improve veteran wellbeing and decrease reasons for isolation, hardship and health issues experienced by members of our community.",
  intro: "Veteran Gaming Australia gives Veterans an outlet for fun, a sense of belonging and an exciting community environment.",
  freeServices: "Veteran Gaming Australia offers free support services, programs, and activities to registered participants.",
  // Contact page / footer
  email: "enquiries@veterangamingaustralia.org.au",
  // Charity status: the previous site displayed the ACNC "Registered Charity" tick. No ABN or DGR statement was published — see MIGRATION-REVIEW.md.
  charityStatement: "ACNC Registered Charity",
  // 100% volunteer run — VGA newsletter (Aug 2026) and 5 Years in the Game report (Apr 2026)
  volunteerRun: "Veteran Gaming Australia is 100% volunteer run and led.",
  copyrightHolder: "Veteran Gaming Australia",
  designCredit: { label: "Previous site designed by Wicked Web", url: "https://www.wickedweb.digital/" },
  // Verified from the previous site's footer social bar and page links
  socials: {
    discord: "https://discord.gg/veterangamingaustralia",
    facebook: "https://www.facebook.com/VeteranGamingAustralia",
    facebookGroup: "https://www.facebook.com/groups/veterangamingaus",
    instagram: "https://www.instagram.com/veterangamingaustralia/",
    youtube: "https://www.youtube.com/channel/UC3uQeXOl-Ob3mvHu3WDRfNw",
    twitch: "https://www.twitch.tv/veterangamingaus",
    patreon: "https://www.patreon.com/veterangamingaustralia",
  },
  /**
   * DECISION REQUIRED: the previous site took donations through Wix's built-in donation app.
   * That app cannot be moved to this site. Until VGA nominates a donation provider, the
   * Donate buttons send people to the existing Wix donation page so no donation path is lost.
   */
  donateUrl: process.env.NEXT_PUBLIC_DONATE_URL ?? "https://www.veterangamingaustralia.org.au/donate",
  /** Live raffle published in the Aug 2026 newsletter */
  raffleUrl: "https://www.raffletix.com.au/newgamingpcraffle2026",
  /** The previous Wix store (checkout) — see data/shop.ts */
  shopUrl: process.env.NEXT_PUBLIC_SHOP_URL ?? "https://www.veterangamingaustralia.org.au/shop",
  /**
   * DECISION REQUIRED: sponsorship packages were sold through Wix Pricing Plans ("Buy Now" → Wix checkout).
   * Until VGA nominates a payment path, "Purchase online" points at the existing plans page; enquiries go to the contact form.
   */
  sponsorCheckoutUrl: process.env.NEXT_PUBLIC_SPONSOR_CHECKOUT_URL ?? "https://www.veterangamingaustralia.org.au/pricing-plans/list",
  locale: "en-AU",
  timezone: "Australia/Brisbane",
} as const;

export type SocialKey = keyof typeof site.socials;
