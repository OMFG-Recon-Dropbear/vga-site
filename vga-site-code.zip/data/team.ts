import type { ImageKey } from "./generated/images";

/**
 * Team directory — names, roles, summaries and biographies exactly as published on the previous
 * site's Our Team page and the three individual profile pages (Samuel Harris, Warren Campbell,
 * Hamish Taylor). Nobody has been added, and no biography has been written that was not published.
 */
export type TeamGroup = "board" | "ambassador" | "state-rep" | "operations";

export type TeamMember = {
  slug: string;
  name: string;
  role: string;
  group: TeamGroup;
  image?: ImageKey;
  summary?: string; // short blurb from the team page
  bio?: string; // long biography from the profile page
  region?: string;
  comingSoon?: boolean;
};

export const team: TeamMember[] = [
  {
    slug: "samuel-harris",
    name: "Samuel Harris",
    role: "Founder | CEO",
    group: "board",
    image: "team/samuel-harris",
    summary:
      "Sam holds a Diploma of Business Management, Justice Administration & E-Sports Coaching, gaining important fundamentals on business operations and advanced his coaching skillsets in E-Sports.",
    bio: "Samuel is a former Army Supply Chain Specialist Corporal, having spent 14 years in the Australian Defence Force. He holds a Diploma of Business Management, Justice Administration & E-Sports Coaching which has taught him important fundamentals on business operations and advanced his coaching skillsets in E-Sports. In 2013 & 2016, he deployed to the UAE/Afghanistan on Force Support Element 1 and Special Operations Logistic Node. Throughout that time he utilized gaming and initiated for technological means to be implemented to assist veterans social and emotional well-being while deployed as the welfare assistance officer. He is an avid mental health advocate and gamer with over a decade of experience in personnel and business management. Samuel is a firm believer in the power of gaming to help in developing social and emotional connections and enhancing mental health through a fun and supportive community. His prior charity work experience with Oxfam Australia, veteran welfare and belief in the power of gaming helped in the foundation of Veteran Gaming Australia.",
  },
  {
    slug: "warren-campbell",
    name: "Warren Campbell",
    role: "Director | Secretary",
    group: "board",
    image: "team/warren-campbell",
    summary:
      "Warren utilises gaming as a way to interact from home as a method to help socialise amongst work & life commitments. As Rabbits260 he chats while playing games.",
    bio: "Warren served in the Australian Regimental Army both in reserves and full-time capacity. He runs his own mechanical & diesel repairs business. He lives a bit country side where he lives with his wife & lots of animals on his lovely estate. He primarily loves gaming as a way to interact from home as a method to help socialise amongst work & life commitments. You will often find Warren aka Rabbits260 in the chat chilling while playing games, he loves to meet new people and hear about their stories. He is a large advocate for VGA in how it is bringing together Veterans and the public communities together through gaming and social nights while utilising new concepts and platforms throughout. He is firm believer in the health benefits that a fun & inclusive community like VGA brings to all involved. He hopes to bring more wider events to both Veterans and the public in helping further educate the public on Veterans.",
  },
  {
    slug: "hamish-taylor",
    name: "Hamish Taylor",
    role: "Director | Treasurer",
    group: "board",
    image: "team/hamish-taylor",
    summary:
      "Hamish completed his Bach of Teaching by distance in his final years of Army service and has since upskilled with a post graduate certificate in Career Development.",
    bio: "Hamish Taylor is currently in the NSW education system. Enlisted as a 47th class apprentice in 1992 and holding various roles within the Fulltime Army, Public Service and finally finishing up as Reservist in 2005. He Finished his Bach of Teaching by distance in his final years of Army service. He has since upskilled with a post graduate certificate in Career Development and holds a Full-Time position as a Careers advisor in Albury. Throughout the years he has owned and operated several small businesses. Currently owns and operates an IT / Phone repair business in his spare time. Widowed father of 4 teenaged kids he has an understanding the importance of mateship. He is most definitely not an amazing gamer and has very little skills in that area, however, he just wants to be part of creating a place that everyone feels safe and welcome. A firm believer in paying it forward and supporting those that have support him. Hamish's long term goals are to get into Advocacy in order to continue to support the community.",
  },
  { slug: "john-fillingham", name: "John Fillingham", role: "VGA Ambassador", group: "ambassador", image: "team/john-fillingham" },
  { slug: "brendton-pearson", name: "Brendton Pearson", role: "ACT State Representative", group: "state-rep", region: "ACT", image: "team/brendton-pearson" },
  { slug: "chris-vanderstoel", name: "Chris Vanderstoel", role: "VIC State Representative", group: "state-rep", region: "VIC", image: "team/chris-vanderstoel" },
  { slug: "mark-faranda", name: "Mark Faranda", role: "SA State Representative", group: "state-rep", region: "SA", image: "team/mark-faranda" },
  { slug: "matt-woodhead", name: "Matt Woodhead", role: "WA State Representative", group: "state-rep", region: "WA", image: "team/matt-woodhead" },
  { slug: "james-mcfarlane", name: "James McFarlane", role: "NT State Rep", group: "state-rep", region: "NT", image: "team/james-mcfarlane" },
  { slug: "amanda-gray", name: "Amanda Gray", role: "Sunshine Coast Rep", group: "state-rep", region: "QLD — Sunshine Coast", image: "team/amanda-gray" },
  { slug: "jeffrey-arnold", name: "Jeffrey Arnold", role: "NSW Nowra Coordinator", group: "state-rep", region: "NSW — Nowra", image: "team/jeffrey-arnold" },
  { slug: "cairns-rep", name: "Coming Soon", role: "Cairns Rep", group: "state-rep", region: "QLD — Cairns", comingSoon: true },
  { slug: "grace-campbell", name: "Grace Campbell", role: "Content Manager", group: "operations", image: "team/grace-campbell" },
  { slug: "sarah-wilson", name: "Sarah Wilson", role: "Discord Manager", group: "operations" },
];

export const teamGroups: { key: TeamGroup; title: string; blurb: string }[] = [
  { key: "board", title: "Board & Leadership", blurb: "VGA’s Board of Directors is made up entirely of Veterans, bringing together expertise across gaming, content creation, finance, governance and business management." },
  { key: "ambassador", title: "Ambassadors", blurb: "" },
  { key: "state-rep", title: "State & Regional Representatives", blurb: "Your local point of contact for VGA activities across the states and territories." },
  { key: "operations", title: "Community & Operations Team", blurb: "" },
];

export const volunteerThanks =
  "Thank you to all our volunteers who help significantly from our board members, event coordinators to veteran welfare leads. Your passion and drive to help Veterans and their families with a community they can call home is amazing.";

/** From the 5 Years in the Game report (Apr 2026) */
export const volunteerWorkforce =
  "Our hardworking 100% volunteer team keeps the mission moving every single day in support of our Veterans and their families. With a team of over 60 volunteers, spanning our board, managers, state representatives, and team members, through to our digital operations including Padres, server admins, game managers, Discord team members, and our esports and competitive teams, there is always something happening behind the scenes.";

export const boardStatement =
  "Veteran Gaming Australia’s Board of Directors is made up entirely of Veterans, bringing together a diverse range of professional expertise across gaming, content creation, finance, governance, and business management. This breadth of experience ensures strong strategic oversight while remaining grounded in the realities of the community we serve. What sets the Board apart is not just professional capability, but the depth of lived experience each member carries.";
