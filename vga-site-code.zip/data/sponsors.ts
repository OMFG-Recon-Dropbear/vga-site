import type { ImageKey } from "./generated/images";

/**
 * Sponsors by year — logos, tiers, thresholds and links exactly as published on the previous site's
 * Sponsors pages (2022–2026). Where the 2026 page showed a logo without a link, the link published
 * for the same organisation on the 2025 page is reused (same organisation, same verified URL).
 * Organisations that never had a link on the previous site are shown without one.
 */
export type Sponsor = { name: string; image: ImageKey; url?: string };
export type SponsorTier = { name: string; threshold?: string; sponsors: Sponsor[] };
export type SponsorYear = {
  year: number;
  title: string;
  intro: string;
  grants?: string;
  thresholds: { tier: string; amount: string }[];
  tiers: SponsorTier[];
};

const URLS = {
  dva: "https://www.dva.gov.au/",
  vic: "https://www.vic.gov.au/anzac-day-proceeds-fund",
  fpc: "https://www.fpconsulting.com.au/",
  rsllifecare: "https://rsllifecare.org.au/veteran-services/",
  campbells: "https://www.campbellscustomcomputers.com.au/",
  arcup: "https://www.arcup.com.au/",
  xbox: "https://www.xbox.com/en-AU",
  avcc: "https://aussieveteranscoffee.com.au/",
  zilor: "https://www.zilorgroup.com.au/",
  kozco: "https://1komma5.com/au/",
  zsu: "https://zsu.gg/",
  ash: "https://aussieserverhosts.com/",
  tfk: "https://www.taskforcekoala.com.au/",
  wickedweb: "https://www.wickedweb.digital/",
};

export const sponsorYears: SponsorYear[] = [
  {
    year: 2026,
    title: "Sponsors 2026",
    intro:
      "Thank you to these Legends in 2026 that have kindly provided grants, sponsored, donated equipment, care packages and/or monetary donations to greatly assist our mission in enhancing Veterans and Veteran Families social connections, health and wellbeing.",
    grants:
      "We were successful for a DVA Veteran Wellbeing Grant and Northern Territory Government Veteran Community grant in supporting our wellbeing initiatives for Veterans and Veteran Families.",
    thresholds: [
      { tier: "Elite", amount: "$8000+" },
      { tier: "Hardcore", amount: "$5000+" },
      { tier: "Core", amount: "$2000+" },
    ],
    tiers: [
      {
        name: "Elite Sponsors",
        sponsors: [
          { name: "Australian Government Department of Veterans’ Affairs", image: "sponsors/dva", url: URLS.dva },
          { name: "RSL LifeCare", image: "sponsors/rsl-lifecare", url: URLS.rsllifecare },
          { name: "Northern Territory Government", image: "sponsors/nt-government" },
          { name: "Campbell’s Custom Computers", image: "sponsors/campbells-custom-computers-2026", url: URLS.campbells },
        ],
      },
      { name: "Core Sponsors", sponsors: [{ name: "Arc Up Energy Company", image: "sponsors/arc-up-energy-2026", url: URLS.arcup }] },
      {
        name: "Digital Sponsors",
        sponsors: [
          { name: "Wicked Web Digital", image: "sponsors/wicked-web-digital", url: URLS.wickedweb },
          { name: "ZSU", image: "sponsors/zsu", url: URLS.zsu },
          { name: "Aussie Server Hosts", image: "sponsors/aussie-server-hosts", url: URLS.ash },
          { name: "Task Force Koala", image: "sponsors/task-force-koala", url: URLS.tfk },
          { name: "Chimera", image: "sponsors/chimera" },
        ],
      },
      {
        name: "Social Events & Sporting Partners",
        sponsors: [
          { name: "Invictus Australia", image: "sponsors/invictus-australia" },
          { name: "Aussie Veterans Coffee Co", image: "sponsors/aussie-veterans-coffee-co", url: URLS.avcc },
        ],
      },
    ],
  },
  {
    year: 2025,
    title: "Sponsors 2025",
    intro:
      "Thank you to these Legends in 2025 that have kindly provided grants, sponsored, donated equipment, care packages and/or monetary donations to greatly assist our mission in enhancing Veterans and Veteran Families social connections, health and wellbeing.",
    grants:
      "We were successful for a DVA Veteran Wellbeing Grant and Victoria State Government-Victorian Veterans Council Anzac Day Proceeds Fund grant in supporting our wellbeing initiatives for Veterans and Veteran Families.",
    thresholds: [
      { tier: "Elite", amount: "$8000+" },
      { tier: "Hardcore", amount: "$5000+" },
      { tier: "Core", amount: "$2000+" },
      { tier: "Casual", amount: "$1000+" },
    ],
    tiers: [
      {
        name: "Elite Sponsors",
        sponsors: [
          { name: "Australian Government Department of Veterans’ Affairs", image: "sponsors/dva", url: URLS.dva },
          { name: "Victorian Veterans Council — Victoria State Government", image: "sponsors/victorian-veterans-council", url: URLS.vic },
          { name: "First Person Consulting", image: "sponsors/first-person-consulting", url: URLS.fpc },
          { name: "RSL LifeCare", image: "sponsors/rsl-lifecare-2025", url: URLS.rsllifecare },
        ],
      },
      {
        name: "Hardcore Sponsors",
        sponsors: [
          { name: "Campbell’s Custom Computers", image: "sponsors/campbells-custom-computers", url: URLS.campbells },
          { name: "Arc Up Energy Company", image: "sponsors/arc-up-energy", url: URLS.arcup },
          { name: "Xbox", image: "sponsors/xbox", url: URLS.xbox },
        ],
      },
      {
        name: "Core Sponsors",
        sponsors: [
          { name: "Aussie Veterans Coffee Co", image: "sponsors/aussie-veterans-coffee-co", url: URLS.avcc },
          { name: "Zilor Group", image: "sponsors/zilor-group", url: URLS.zilor },
          { name: "Kozco Energy Group (1KOMMA5°)", image: "sponsors/kozco-energy-group", url: URLS.kozco },
        ],
      },
      { name: "Casual Sponsors", sponsors: [{ name: "3GEN Building Consultants", image: "sponsors/3gen-building-consultants" }] },
      {
        name: "Digital Sponsors",
        sponsors: [
          { name: "ZSU", image: "sponsors/zsu", url: URLS.zsu },
          { name: "Aussie Server Hosts", image: "sponsors/aussie-server-hosts", url: URLS.ash },
          { name: "Task Force Koala", image: "sponsors/task-force-koala", url: URLS.tfk },
          { name: "Wicked Web Digital", image: "sponsors/wicked-web-digital", url: URLS.wickedweb },
        ],
      },
    ],
  },
  {
    year: 2024,
    title: "Legends 2024",
    intro:
      "Thank you to these Legends in 2024 that have kindly provided grants, sponsored, donated equipment, care packages and/or monetary donations to greatly assist our mission in enhancing Veterans and Veteran Families social connections, health and wellbeing.",
    grants:
      "We were successful for a DVA Veteran Wellbeing Grants Program and Queensland Government Gambling Community Benefit Fund grant in supporting our wellbeing initiatives for Veterans and Veteran Families.",
    thresholds: [
      { tier: "Legendary Sponsor", amount: "$8,000+" },
      { tier: "Major Sponsor", amount: "$5,000+" },
      { tier: "Minor Sponsor", amount: "$2,000+" },
      { tier: "Base Sponsor", amount: "$1,000+" },
    ],
    tiers: [
      {
        name: "Legend Sponsors",
        sponsors: [
          { name: "Australian Government Department of Veterans’ Affairs", image: "sponsors/dva", url: URLS.dva },
          { name: "Queensland Government", image: "sponsors/queensland-government" },
        ],
      },
      {
        name: "Major Sponsors",
        sponsors: [
          { name: "Arc Up Energy Company", image: "sponsors/arc-up-energy-2024", url: URLS.arcup },
          { name: "Campbell’s Custom Computers", image: "sponsors/campbells-custom-computers", url: URLS.campbells },
        ],
      },
      {
        name: "Minor Sponsors",
        sponsors: [
          { name: "Xbox", image: "sponsors/xbox", url: URLS.xbox },
          { name: "Kozco Energy Group (1KOMMA5°)", image: "sponsors/kozco-energy-group", url: URLS.kozco },
          { name: "Aussie Veterans Coffee Co", image: "sponsors/aussie-veterans-coffee-co", url: URLS.avcc },
        ],
      },
      { name: "Base Sponsors", sponsors: [{ name: "3GEN Building Consultants", image: "sponsors/3gen-building-consultants" }] },
    ],
  },
  {
    year: 2023,
    title: "Legends 2023",
    intro: "Thank you to these Legends in 2023 that have kindly sponsored, donated equipment, care packages and monetary donations to greatly assist our Veterans.",
    thresholds: [
      { tier: "Legendary Status", amount: "$7,001+" },
      { tier: "Elite Status", amount: "$5,001 – $7,000" },
      { tier: "Rare Status", amount: "$3,001 – $5,000" },
      { tier: "Base Status", amount: "$1,000 – $3,000" },
    ],
    tiers: [
      {
        name: "Legend Sponsors",
        sponsors: [
          { name: "Arc Up Energy Company", image: "sponsors/arc-up-energy", url: URLS.arcup },
          { name: "Campbell’s Mechanical Technician Services (CMTS)", image: "sponsors/cmts" },
        ],
      },
      { name: "Major Sponsors", sponsors: [{ name: "Logitech G", image: "sponsors/logitech-g" }] },
      { name: "Minor Sponsors", sponsors: [{ name: "Aussie Veterans Coffee Co", image: "sponsors/aussie-veterans-coffee-co", url: URLS.avcc }] },
      {
        name: "Base Sponsors",
        sponsors: [
          { name: "Frontline Hospitality Recruitment", image: "sponsors/frontline-hospitality-recruitment" },
          { name: "Homefront", image: "sponsors/homefront" },
        ],
      },
    ],
  },
  {
    year: 2022,
    title: "Sponsors 2022",
    intro: "These are the Legends in 2022 that have kindly sponsored, donated equipment, care packages and monetary donations to greatly assist our Veterans. Thank you.",
    thresholds: [
      { tier: "Legendary Status", amount: "$15,001+" },
      { tier: "Elite Status", amount: "$9,001 – $15,000" },
      { tier: "Rare Status", amount: "$5,001 – $9,000" },
      { tier: "Base Status", amount: "$1,000 – $5,000" },
    ],
    tiers: [
      {
        name: "Base Sponsors",
        sponsors: [
          { name: "Peanut VR", image: "sponsors/peanut-vr" },
          { name: "Gold Coast Polishing", image: "sponsors/gold-coast-polishing" },
          { name: "Young Veterans", image: "sponsors/young-veterans" },
          { name: "Brisbane Lions", image: "sponsors/brisbane-lions" },
        ],
      },
    ],
  },
];

export const currentSponsorYear = sponsorYears[0];

/** Sponsorship packages as published on the previous "Support Us" (pricing plans) page. */
export const sponsorshipPlans = [
  { name: "Casual Sponsor", price: "A$1,000", validity: "Valid for 12 months", benefits: ["Social media posts (2 times yearly)", "Logo on our Legends Wall", "Digital sponsorship badge for socials", "Listed on Legends wall page"] },
  { name: "Core Sponsor", price: "A$2,000", validity: "Valid for 12 months", benefits: ["Social media posts (2 times yearly)", "Logo on our Legends Wall", "Small logo on Sim Cars", "Digital sponsorship badge for socials", "Listed on Legends wall page"] },
  { name: "Hard Core Sponsor", price: "A$5,000", validity: "Valid for 12 months", benefits: ["Social media posts (2 times yearly)", "Logo on our Legends Wall", "Medium logo on Sim Cars", "Digital sponsorship badge for socials", "Listed on Legends wall page"] },
  { name: "Elite Sponsor", price: "A$8,000", validity: "Valid for 12 months", benefits: ["All Gold sponsor benefits", "Logo on Twitch startup screen", "Your business flyer at select VGA events", "Article on VGA website"] },
];
