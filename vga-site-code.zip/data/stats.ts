/**
 * Impact statistics. Each figure carries its published source so the site never drifts from
 * what VGA has actually said. Where the previous site published two different figures, the most
 * recent published figure is used and the older one is listed in MIGRATION-REVIEW.md.
 */
export type Stat = {
  value: number;
  suffix?: string;
  prefix?: string;
  label: string;
  detail?: string;
  source: string;
  asOf: string; // ISO date of the source publication
};

export const headlineStats: Stat[] = [
  {
    value: 46000,
    suffix: "+",
    label: "Veterans & families supported",
    detail: "Through community programs, stakeholder and collaborative events since 2021.",
    source: "Donate page impact graphic; 'Celebrating 5 Years of Impact' (Apr 2026); 5 Years in the Game report",
    asOf: "2026-04-30",
  },
  {
    value: 700,
    suffix: "+",
    label: "Events & activities",
    detail: "Hundreds of physical and digital events have created opportunities for Veterans and families to connect.",
    source: "Donate page impact graphic; About Us ('over 700 community events')",
    asOf: "2026-08-16",
  },
  {
    value: 50000,
    prefix: "$",
    suffix: "+",
    label: "In care packages & support",
    detail: "Provided to Veterans and families experiencing hardship, illness and challenging circumstances.",
    source: "Donate page impact graphic; About Us",
    asOf: "2026-08-16",
  },
  {
    value: 19,
    label: "Gaming & esports hubs",
    detail: "Social gaming and esports hubs on Defence bases, in Veteran wellbeing centres, RSLs and hospitals.",
    source: "Gaming Hubs map (19 pins); 5 Years in the Game report ('over 19')",
    asOf: "2026-08-16",
  },
  {
    value: 10000,
    suffix: "+",
    label: "Volunteer hours",
    detail: "VGA is 100% volunteer run and led, with a team of over 60 volunteers.",
    source: "About Us; 5 Years in the Game report",
    asOf: "2026-08-16",
  },
  {
    value: 70,
    suffix: "+",
    label: "Hours of voice chat every week",
    detail: "On average, more than 70 hours of voice conversation and 1,000+ messages a week across VGA's Discord.",
    source: "Donate page impact graphic; Aug 2026 newsletter",
    asOf: "2026-08-07",
  },
];

/** Independent evaluation (First Person Consulting, published 4 Mar 2026) */
export const evaluationStats: Stat[] = [
  { value: 98, suffix: "%", label: "rated Social Connection Events very or extremely enjoyable", source: "Independent evaluation, Mar 2026", asOf: "2026-03-04" },
  { value: 68, suffix: "%", label: "felt very or extremely connected after events — up from 18% before", source: "Independent evaluation, Mar 2026", asOf: "2026-03-04" },
  { value: 100, suffix: "%", label: "of Esports Hub participants reported high enjoyment", source: "Independent evaluation, Mar 2026", asOf: "2026-03-04" },
  { value: 73, suffix: "%", label: "of Esports League participants rated their experience 8–10 out of 10", source: "Independent evaluation, Mar 2026", asOf: "2026-03-04" },
  { value: 63, suffix: "%", label: "felt very or extremely confident maintaining connections after the event", source: "Independent evaluation, Mar 2026", asOf: "2026-03-04" },
  { value: 7, label: "states and territories where evaluated activities were delivered", source: "Independent evaluation, Mar 2026", asOf: "2026-03-04" },
];

/** Digital Australia / Australia Plays research quoted by VGA (About Us page and 5-year report) */
export const researchStats = {
  digitalAustralia2023: {
    title: "Digital Australia 2023",
    by: "Interactive Games and Entertainment Association (IGEA), designed and conducted by Bond University",
    topReasons: ["have fun", "relax and de-stress", "pass time", "escape", "be challenged"],
    findings: [
      "89% of adults think games improve thinking skills for players of all ages",
      "81% of all Australians play video games",
      "91% say video games can create feelings of enjoyment",
      "84% say video games can stimulate the mind",
      "75% say video games can help manage stress",
      "66% say video games can nurture mental health",
      "61% say video games encourage social interaction",
      "33% made new friend(s) through video games",
    ],
  },
  australiaPlays2025: {
    title: "Australia Plays 2025",
    by: "Bond University and Interactive Games and Entertainment Association",
    findings: ["82% of all Australians play video games", "97% play to have fun", "95% play to relax and de-stress", "77% play with others"],
    source: "VGA 5 Years in the Game report (Apr 2026)",
  },
};
