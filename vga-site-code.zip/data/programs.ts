import type { ImageKey } from "./generated/images";

/**
 * Programs — text is drawn from the previous site's Programs, Home, About, Game Servers, Esports,
 * OVEL and Sim Racing pages, the May–August 2026 newsletter and VGA's "5 Years in the Game" report.
 * Fields are only filled where the source material provides them.
 */
export type ProgramLink = { label: string; href: string; external?: boolean };

export type Program = {
  slug: string;
  title: string;
  category: "Gaming Hubs" | "Esports" | "Online Community" | "Community Events" | "Care & Wellbeing" | "Creative Programs";
  short: string; // card blurb (as published)
  image: ImageKey;
  href: string; // where the card links
  whoFor?: string;
  howItWorks?: string[];
  howToParticipate?: string;
  links?: ProgramLink[];
  contact?: string;
  source: string;
};

export const programs: Program[] = [
  {
    slug: "gaming-hubs",
    title: "Retrofit — Social Gaming & Esports Hubs",
    category: "Gaming Hubs",
    short:
      "VGA is facilitating and donating social gaming and esports hubs, information & resources to Veteran hospitals and other Veteran organisations to reduce the reasons for isolation, hardship & health issues.",
    image: "programs/gaming-hub-pcs",
    href: "/gaming-hubs",
    whoFor: "Veterans and Veteran Families who use Defence bases, Veteran and Family Wellbeing Centres, RSLs, community spaces and hospitals where a hub has been installed.",
    howItWorks: [
      "Retrofit is about meeting Veterans where they already are — on-base, within a Veteran and Family Wellbeing Centre, at an RSL, or in a hospital setting.",
      "Each hub is designed to be simple, welcoming, and easy to use. With gaming consoles, screens, and shared spaces, they create an environment where conversation happens naturally.",
      "Gaming hubs have proven to be effective informal wellbeing spaces. They allow Veterans to connect without pressure, offering a shared activity that builds trust, familiarity, and a sense of belonging over time.",
    ],
    howToParticipate: "Use the map to find a hub near you, then contact the host venue about access. Venues host the hubs; VGA installs and supports them.",
    links: [{ label: "Find a gaming hub", href: "/gaming-hubs" }],
    source: "Programs page; Gaming Hubs page; 5 Years in the Game report",
  },
  {
    slug: "esports",
    title: "Esports & the Oceania Veteran Esports League",
    category: "Esports",
    short:
      "A structured and engaging pathway for Veterans and serving members to connect through teamwork, communication, and shared competition — including the Oceania Veteran Esports League (OVEL), Call of Duty and sim racing.",
    image: "esports/team-vga-banner",
    href: "/esports",
    whoFor: "Veterans who served in the Australian Defence Force, Coalition Nation Veterans who reside in Australia and Veterans who served in an Oceania region military (OVEL eligibility as published). All skill levels welcome.",
    howItWorks: [
      "While social gaming is often the first step, esports offers an opportunity to build on that connection in a more focused and team-driven environment.",
      "The Oceania Veteran Esports League (OVEL) brings together teams from across Australia and the broader region.",
      "Beyond national competition, VGA has had teams represented on the international stage through the World Military Esports League, competing across titles including F1 and Call of Duty.",
    ],
    howToParticipate: "Register your interest through the VGA Discord — league registrations and rosters are managed there.",
    links: [
      { label: "Esports overview", href: "/esports" },
      { label: "OVEL — rules, format and standings", href: "/esports/ovel" },
      { label: "Sim racing", href: "/esports/sim-racing" },
    ],
    source: "Esports Teams page; OVEL page; Sim Racing page; 5 Years in the Game report; Aug 2026 newsletter",
  },
  {
    slug: "game-servers",
    title: "24/7 Game Servers & Digital Socials",
    category: "Online Community",
    short:
      "We have a wide variety of 24/7 game servers available, plus regular Digital Social Game Nights so Veterans and Veteran Families can connect from wherever they are.",
    image: "community/discord-server",
    href: "/programs/game-servers",
    whoFor: "VGA members on Discord — jump in whenever it suits you.",
    howItWorks: [
      "Most of this happens through our Discord, where Veterans and families can jump in whenever it suits them. Some nights are organised Social Game Nights, others are just mates linking up for a few games.",
      "VGA maintains a growing range of 24/7 community game servers, giving Veterans and Veteran Families the ability to jump online, play together and connect with the community at a time that works for them.",
    ],
    howToParticipate:
      "Join our Discord and select the relevant game role to find the server details. If you get stuck, raise a support ticket and our team will help you.",
    links: [
      { label: "Join the VGA Discord", href: "https://discord.gg/veterangamingaustralia", external: true },
      { label: "Weekly schedule & servers", href: "/programs/game-servers" },
    ],
    source: "Game Servers page; Aug 2026 newsletter; 5 Years in the Game report",
  },
  {
    slug: "events",
    title: "Community Events",
    category: "Community Events",
    short:
      "Fun Game Days, Movie Outings, STEM educational sessions, Social BBQs. These are just some of the fun activities you will see at our physical events.",
    image: "news/vga-social-event-stadium",
    href: "/events",
    whoFor: "Veterans and Veteran Families — many events are family-inclusive.",
    howItWorks: [
      "Due to our events being in high demand and some even being fully booked in 15 minutes of listings, we often only advertise on our public Facebook and Discord.",
      "Over the last 12 months VGA delivered more than 40 family-inclusive, in-person social connection events (July 2026).",
    ],
    howToParticipate: "Follow the VGA Facebook page and join the Discord to see events as they are listed and RSVP.",
    links: [
      { label: "Events", href: "/events" },
      { label: "VGA on Facebook", href: "https://www.facebook.com/VeteranGamingAustralia", external: true },
    ],
    source: "Programs page; Home page; 'Disappointed following unsuccessful DVA grant' (Jul 2026)",
  },
  {
    slug: "tournaments",
    title: "Tournaments",
    category: "Esports",
    short: "Tournaments are competitive events in which Veterans compete in specific games for the title of top team.",
    image: "programs/esports-arena",
    href: "/esports",
    howItWorks: [
      "Our tournaments bring Veterans together in high-stakes competition, fostering camaraderie, strategic thinking, and teamwork. Beyond the thrill of competing for the title of top team, these events provide a social space where Veterans can connect, communicate, and sharpen critical problem-solving skills.",
      "The competitive environment boosts self-confidence and creates exciting moments that are streamed on VGA and Veterans Twitch streams, increasing engagement and awareness. These tournaments not only offer cool gaming and tech prizes but also serve as doorways to future opportunities within the community.",
    ],
    links: [
      { label: "Esports & OVEL", href: "/esports" },
      { label: "VGA on Twitch", href: "https://www.twitch.tv/veterangamingaus", external: true },
    ],
    source: "Programs page; Home page",
  },
  {
    slug: "care-packages",
    title: "Care Packages",
    category: "Care & Wellbeing",
    short:
      "Gaming care packages sent to our Veterans at home and abroad on operations to ensure they can have fun and utilise as a healthy outlet to build or assist in re-building social and emotional connections, decompress & keep an active mind to prevent operational stress.",
    image: "programs/care-package-bundle",
    href: "/programs/care-packages",
    whoFor: "Veterans facing financial and/or health hardships — at home or deployed. Do you know a Veteran who deserves a care package?",
    howItWorks: [
      "Through the Care Package Program, we delivered over 100 care packages to Veterans and families across Australia. These packages have ranged from gaming PCs and consoles through to gift cards and 3D printed items, tailored to meet individual needs.",
      "The support provided has been tailored to the individual or family rather than taking a one-size-fits-all approach.",
    ],
    howToParticipate: "Nominate a Veteran by emailing enquiries@veterangamingaustralia.org.au or through the contact form.",
    links: [{ label: "Care package stories", href: "/news/category/news" }],
    contact: "enquiries@veterangamingaustralia.org.au",
    source: "Programs page; 5 Years in the Game report; Aug 2026 newsletter",
  },
  {
    slug: "hospital-loan-program",
    title: "Hospital Loan Program",
    category: "Care & Wellbeing",
    short:
      "Are you a Veteran having a surgery or checking into a Mental Health ward within the QLD, VIC or ACT region? We have a free device loan program for the period you are in hospital.",
    image: "programs/hospital-loan-devices",
    href: "/programs/hospital-loan-program",
    whoFor: "Veterans having surgery or checking into a mental health ward in the QLD, VIC or ACT region.",
    howItWorks: [
      "Free device loans including Nintendo Switch consoles with games and Kindles with e-books loaded. This helps bring entertainment, relaxation and learning to your hospital stay.",
      "We visited over 100 Veterans, often bringing chocolates, refreshments and other items on request of the Veteran. Through these visits, we often saw a lack of entertainment such as TVs and mobile phones, and this led to the creation of our free Hospital Loan Device program.",
    ],
    howToParticipate: "Contact VGA before or during your hospital stay.",
    contact: "enquiries@veterangamingaustralia.org.au",
    source: "Programs page; 5 Years in the Game report",
  },
  {
    slug: "air-assault",
    title: "Air Assault",
    category: "Community Events",
    short:
      "All expenses paid trip to Supanova, PAX Australia, Electronic Entertainment Expo, esports team meet & training sessions.",
    image: "programs/air-assault-poster",
    href: "/programs/air-assault",
    whoFor: "Open to all Australian Veterans, both serving and honourably discharged, who have a passion for gaming.",
    howItWorks: [
      "This is a great experience as it provides the opportunity to share their interests with other Veterans and that of industry professionals who support and admire them.",
      "We are looking for deserving Veterans who have a passion for gaming and would love to go along to events such as Supanova, PAX Australia, Electronic Entertainment Expo, esports team meet & training sessions.",
    ],
    howToParticipate: "If you have a great story of how you have served your Nation, nominate yourself or a mate through the contact form.",
    contact: "enquiries@veterangamingaustralia.org.au",
    source: "Programs page",
  },
  {
    slug: "creative-programs",
    title: "Miniature Painting & 3D Printing",
    category: "Creative Programs",
    short:
      "Pioneered Miniature Figurine Painting Therapy — a unique alternative therapy — with more than 70 sessions delivered, plus the first 3D printing workshop within an Australian Veteran hospital.",
    image: "news/air-space-power-centre",
    href: "/programs#creative-programs",
    howItWorks: [
      "Programs such as miniature figurine painting provide a creative and mindful outlet, helping Veterans relax, engage, and connect with others in a low-pressure environment.",
      "We also delivered the first 3D printing workshop within an Australian Veteran hospital, introducing a new and engaging activity that supports both creativity and skill development.",
    ],
    links: [
      { label: "Read: Our team at the Air, Space and Power Centre", href: "/news/our-team-at-air-space-and-power-centre" },
      { label: "3D printing basics guide", href: "/education/3d-printing" },
    ],
    source: "About Us page; 5 Years in the Game report",
  },
];

export const programCategories = Array.from(new Set(programs.map((p) => p.category)));

/** Weekly Digital Social schedule — VGA May–August 2026 newsletter */
export const digitalSocials: { day: string; sessions: { game: string; time: string; cadence: string }[] }[] = [
  { day: "Tuesday", sessions: [{ game: "Farming Simulator 25", time: "8:00pm AEST", cadence: "Weekly" }] },
  {
    day: "Wednesday",
    sessions: [
      { game: "Rocket League", time: "8:00pm AEST", cadence: "Weekly" },
      { game: "Over the Top", time: "8:30pm AEST", cadence: "Weekly" },
    ],
  },
  {
    day: "Thursday",
    sessions: [
      { game: "Arma Reforger Missions", time: "7:00pm AEST", cadence: "Weekly" },
      { game: "F1", time: "8:00pm AEST", cadence: "Weekly" },
    ],
  },
  {
    day: "Friday",
    sessions: [
      { game: "Ready or Not", time: "5:00pm AEST", cadence: "Weekly" },
      { game: "No Man's Sky", time: "7:30pm AEST", cadence: "Fortnightly" },
      { game: "Gray Zone Warfare", time: "8:00pm AEST", cadence: "Fortnightly" },
    ],
  },
  { day: "Saturday", sessions: [{ game: "Squad / Hell Let Loose", time: "8:30pm AEST", cadence: "Rotating" }] },
  { day: "Sunday", sessions: [{ game: "Arma Reforger Missions", time: "3:00pm AEST", cadence: "Weekly" }] },
];

/** 24/7 community game servers — Aug 2026 newsletter (list) and Game Servers page (logos) */
export const gameServers: { name: string; image?: ImageKey }[] = [
  { name: "Windrose", image: "servers/windrose" },
  { name: "Palworld" },
  { name: "StarRupture", image: "servers/starrupture" },
  { name: "RuneScape" },
  { name: "ARK: Survival Ascended", image: "servers/ark-survival-ascended" },
  { name: "Farming Simulator 25", image: "servers/farming-simulator-25" },
  { name: "Arma Reforger", image: "servers/arma-reforger" },
  { name: "Project Zomboid" },
  { name: "EVE Online" },
  { name: "DCS" },
];

/** Game logos that appeared on the previous Game Servers page but are not in the Aug 2026 server list */
export const legacyServerLogos: { name: string; image: ImageKey }[] = [
  { name: "DayZ", image: "servers/dayz" },
  { name: "Myth of Empires", image: "servers/myth-of-empires" },
];
