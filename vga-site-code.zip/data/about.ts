/**
 * About content — from the previous site's About Us page, the Home page and VGA's
 * "5 Years in the Game" impact report (April 2026). Quotations are verbatim.
 */
export const about = {
  metaDescription:
    "Founded in 2021, Veteran Gaming Australia (VGA) is dedicated to building a thriving community around gaming and geek culture for Veterans and their families.",
  intro: [
    "Founded in 2021, Veteran Gaming Australia (VGA) is dedicated to building a thriving community around gaming and geek culture for Veterans and their families.",
    "Our mission is to enhance Veteran-Family engagement and social connections through interactive and inclusive community platforms, reducing isolation, hardship, and health challenges within the Veteran and Family space.",
  ],
  missionStatement:
    "Our mission is to develop a community around a shared love of gaming for current and ex-service Veterans and Veteran Families. Our aim is to improve veteran and family wellbeing and decrease reasons for isolation, hardship and health issues experienced by members of our community.",
  founding:
    "Founded in 2021 by Veteran and gamer Samuel Harris, Veteran Gaming Australia connects current and ex-service ADF members and their families through gaming and geek culture, reducing isolation and strengthening community across the nation.",
  /** From the RSL Queensland article republished as "More than just a game" (Jun 2021) */
  origin:
    "The group was founded by Samuel Harris, an Army Corporal who works in Research, Investigation and Stocktaking as a Supply Chain Specialist, with the support of his founding members Cara Musk and Andrew Dubignon, who are both ex-serving. After launching in April 2021, VGA grew to 600 members in the first month and the numbers are still climbing.",
  whatWeDo: {
    hubs: "Gaming & Esports Hubs: We have facilitated, donated, and set up social gaming hubs at over 12 Veteran and Veteran Family support locations and established Esports Hubs at 3 venues, with more on the way.",
    communityImpact: [
      "Supported over 42,000 Veterans and Veteran Family members through our programs and growing.",
      "Provided over $50,000 worth of care packages to Veterans facing financial and/or health hardships.",
      "Pioneered Miniature Figurine Painting Therapy—a unique alternative therapy",
      "Hosted over 700 community events, including in-person and online social activities.",
      "Dedicated over 10,000 volunteer hours to supporting Veterans and their families.",
    ],
  },
  achievements: [
    "2024 Veterans, Emergency Services & Police Industry Institute of Australia (VESPIIA) Social Program of the Year Award Winner.",
    "First charity in Australia to receive a Mental Health Association grant for gaming & geek culture programs during QLD Mental Health Week.",
    "Strong national partnerships-networks with Veteran support organisations like Invictus Australia, RSLs, hospitals, social workers, education and employment pathways, and state government agencies.",
  ],
  /** Recognition from the 5 Years in the Game report and the July 2026 news post */
  recognition: [
    { year: "2024", text: "VGA was honoured with the Veterans, Emergency Services & Police Industry Institute of Australia Social Program of the Year Award." },
    { year: "2025", text: "Grace Campbell and Mark Faranda, two of our dedicated volunteers, were awarded Australia Day Medallions." },
    { year: "2026", text: "Founder and CEO Samuel Harris was recognised at the Queensland Suicide Prevention Awards for Priority Populations, in recognition of his leadership and Veteran Gaming Australia's work supporting Veteran and Family suicide prevention through innovative community programs." },
  ],
  belief:
    "At VGA, we believe that gaming and geek culture can be powerful tools for connection, well-being, and support. Whether through digital gaming, esports, tabletop and in-person social events, we continue to create spaces where Veterans and their families feel seen, supported, and empowered.",
  whyGaming: [
    "Throughout service in the Australian Defence Force, gaming and geek culture was one factor you could always rely on as a fun de-stressor and enjoyment. We have seen members come back from outside the wire and play Fifa even before showering, utilised on courses between mates and living in lines common rooms, members serving overseas playing games with their children back in Australia and the list goes on.",
    "Video games and geek culture, they are hours of entertainment, but importantly a way to help bring your mindstate back a level where needed and as a tool in helping connect you with family and mates.",
    "Another great aspect of gaming and geek culture is its accessible nature, for those carrying injuries/illnesses and those who might live in rural and remote communities to be able to connect.",
  ],
  ceoMessage: {
    name: "Samuel Harris",
    title: "Founder | CEO, Veteran Gaming Australia",
    date: "30 April 2026",
    quote:
      "Veteran Gaming Australia was never just about gaming. It was about creating fun and interactive spaces, both digital and physical, where Veterans and Families could show up as themselves, without judgement, and know they belong.",
    paragraphs: [
      "What began as a simple idea has grown into a national movement supporting tens of thousands of Veterans and their families across Australia. Over the past five years, we have seen firsthand the power of connection.",
      "We’ve seen Veterans and Families who were once isolated find their tribe again. We’ve seen families reconnect through shared experiences. We’ve seen individuals rebuild confidence, purpose, and identity, often starting with something as simple as picking up a controller and joining a game night.",
      "From over 800 social game nights, to national in-person events, esports leagues, hospital programs, and the rollout of social gaming and Esports hubs across the country, every initiative has been driven by one goal: strengthen connection and reduce isolation.",
      "We’ve remained community first. We’ve remained grounded in lived experience. We’ve built this alongside everyone in the community, not just for them.",
      "Five years in, we’re only just getting started, the mission continues and we’re levelling up our impact.",
    ],
  },
  values: "Community, Mateship, Fun, Fortitude",
  impactReportPdf: "/docs/vga-5-years-in-the-game-impact-report-2026.pdf",
  evaluationReportUrl: "https://1drv.ms/b/c/509c4084b185b367/IQD0Rs2emGZhTq5nL1ZY8nEAAeM5JmW0UX2fvQ3UqJqliHQ?e=SfRQVB",
  /** Milestones — each line is traceable to a published VGA page or post (see the source note). */
  timeline: [
    { year: "2021", text: "VGA launches in April 2021 and grows to 600 members in its first month. (RSL Queensland article, June 2021)" },
    { year: "2022", text: "The first sponsor wall (2022 Legends), Christmas celebrations across the community, and VGA featured in the NT Top Ender magazine." },
    { year: "2023", text: "Social gaming hubs open at the Riverina and Nowra Veteran Wellbeing Centres; care packages; Queensland Mental Health Week farm day; miniature painting at the Air, Space and Power Centre." },
    { year: "2024", text: "VESPIIA Social Program of the Year Award; Oz Comic-Con Brisbane; Veteran Health Week; 2024 care packages; Team VGA sim racing." },
    { year: "2025", text: "Oceania Veteran Esports League launches with Call of Duty: Black Ops 6; Australia Day Medallions for two VGA volunteers." },
    { year: "2026", text: "Five years of VGA: 46,000+ Veterans and families supported, independent evaluation published, OVEL Rocket League with 101 participants, and advocacy on the proposed DVA allied health changes." },
  ],
};
