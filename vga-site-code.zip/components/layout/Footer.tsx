import Link from "next/link";
import Image from "next/image";
import { site } from "@/data/site";
import { footerNav, ctaNav } from "@/data/navigation";
import { images } from "@/data/generated/images";
import { SocialLinks } from "./SocialLinks";
import { NewsletterForm } from "@/components/forms/NewsletterForm";
import { Icon } from "@/components/ui/Icon";

const logo = images["brand/vga-logo"];
const acnc = images["brand/acnc-registered-charity"];

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="relative mt-20 border-t border-ink-700/70 bg-ink-950">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-700/60 to-transparent" aria-hidden="true" />
      <div className="container grid gap-12 py-16 lg:grid-cols-[1.4fr_2fr] lg:gap-16">
        <div>
          <Link href="/" className="inline-flex items-center gap-4" aria-label={`${site.name} — home`}>
            <Image src={logo.src} width={logo.width} height={logo.height} alt="" className="h-20 w-auto" />
            <span className="font-display text-3xl font-bold uppercase leading-[0.9] text-ink-50">
              Veteran Gaming
              <span className="block text-lg font-semibold tracking-[0.22em] text-gold-500">Australia</span>
            </span>
          </Link>
          <p className="mt-6 max-w-md text-ink-200">{site.intro}</p>
          <p className="mt-3 max-w-md text-sm text-ink-300">{site.volunteerRun}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href={ctaNav.join.href} className="inline-flex items-center gap-2 font-display text-lg font-semibold uppercase tracking-wide text-gold-200 hover:text-gold-100">
              {ctaNav.join.label} <Icon name="arrow-right" className="h-4 w-4" />
            </Link>
            <span className="text-ink-600" aria-hidden="true">
              /
            </span>
            <a href={ctaNav.discord.href} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 font-display text-lg font-semibold uppercase tracking-wide text-gold-200 hover:text-gold-100">
              {ctaNav.discord.label} <Icon name="external" className="h-4 w-4" />
            </a>
          </div>
          <SocialLinks className="mt-6" />
        </div>

        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {footerNav.map((col) => (
            <div key={col.heading}>
              <h2 className="font-display text-base font-semibold uppercase tracking-[0.18em] text-gold-500">{col.heading}</h2>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-ink-200 transition hover:text-gold-200">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t border-ink-800">
        <div className="container grid gap-10 py-10 lg:grid-cols-[1.4fr_2fr] lg:gap-16">
          <div className="flex items-start gap-4">
            <Image src={acnc.src} width={acnc.width} height={acnc.height} alt={acnc.alt} className="h-16 w-16 shrink-0" />
            <div className="text-sm text-ink-300">
              <p className="font-semibold text-ink-100">{site.charityStatement}</p>
              <p className="mt-1">
                Contact:{" "}
                <a href={`mailto:${site.email}`} className="break-all text-gold-200 hover:text-gold-100">
                  {site.email}
                </a>
              </p>
            </div>
          </div>
          <div>
            <h2 className="font-display text-base font-semibold uppercase tracking-[0.18em] text-gold-500">Newsletter</h2>
            <p className="mt-2 text-sm text-ink-300">Subscribe for VGA updates, events and community news.</p>
            <NewsletterForm compact />
          </div>
        </div>
      </div>

      <div className="border-t border-ink-800">
        <div className="container flex flex-col gap-3 py-6 text-xs text-ink-400 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {site.copyrightHolder}. All rights reserved.
          </p>
          <ul className="flex flex-wrap gap-x-5 gap-y-2">
            <li>
              <Link href="/privacy-policy" className="hover:text-gold-200">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link href="/contact" className="hover:text-gold-200">
                Contact
              </Link>
            </li>
            <li>
              <Link href="/sitemap.xml" className="hover:text-gold-200">
                Sitemap
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
