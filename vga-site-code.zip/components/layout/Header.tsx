"use client";

import Link from "next/link";
import Image from "next/image";
import { useCallback, useEffect, useId, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { mainNav, ctaNav } from "@/data/navigation";
import { site } from "@/data/site";
import { images } from "@/data/generated/images";
import { cn } from "@/lib/utils";
import { Icon } from "@/components/ui/Icon";
import { Button } from "@/components/ui/Button";
import { SocialLinks } from "./SocialLinks";

const logo = images["brand/vga-logo-mark"];

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState<string | null>(null); // desktop mega menu group label
  const [mobile, setMobile] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const navRef = useRef<HTMLDivElement>(null);
  const closeTimer = useRef<number | null>(null);

  // Close menus on route change
  useEffect(() => {
    setOpen(null);
    setMobile(false);
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Escape + outside click close the desktop panel
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
    };
    const onClick = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) setOpen(null);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick);
    };
  }, [open]);

  // Lock scroll for mobile drawer
  useEffect(() => {
    document.documentElement.style.overflow = mobile ? "hidden" : "";
    return () => {
      document.documentElement.style.overflow = "";
    };
  }, [mobile]);

  const scheduleClose = useCallback(() => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
    closeTimer.current = window.setTimeout(() => setOpen(null), 160);
  }, []);
  const cancelClose = useCallback(() => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
  }, []);

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <header className={cn("sticky top-0 z-50 border-b transition-colors duration-300", scrolled || open || mobile ? "border-ink-700/80 bg-ink-900/95" : "border-transparent bg-ink-900/70")}>
      {/* Backdrop blur lives on a pseudo-layer: a backdrop-filter on the header itself would become the containing block
          for the fixed mobile drawer (and collapse it to the header's height). */}
      <div aria-hidden="true" className={cn("pointer-events-none absolute inset-0 -z-10", scrolled || open || mobile ? "backdrop-blur-md" : "backdrop-blur-sm")} />
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-3 focus:z-[60] focus:rounded focus:bg-gold-500 focus:px-4 focus:py-2 focus:font-semibold focus:text-ink-950">
        Skip to content
      </a>
      <div className="container flex h-[var(--header-h)] items-center justify-between gap-4">
        <Link href="/" className="flex shrink-0 items-center gap-3" aria-label={`${site.name} — home`}>
          <Image src={logo.src} width={logo.width} height={logo.height} alt="" priority className="h-11 w-auto sm:h-12" />
          <span className="hidden font-display text-[1.35rem] font-bold uppercase leading-[0.9] tracking-wide text-ink-50 xs:block">
            Veteran Gaming
            <span className="block text-[0.95rem] font-semibold tracking-[0.22em] text-gold-500">Australia</span>
          </span>
        </Link>

        {/* Desktop navigation */}
        <div ref={navRef} className="hidden items-center lg:flex" onMouseLeave={scheduleClose} onMouseEnter={cancelClose}>
          <nav aria-label="Primary">
            <ul className="flex items-center gap-1">
              {mainNav.map((group) => {
                const hasPanel = !!group.items?.length;
                const active = isActive(group.href);
                return (
                  <li key={group.label} className="relative" onMouseEnter={() => hasPanel && setOpen(group.label)}>
                    {hasPanel ? (
                      <button
                        type="button"
                        className={cn(
                          "flex items-center gap-1 rounded px-3 py-2 font-display text-[1.05rem] font-semibold uppercase tracking-[0.08em] transition",
                          active || open === group.label ? "text-gold-200" : "text-ink-100 hover:text-gold-200"
                        )}
                        aria-expanded={open === group.label}
                        aria-controls={`menu-${group.label}`}
                        onClick={() => setOpen(open === group.label ? null : group.label)}
                      >
                        {group.label}
                        <Icon name="chevron-down" className={cn("h-4 w-4 transition-transform", open === group.label ? "rotate-180" : "")} />
                      </button>
                    ) : (
                      <Link
                        href={group.href}
                        className={cn("block rounded px-3 py-2 font-display text-[1.05rem] font-semibold uppercase tracking-[0.08em] transition", active ? "text-gold-200" : "text-ink-100 hover:text-gold-200")}
                        aria-current={active ? "page" : undefined}
                      >
                        {group.label}
                      </Link>
                    )}
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* Mega panel */}
          {mainNav.map((group) =>
            group.items?.length ? (
              <div
                key={group.label}
                id={`menu-${group.label}`}
                hidden={open !== group.label}
                className="absolute left-0 right-0 top-full border-b border-ink-700 bg-ink-900 shadow-[0_30px_60px_-30px_rgba(0,0,0,0.8)]"
              >
                <div className="container grid gap-8 py-8 lg:grid-cols-[1fr_1fr_20rem]">
                  <ul className="grid gap-1 lg:col-span-2 lg:grid-cols-2">
                    {group.items.map((item) => (
                      <li key={item.href}>
                        {item.external ? (
                          <a href={item.href} target="_blank" rel="noopener noreferrer" className="group block rounded-md px-3 py-3 transition hover:bg-ink-800">
                            <span className="flex items-center gap-2 font-display text-lg font-semibold uppercase tracking-wide text-ink-50 group-hover:text-gold-200">
                              {item.label}
                              <Icon name="external" className="h-4 w-4 text-ink-400" />
                            </span>
                            {item.description ? <span className="mt-0.5 block text-sm text-ink-300">{item.description}</span> : null}
                          </a>
                        ) : (
                          <Link href={item.href} className="group block rounded-md px-3 py-3 transition hover:bg-ink-800">
                            <span className="font-display text-lg font-semibold uppercase tracking-wide text-ink-50 group-hover:text-gold-200">{item.label}</span>
                            {item.description ? <span className="mt-0.5 block text-sm text-ink-300">{item.description}</span> : null}
                          </Link>
                        )}
                      </li>
                    ))}
                  </ul>
                  {group.featured ? (
                    <div className="chamfer-frame self-start">
                      <div className="chamfer bg-ink-850 p-6">
                        <p className="eyebrow mb-3">Featured</p>
                        <p className="font-display text-2xl font-bold uppercase leading-none text-ink-50">{group.featured.title}</p>
                        <p className="mt-3 text-sm text-ink-200">{group.featured.body}</p>
                        <Button href={group.featured.href} size="sm" icon="arrow-right" className="mt-5">
                          {group.featured.cta}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="chamfer-frame self-start">
                      <div className="chamfer bg-ink-850 p-6">
                        <p className="eyebrow mb-3">Join the community</p>
                        <p className="font-display text-2xl font-bold uppercase leading-none text-ink-50">Membership is free</p>
                        <p className="mt-3 text-sm text-ink-200">For current and ex-serving ADF and NZDF members, and immediate family aged 18+.</p>
                        <Button href={ctaNav.join.href} size="sm" icon="arrow-right" className="mt-5">
                          {ctaNav.join.label}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : null
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <a
            href={ctaNav.discord.href}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden h-10 w-10 items-center justify-center rounded-full text-ink-100 transition hover:bg-discord/20 hover:text-white md:flex"
            aria-label="Join the VGA Discord (opens in a new tab)"
            title="Join the VGA Discord"
          >
            <Icon name="discord" className="h-5 w-5" />
          </a>
          <Button href={ctaNav.donate.href} variant="secondary" size="sm" className="hidden md:inline-flex">
            {ctaNav.donate.label}
          </Button>
          <Button href={ctaNav.join.href} size="sm" className="hidden sm:inline-flex">
            {ctaNav.join.label}
          </Button>
          <button
            type="button"
            className="flex h-11 w-11 items-center justify-center rounded text-ink-50 transition hover:bg-ink-800 lg:hidden"
            aria-expanded={mobile}
            aria-controls="mobile-nav"
            aria-label={mobile ? "Close menu" : "Open menu"}
            onClick={() => setMobile((v) => !v)}
          >
            <Icon name={mobile ? "close" : "menu"} className="h-6 w-6" />
          </button>
        </div>
      </div>

      <MobileNav open={mobile} onClose={() => setMobile(false)} pathname={pathname} />
    </header>
  );
}

function MobileNav({ open, onClose, pathname }: { open: boolean; onClose: () => void; pathname: string }) {
  const [expanded, setExpanded] = useState<string | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const id = useId();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const first = panelRef.current?.querySelector<HTMLElement>("a, button");
    first?.focus();
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return (
    <div
      id="mobile-nav"
      ref={panelRef}
      hidden={!open}
      className="fixed inset-x-0 bottom-0 top-[var(--header-h)] z-40 overflow-y-auto border-t border-ink-700 bg-ink-900 lg:hidden"
      aria-label="Mobile navigation"
    >
      <nav className="container py-4">
        <ul className="divide-y divide-ink-700/70">
          {mainNav.map((group) => {
            const isOpen = expanded === group.label;
            const active = group.href === "/" ? pathname === "/" : pathname.startsWith(group.href);
            return (
              <li key={group.label}>
                {group.items?.length ? (
                  <>
                    <div className="flex items-stretch">
                      <Link href={group.href} className={cn("flex-1 py-4 font-display text-2xl font-bold uppercase tracking-wide", active ? "text-gold-200" : "text-ink-50")}>
                        {group.label}
                      </Link>
                      <button
                        type="button"
                        className="flex w-14 items-center justify-center text-ink-200"
                        aria-expanded={isOpen}
                        aria-controls={`${id}-${group.label}`}
                        aria-label={`${isOpen ? "Collapse" : "Expand"} ${group.label}`}
                        onClick={() => setExpanded(isOpen ? null : group.label)}
                      >
                        <Icon name="chevron-down" className={cn("h-5 w-5 transition-transform", isOpen ? "rotate-180" : "")} />
                      </button>
                    </div>
                    <ul id={`${id}-${group.label}`} hidden={!isOpen} className="mb-3 space-y-1 border-l border-gold-700/50 pl-4">
                      {group.items.map((item) =>
                        item.external ? (
                          <li key={item.href}>
                            <a href={item.href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 py-2.5 text-lg text-ink-100">
                              {item.label} <Icon name="external" className="h-4 w-4 text-ink-400" />
                            </a>
                          </li>
                        ) : (
                          <li key={item.href}>
                            <Link href={item.href} className="block py-2.5 text-lg text-ink-100">
                              {item.label}
                            </Link>
                          </li>
                        )
                      )}
                    </ul>
                  </>
                ) : (
                  <Link href={group.href} className={cn("block py-4 font-display text-2xl font-bold uppercase tracking-wide", active ? "text-gold-200" : "text-ink-50")}>
                    {group.label}
                  </Link>
                )}
              </li>
            );
          })}
          <li>
            <Link href="/contact" className="block py-4 font-display text-2xl font-bold uppercase tracking-wide text-ink-50">
              Contact
            </Link>
          </li>
        </ul>
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <Button href={ctaNav.join.href} size="lg" icon="arrow-right">
            {ctaNav.join.label}
          </Button>
          <Button href={ctaNav.discord.href} variant="discord" size="lg" icon="discord" iconPosition="left">
            {ctaNav.discord.label}
          </Button>
          <Button href={ctaNav.donate.href} variant="secondary" size="lg" className="sm:col-span-2">
            {ctaNav.donate.label}
          </Button>
        </div>
        <div className="mt-8 border-t border-ink-700/70 pt-6">
          <SocialLinks className="justify-start" />
        </div>
        <div className="safe-bottom h-6" />
      </nav>
    </div>
  );
}
