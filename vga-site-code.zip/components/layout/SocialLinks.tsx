import { site } from "@/data/site";
import { Icon, type IconName } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

const links: { key: keyof typeof site.socials; label: string; icon: IconName }[] = [
  { key: "discord", label: "Discord", icon: "discord" },
  { key: "facebook", label: "Facebook", icon: "facebook" },
  { key: "instagram", label: "Instagram", icon: "instagram" },
  { key: "youtube", label: "YouTube", icon: "youtube" },
  { key: "twitch", label: "Twitch", icon: "twitch" },
  { key: "patreon", label: "Patreon", icon: "patreon" },
];

export function SocialLinks({ className, size = "md" }: { className?: string; size?: "md" | "lg" }) {
  return (
    <ul className={cn("flex flex-wrap items-center gap-2", className)} aria-label="Veteran Gaming Australia on social media">
      {links.map((l) => (
        <li key={l.key}>
          <a
            href={site.socials[l.key]}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`${site.shortName} on ${l.label} (opens in a new tab)`}
            title={l.label}
            className={cn(
              "flex items-center justify-center rounded-full border border-ink-600 text-ink-100 transition hover:border-gold-500 hover:text-gold-200",
              size === "lg" ? "h-12 w-12" : "h-10 w-10"
            )}
          >
            <Icon name={l.icon} className={size === "lg" ? "h-[1.375rem] w-[1.375rem]" : "h-5 w-5"} />
          </a>
        </li>
      ))}
    </ul>
  );
}
