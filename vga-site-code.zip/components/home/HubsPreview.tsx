import { hubs, hubStates } from "@/data/hubs";
import { AustraliaMap } from "@/components/hubs/AustraliaMap";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";

const stateNames: Record<string, string> = { QLD: "Queensland", NSW: "New South Wales", VIC: "Victoria", SA: "South Australia", NT: "Northern Territory", WA: "Western Australia", TAS: "Tasmania", ACT: "ACT" };

export function HubsPreview() {
  const esports = hubs.filter((h) => h.type === "Esports Hub").length;
  return (
    <section className="relative overflow-hidden border-y border-ink-700/60 bg-ink-950" aria-labelledby="hubs-title">
      <div className="absolute inset-0 bg-grid opacity-40 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" aria-hidden="true" />
      <div className="container relative grid items-center gap-12 py-20 lg:grid-cols-[1fr_1.1fr] sm:py-24">
        <div>
          <p className="eyebrow mb-4">Gaming hubs · national footprint</p>
          <h2 id="hubs-title" className="text-display-md uppercase text-ink-50">
            Is there a VGA hub near you?
          </h2>
          <p className="mt-5 text-lg text-ink-200">
            VGA has facilitated and set up <strong className="text-ink-50">{hubs.length} social gaming and esports hubs</strong> on Defence bases, in Veteran and Family wellbeing centres, RSLs and hospitals — including {esports} esports hubs with gaming PCs.
          </p>
          <ul className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {hubStates.map((s) => {
              const n = hubs.filter((h) => h.state === s).length;
              return (
                <li key={s} className="rounded border border-ink-700 bg-ink-900/70 px-4 py-3">
                  <p className="font-display text-3xl font-bold leading-none text-gold-200">{n}</p>
                  <p className="mt-1 text-sm text-ink-300">
                    <span className="font-semibold text-ink-100">{s}</span> · {stateNames[s]}
                  </p>
                </li>
              );
            })}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button href="/gaming-hubs" icon="map-pin" iconPosition="left">
              Find a hub near you
            </Button>
            <Button href="/programs#gaming-hubs" variant="ghost" icon="arrow-right">
              About the Retrofit program
            </Button>
          </div>
          <p className="mt-6 flex items-start gap-2 text-sm text-ink-400">
            <Icon name="info" className="mt-0.5 h-4 w-4 shrink-0" />
            Hub venues are hosted by partner organisations. Check with the venue about access before you visit.
          </p>
        </div>
        <div className="chamfer-frame">
          <div className="chamfer bg-ink-900 p-2 sm:p-4">
            <AustraliaMap hubs={hubs} interactive compact={false} />
          </div>
        </div>
      </div>
    </section>
  );
}
