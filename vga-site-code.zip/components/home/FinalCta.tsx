import { site } from "@/data/site";
import { Button } from "@/components/ui/Button";

export function FinalCta() {
  return (
    <section className="container py-20 sm:py-24" aria-labelledby="final-cta">
      <div className="chamfer-frame chamfer-lg">
        <div className="chamfer-lg relative overflow-hidden bg-ink-950 px-6 py-14 text-center sm:px-12 sm:py-20">
          <div className="absolute inset-0 bg-grid opacity-50 [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" aria-hidden="true" />
          <div className="absolute -top-24 left-1/2 h-64 w-[36rem] -translate-x-1/2 rounded-full bg-gold-500/15 blur-3xl" aria-hidden="true" />
          <div className="relative mx-auto max-w-3xl">
            <p className="eyebrow mb-4 justify-center">Ready when you are</p>
            <h2 id="final-cta" className="text-display-lg uppercase text-ink-50">
              Join the <span className="gold-text">community.</span>
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-lg text-ink-200">
              Membership is free for current and ex-serving ADF and NZDF members and their immediate family (18+). Not eligible? You can still back the mission.
            </p>
            <div className="mt-9 flex flex-wrap justify-center gap-3">
              <Button href="/become-a-member" size="lg" icon="arrow-right">
                Become a member
              </Button>
              <Button href={site.socials.discord} variant="discord" size="lg" icon="discord" iconPosition="left">
                Join Discord
              </Button>
              <Button href="/donate" variant="secondary" size="lg">
                Donate
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
