import { digitalSocials } from "@/data/programs";
import { pastEvents, upcomingEvents, eventsNotice } from "@/data/events";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { EventCard } from "@/components/events/EventCard";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";

export function EventsPreview() {
  const upcoming = upcomingEvents.slice(0, 3);
  const recent = pastEvents.slice(0, 3);
  const socialsToday = digitalSocials.slice(0, 4);
  return (
    <section className="border-y border-ink-700/60 bg-ink-850" aria-labelledby="events-title">
      <div className="container py-20 sm:py-24">
        <SectionHeader
          id="events-title"
          eyebrow="Events"
          title={upcoming.length ? "Upcoming events" : "Something on every week"}
          lead={upcoming.length ? "In person and online — all free for members." : "Digital social game nights run every week on Discord. In-person events are announced on Facebook and Discord and often book out within minutes."}
          action={
            <Button href="/events" variant="secondary" icon="arrow-right">
              View all events
            </Button>
          }
        />
        <div className="grid gap-8 lg:grid-cols-[1.1fr_2fr]">
          <div className="card p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-2xl font-bold uppercase text-ink-50">Weekly digital socials</h3>
              <Icon name="discord" className="h-6 w-6 text-discord" />
            </div>
            <ul className="mt-4 divide-y divide-ink-700/70">
              {socialsToday.map((d) => (
                <li key={d.day} className="py-3">
                  <p className="font-display text-base font-semibold uppercase tracking-[0.14em] text-gold-500">{d.day}</p>
                  <ul className="mt-1 space-y-1">
                    {d.sessions.map((s) => (
                      <li key={s.game} className="flex flex-wrap items-baseline justify-between gap-x-4 text-ink-100">
                        <span>{s.game}</span>
                        <span className="text-sm text-ink-300">
                          {s.time} · {s.cadence}
                        </span>
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ul>
            <Button href="/programs/game-servers" variant="ghost" icon="arrow-right" className="mt-4">
              Full schedule and 24/7 servers
            </Button>
          </div>
          <div>
            <ul className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
              {(upcoming.length ? upcoming : recent).map((e) => (
                <li key={e.slug}>
                  <EventCard event={e} past={!upcoming.length} />
                </li>
              ))}
            </ul>
            <p className="mt-6 flex items-start gap-3 rounded border border-ink-700 bg-ink-900 p-4 text-sm text-ink-300">
              <Icon name="info" className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" />
              <span>
                {eventsNotice.body}{" "}
                <a href={eventsNotice.facebook} target="_blank" rel="noopener noreferrer" className="text-gold-200 underline underline-offset-4">
                  Facebook
                </a>{" "}
                ·{" "}
                <a href={eventsNotice.discord} target="_blank" rel="noopener noreferrer" className="text-gold-200 underline underline-offset-4">
                  Discord
                </a>
              </span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
