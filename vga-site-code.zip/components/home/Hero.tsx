import Image from "next/image";
import { site } from "@/data/site";
import { images } from "@/data/generated/images";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";

const hero = images["hero/sim-racing-rig-pair"];
const acnc = images["brand/acnc-registered-charity"];

export function Hero() {
  return (
    <section className="relative isolate overflow-hidden bg-ink-950" aria-labelledby="hero-title">
      <Image
        src={hero.src}
        alt={hero.alt}
        width={hero.width}
        height={hero.height}
        priority
        sizes="100vw"
        className="absolute inset-0 -z-20 h-full w-full object-cover object-[70%_center] opacity-60"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-950 via-ink-950/80 to-ink-950/25" aria-hidden="true" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-ink-900 via-ink-900/20 to-transparent" aria-hidden="true" />
      <div className="absolute inset-0 -z-10 bg-grid opacity-40 [mask-image:linear-gradient(to_right,black,transparent_60%)]" aria-hidden="true" />

      <div className="container relative flex min-h-[calc(100svh-var(--header-h))] flex-col justify-center py-16 sm:py-24 lg:min-h-[min(88vh,900px)]">
        <div className="max-w-3xl">
          <p className="eyebrow mb-5 animate-fade-up">Veteran founded · 100% volunteer run · ACNC registered charity</p>
          <h1 id="hero-title" className="text-display-xl uppercase text-ink-50 animate-fade-up [animation-delay:80ms]">
            Improving Veteran wellbeing through <span className="gold-text">gaming.</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-ink-100 sm:text-xl animate-fade-up [animation-delay:160ms]">{site.mission}</p>
          <p className="mt-3 max-w-2xl text-base text-ink-300 animate-fade-up [animation-delay:200ms]">{site.freeServices}</p>
          <div className="mt-9 flex flex-wrap gap-3 animate-fade-up [animation-delay:240ms]">
            <Button href="/become-a-member" size="lg" icon="arrow-right">
              Join the community
            </Button>
            <Button href="/programs" variant="secondary" size="lg">
              Explore programs
            </Button>
            <Button href={site.socials.discord} variant="discord" size="lg" icon="discord" iconPosition="left">
              Join Discord
            </Button>
          </div>
        </div>

        <ul className="mt-12 grid gap-x-8 gap-y-4 border-t border-ink-700/60 pt-6 text-sm text-ink-300 animate-fade-up [animation-delay:320ms] sm:grid-cols-2 lg:grid-cols-3 lg:divide-x lg:divide-ink-700">
          <li className="flex items-center gap-3 lg:pr-6">
            <Image src={acnc.src} width={acnc.width} height={acnc.height} alt={acnc.alt} className="h-11 w-11 shrink-0" />
            <span>
              Registered charity
              <span className="block text-ink-400">Founded {site.founded} · community-charity</span>
            </span>
          </li>
          <li className="flex items-center gap-3 lg:px-6">
            <Icon name="users" className="h-6 w-6 shrink-0 text-gold-500" />
            <span>
              For Veterans and Veteran Families
              <span className="block text-ink-400">Current and ex-serving ADF &amp; NZDF, plus immediate family 18+</span>
            </span>
          </li>
          <li className="flex items-center gap-3 lg:pl-6">
            <Icon name="discord" className="h-6 w-6 shrink-0 text-gold-500" />
            <span>
              Always-on community
              <span className="block text-ink-400">~70 hours of voice chat &amp; 1,000+ messages every week</span>
            </span>
          </li>
        </ul>
      </div>
    </section>
  );
}
