import { currentSponsorYear } from "@/data/sponsors";
import { SponsorLogo } from "@/components/sponsors/SponsorLogo";
import { Button } from "@/components/ui/Button";

export function SponsorsStrip() {
  const year = currentSponsorYear;
  const tiers = year.tiers;
  return (
    <section className="border-t border-ink-700/60 bg-ink-850" aria-labelledby="sponsors-title">
      <div className="container py-16 sm:py-20">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="eyebrow mb-3">Sponsors &amp; partners</p>
            <h2 id="sponsors-title" className="text-display-sm uppercase text-ink-50">
              Backed by legends — {year.title.replace("Sponsors ", "")}
            </h2>
            <p className="mt-3 max-w-xl text-ink-300">{year.grants}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button href="/become-a-sponsor" icon="arrow-right">
              Become a sponsor
            </Button>
            <Button href="/sponsors" variant="ghost" icon="arrow-right">
              All sponsors by year
            </Button>
          </div>
        </div>
        <div className="mt-10 space-y-8">
          {tiers.map((tier) => (
            <div key={tier.name}>
              <p className="mb-3 font-display text-sm font-semibold uppercase tracking-[0.18em] text-ink-400">{tier.name}</p>
              <ul className="flex flex-wrap gap-3">
                {tier.sponsors.map((s) => (
                  <li key={s.name}>
                    <SponsorLogo sponsor={s} size={tier.name.startsWith("Elite") ? "lg" : "md"} />
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
