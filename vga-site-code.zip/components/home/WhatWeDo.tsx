import { programs } from "@/data/programs";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { ProgramCard } from "@/components/programs/ProgramCard";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";

const featured = ["gaming-hubs", "esports", "game-servers", "events", "care-packages", "creative-programs"];

export function WhatWeDo() {
  const items = featured.map((slug) => programs.find((p) => p.slug === slug)!).filter(Boolean);
  return (
    <section className="container py-20 sm:py-24" aria-labelledby="what-we-do">
      <SectionHeader
        id="what-we-do"
        eyebrow="What we do"
        title="Gaming is the mechanism. Community is the outcome."
        lead="Free programs, online and in person, for current and ex-serving Veterans and their families — from 24/7 game servers and esports leagues to gaming hubs, care packages and hospital visits."
        action={
          <Button href="/programs" variant="secondary" icon="arrow-right">
            All programs
          </Button>
        }
      />
      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p, i) => (
          <Reveal as="li" key={p.slug} delay={i * 50}>
            <ProgramCard program={p} />
          </Reveal>
        ))}
      </ul>
    </section>
  );
}
