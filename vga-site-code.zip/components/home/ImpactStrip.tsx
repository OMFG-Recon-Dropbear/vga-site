import { headlineStats } from "@/data/stats";
import { AnimatedNumber } from "@/components/ui/Stat";
import { Reveal } from "@/components/ui/Reveal";
import { Button } from "@/components/ui/Button";

export function ImpactStrip() {
  return (
    <section className="relative border-y border-ink-700/60 bg-ink-850" aria-labelledby="impact-title">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-500/70 to-transparent" aria-hidden="true" />
      <div className="container py-14 sm:py-18">
        <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="eyebrow mb-3">VGA by the numbers</p>
            <h2 id="impact-title" className="text-display-md uppercase text-ink-50">
              Five years in the game
            </h2>
          </div>
          <p className="max-w-md text-sm text-ink-300">
            Figures as published by VGA (About Us, Donate page and the April 2026 <em>5 Years in the Game</em> report).
          </p>
        </div>
        <ul className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-ink-700 bg-ink-700 md:grid-cols-3 lg:grid-cols-6">
          {headlineStats.map((s, i) => (
            <Reveal as="li" key={s.label} delay={i * 60} className="bg-ink-900 p-5 sm:p-6">
              <p className="font-display text-4xl font-bold leading-none text-gold-200 sm:text-5xl">
                <AnimatedNumber value={s.value} prefix={s.prefix} suffix={s.suffix} />
              </p>
              <p className="mt-3 font-display text-lg font-semibold uppercase leading-tight tracking-wide text-ink-50">{s.label}</p>
              {s.detail ? <p className="mt-2 text-sm leading-snug text-ink-300">{s.detail}</p> : null}
            </Reveal>
          ))}
        </ul>
        <div className="mt-8">
          <Button href="/impact" variant="ghost" icon="arrow-right">
            See our impact and the independent evaluation
          </Button>
        </div>
      </div>
    </section>
  );
}
