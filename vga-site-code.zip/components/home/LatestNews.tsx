import { latestPosts } from "@/lib/content";
import { NewsCard } from "@/components/community/NewsCard";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";

export function LatestNews() {
  const posts = latestPosts(3, { excludeGalleries: true });
  return (
    <section className="container py-20 sm:py-24" aria-labelledby="news-title">
      <SectionHeader
        id="news-title"
        eyebrow="Latest news"
        title="What VGA has been up to"
        lead="Newsletters, program updates and advocacy on behalf of Veterans and Veteran Families."
        action={
          <Button href="/news" variant="secondary" icon="arrow-right">
            All news
          </Button>
        }
      />
      <ul className="grid gap-6 md:grid-cols-3">
        {posts.map((p, i) => (
          <Reveal as="li" key={p.slug} delay={i * 60}>
            <NewsCard post={p} featured={i === 0} />
          </Reveal>
        ))}
      </ul>
    </section>
  );
}
