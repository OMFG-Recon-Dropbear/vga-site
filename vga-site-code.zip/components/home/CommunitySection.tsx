import Image from "next/image";
import { images, type ImageKey } from "@/data/generated/images";
import { about } from "@/data/about";
import { evaluationStats } from "@/data/stats";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";

const grid: { key: ImageKey; span?: string }[] = [
  { key: "news/vga-social-event-stadium", span: "sm:col-span-2 sm:row-span-2" },
  { key: "gallery/newsletter-may-aug-2026/06" },
  { key: "news/qld-mhw-llama" },
  { key: "gallery/comicon-brisbane-2024/07" },
  { key: "gallery/newsletter-may-aug-2026/02" },
  { key: "gallery/community-2025-26/22" },
];

export function CommunitySection() {
  const connected = evaluationStats[1];
  return (
    <section className="container py-20 sm:py-24" aria-labelledby="community-title">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr] lg:items-center">
        <div>
          <p className="eyebrow mb-4">Community</p>
          <h2 id="community-title" className="text-display-lg uppercase text-ink-50">
            More than <span className="gold-text">gaming.</span>
          </h2>
          <p className="mt-6 text-lg leading-relaxed text-ink-200">{about.belief}</p>
          <blockquote className="mt-8 border-l-2 border-gold-500 pl-5">
            <p className="text-xl leading-relaxed text-ink-50">“{about.ceoMessage.quote}”</p>
            <footer className="mt-3 text-sm text-ink-300">
              — {about.ceoMessage.name}, {about.ceoMessage.title}
            </footer>
          </blockquote>
          <div className="mt-8 rounded-lg border border-ink-700 bg-ink-850 p-5">
            <p className="font-display text-5xl font-bold leading-none text-gold-200">18% → 68%</p>
            <p className="mt-2 text-ink-100">Veterans feeling very or extremely connected, before and after VGA events.</p>
            <p className="mt-1 text-sm text-ink-400">{connected.source}, First Person Consulting.</p>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button href="/about-us" icon="arrow-right">
              Our story
            </Button>
            <Button href="/gallery" variant="secondary">
              Photo gallery
            </Button>
          </div>
        </div>
        <Reveal>
          <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {grid.map((g, i) => {
              const img = images[g.key];
              return (
                <li key={g.key} className={`relative overflow-hidden rounded-md bg-ink-800 ${g.span ?? ""} ${i === 0 ? "aspect-[4/3] sm:aspect-auto" : "aspect-square"}`}>
                  <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 30vw, 50vw" className="h-full w-full object-cover transition duration-700 hover:scale-[1.03]" />
                </li>
              );
            })}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
