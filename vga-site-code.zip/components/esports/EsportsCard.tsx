import Image from "next/image";
import Link from "next/link";
import { images, type ImageKey } from "@/data/generated/images";
import { Icon } from "@/components/ui/Icon";
import { Tag } from "@/components/ui/Tag";

export function EsportsCard({ title, subtitle, href, image, status, body }: { title: string; subtitle?: string; href: string; image: ImageKey; status?: string; body: string }) {
  const img = images[image];
  return (
    <Link href={href} className="card card-hover group flex h-full flex-col overflow-hidden">
      <div className="relative aspect-[16/9] overflow-hidden bg-ink-800">
        <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 33vw, 100vw" className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
        {status ? (
          <div className="absolute left-4 top-4">
            <Tag tone={status === "Coming soon" ? "grey" : "gold"}>{status}</Tag>
          </div>
        ) : null}
      </div>
      <div className="flex flex-1 flex-col p-6">
        {subtitle ? <p className="eyebrow mb-2">{subtitle}</p> : null}
        <h3 className="font-display text-3xl font-bold uppercase leading-none text-ink-50 transition group-hover:text-gold-200">{title}</h3>
        <p className="mt-3 flex-1 text-ink-200">{body}</p>
        <span className="mt-5 inline-flex items-center gap-2 font-display text-base font-semibold uppercase tracking-[0.1em] text-gold-300">
          Learn more <Icon name="arrow-right" className="h-4 w-4 transition group-hover:translate-x-1" />
        </span>
      </div>
    </Link>
  );
}
