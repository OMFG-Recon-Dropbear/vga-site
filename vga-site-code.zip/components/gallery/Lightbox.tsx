"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import { Icon } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

export type LightboxImage = { src: string; width: number; height: number; alt: string; caption?: string };

/**
 * Photo grid with an accessible lightbox. Uses a native <dialog> for focus management and Escape handling;
 * arrow keys move between photos. Thumbnails are lazy-loaded.
 */
export function PhotoGrid({ images, columns = 3, className }: { images: LightboxImage[]; columns?: 2 | 3 | 4; className?: string }) {
  const [index, setIndex] = useState<number | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const lastTrigger = useRef<HTMLElement | null>(null);

  const close = useCallback(() => {
    dialogRef.current?.close();
  }, []);

  const open = (i: number, el: HTMLElement) => {
    lastTrigger.current = el;
    setIndex(i);
  };

  useEffect(() => {
    const d = dialogRef.current;
    if (!d) return;
    if (index !== null && !d.open) d.showModal();
    const onClose = () => {
      setIndex(null);
      lastTrigger.current?.focus();
    };
    d.addEventListener("close", onClose);
    return () => d.removeEventListener("close", onClose);
  }, [index]);

  useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") setIndex((i) => (i === null ? i : (i + 1) % images.length));
      if (e.key === "ArrowLeft") setIndex((i) => (i === null ? i : (i - 1 + images.length) % images.length));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index, images.length]);

  const cols = columns === 4 ? "sm:grid-cols-3 lg:grid-cols-4" : columns === 2 ? "sm:grid-cols-2" : "sm:grid-cols-2 lg:grid-cols-3";
  const current = index !== null ? images[index] : null;

  return (
    <>
      <ul className={cn("grid grid-cols-2 gap-2 sm:gap-3", cols, className)}>
        {images.map((img, i) => (
          <li key={img.src} className={cn(i % 7 === 0 && columns !== 2 ? "col-span-2 row-span-2" : "")}>
            <button
              type="button"
              onClick={(e) => open(i, e.currentTarget)}
              className="group relative block h-full w-full overflow-hidden rounded-md border border-ink-700 bg-ink-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-200"
              aria-label={`Open photo ${i + 1} of ${images.length}: ${img.alt}`}
            >
              <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 33vw, 50vw" className="aspect-[4/3] h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
              <span className="absolute inset-0 bg-gradient-to-t from-ink-950/60 to-transparent opacity-0 transition group-hover:opacity-100" aria-hidden="true" />
              <span className="absolute bottom-2 right-2 flex h-8 w-8 items-center justify-center rounded-sm bg-ink-950/80 text-gold-200 opacity-0 transition group-hover:opacity-100" aria-hidden="true">
                <Icon name="search" className="h-4 w-4" />
              </span>
            </button>
          </li>
        ))}
      </ul>

      <dialog
        ref={dialogRef}
        className="m-0 h-full max-h-none w-full max-w-none bg-transparent p-0 backdrop:bg-ink-950/95"
        aria-label={current ? `Photo ${index! + 1} of ${images.length}` : "Photo viewer"}
        onClick={(e) => {
          if (e.target === e.currentTarget) close();
        }}
      >
        {current ? (
          <div className="flex h-full w-full flex-col">
            <div className="flex items-center justify-between gap-4 px-4 py-3 text-ink-200 sm:px-6">
              <p className="font-display text-sm font-semibold uppercase tracking-[0.14em]">
                {index! + 1} / {images.length}
              </p>
              <button type="button" onClick={close} className="flex h-10 w-10 items-center justify-center rounded-sm bg-ink-800 text-ink-50 hover:bg-ink-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-200" aria-label="Close photo viewer">
                <Icon name="close" className="h-5 w-5" />
              </button>
            </div>
            <div className="relative flex min-h-0 flex-1 items-center justify-center px-2 sm:px-16">
              <button type="button" onClick={() => setIndex((index! - 1 + images.length) % images.length)} className="absolute left-2 top-1/2 z-10 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-sm bg-ink-800/90 text-ink-50 hover:bg-ink-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-200 sm:left-4" aria-label="Previous photo">
                <Icon name="chevron-left" className="h-6 w-6" />
              </button>
              <figure className="flex max-h-full max-w-full flex-col items-center">
                <Image key={current.src} src={current.src} alt={current.alt} width={current.width} height={current.height} sizes="100vw" className="max-h-[78vh] w-auto max-w-full object-contain" priority />
                <figcaption className="mt-3 max-w-2xl text-center text-sm text-ink-300">{current.caption ?? current.alt}</figcaption>
              </figure>
              <button type="button" onClick={() => setIndex((index! + 1) % images.length)} className="absolute right-2 top-1/2 z-10 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-sm bg-ink-800/90 text-ink-50 hover:bg-ink-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold-200 sm:right-4" aria-label="Next photo">
                <Icon name="chevron-right" className="h-6 w-6" />
              </button>
            </div>
            <div className="safe-bottom px-4 pb-4 pt-2 text-center text-xs text-ink-500">Use ← → to move between photos, Esc to close</div>
          </div>
        ) : null}
      </dialog>
    </>
  );
}
