import Image from "next/image";
import type { Sponsor } from "@/data/sponsors";
import { images, type ImageAsset } from "@/data/generated/images";
import { cn } from "@/lib/utils";

/** Sponsor logo tile. Tile tone follows the artwork (light for dark-on-transparent logos, dark for light-on-transparent). */
export function SponsorLogo({ sponsor, size = "md" }: { sponsor: Sponsor; size?: "sm" | "md" | "lg" }) {
  const img = images[sponsor.image] as ImageAsset;
  const box = size === "lg" ? "h-24 w-52 sm:h-28 sm:w-64" : size === "sm" ? "h-14 w-32" : "h-20 w-44";
  const tone = img.tone === "dark" ? "bg-ink-950 border-ink-600" : "bg-[#f7f7f5] border-ink-700";
  const inner = (
    <span className={cn("flex items-center justify-center rounded-md border p-3 transition", box, tone, sponsor.url ? "hover:border-gold-500 hover:shadow-lift" : "")}>
      <Image src={img.src} alt={sponsor.name} width={img.width} height={img.height} sizes="260px" className="max-h-full w-auto max-w-full object-contain" />
    </span>
  );
  return sponsor.url ? (
    <a href={sponsor.url} target="_blank" rel="noopener noreferrer sponsored" title={sponsor.name} aria-label={`${sponsor.name} (opens in a new tab)`} className="block">
      {inner}
    </a>
  ) : (
    <span className="block" title={sponsor.name}>
      {inner}
    </span>
  );
}
