import type { SponsorYear } from "@/data/sponsors";
import { SponsorLogo } from "./SponsorLogo";

/** One sponsorship year: intro, grants line, thresholds and tier walls. */
export function SponsorYearSection({ year, headingLevel = 2, compact = false }: { year: SponsorYear; headingLevel?: 2 | 3; compact?: boolean }) {
  const H = `h${headingLevel}` as "h2";
  return (
    <div>
      {!compact ? (
        <div className="max-w-3xl">
          <p className="text-lg text-ink-200">{year.intro}</p>
          {year.grants ? <p className="mt-3 text-ink-300">{year.grants}</p> : null}
        </div>
      ) : null}
      {year.thresholds.length ? (
        <ul className="mt-6 flex flex-wrap gap-2" aria-label={`${year.title} sponsorship thresholds`}>
          {year.thresholds.map((t) => (
            <li key={t.tier} className="chamfer-sm inline-flex items-center gap-2 bg-ink-800 px-3 py-1.5 font-display text-sm font-semibold uppercase tracking-[0.1em] text-ink-100">
              <span className="text-gold-300">{t.tier}</span> {t.amount}
            </li>
          ))}
        </ul>
      ) : null}
      <div className="mt-8 space-y-10">
        {year.tiers.map((tier) => (
          <section key={tier.name} aria-labelledby={`${year.year}-${tier.name.replace(/\W+/g, "-").toLowerCase()}`}>
            <H id={`${year.year}-${tier.name.replace(/\W+/g, "-").toLowerCase()}`} className="flex items-center gap-4 font-display text-2xl font-bold uppercase text-ink-50">
              <span>{tier.name}</span>
              {tier.threshold ? <span className="text-base font-semibold tracking-[0.1em] text-gold-500">{tier.threshold}</span> : null}
              <span className="h-px flex-1 bg-ink-700" aria-hidden="true" />
            </H>
            <ul className="mt-5 flex flex-wrap gap-4">
              {tier.sponsors.map((s) => (
                <li key={s.name + s.image}>
                  <SponsorLogo sponsor={s} size={tier.name.startsWith("Elite") || tier.name.startsWith("Legendary") ? "lg" : "md"} />
                  <span className="sr-only">{s.name}</span>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}
