"use client";

import { useMemo, useState } from "react";
import type { VgaEvent, EventRegion } from "@/data/events";
import { EventCard } from "./EventCard";
import { cn } from "@/lib/utils";

const regionLabel: Record<string, string> = { ACT: "ACT", NSW: "NSW", QLD: "QLD", VIC: "VIC", SA: "SA", WA: "WA", NT: "NT", TAS: "TAS", Online: "Online", National: "National" };

/** Past-events archive with region and type filters. Only regions that have events are offered. */
export function EventsExplorer({ events, regions }: { events: VgaEvent[]; regions: EventRegion[] }) {
  const [region, setRegion] = useState<EventRegion | "all">("all");
  const [kind, setKind] = useState<VgaEvent["kind"] | "all">("all");
  const kinds = useMemo(() => Array.from(new Set(events.map((e) => e.kind))), [events]);
  const list = events.filter((e) => (region === "all" || e.region === region) && (kind === "all" || e.kind === kind));
  const chip = (active: boolean) => cn("chamfer-sm px-3 py-1.5 font-display text-sm font-semibold uppercase tracking-[0.1em] transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-200", active ? "bg-gold-500 text-ink-950" : "bg-ink-800 text-ink-200 hover:bg-ink-700 hover:text-ink-50");

  return (
    <div>
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <fieldset>
          <legend className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-ink-400">Region</legend>
          <div className="flex flex-wrap gap-2">
            <button type="button" className={chip(region === "all")} aria-pressed={region === "all"} onClick={() => setRegion("all")}>
              All
            </button>
            {regions.map((r) => (
              <button key={r} type="button" className={chip(region === r)} aria-pressed={region === r} onClick={() => setRegion(r)}>
                {regionLabel[r] ?? r}
              </button>
            ))}
          </div>
        </fieldset>
        <fieldset>
          <legend className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-ink-400">Type</legend>
          <div className="flex flex-wrap gap-2">
            <button type="button" className={chip(kind === "all")} aria-pressed={kind === "all"} onClick={() => setKind("all")}>
              All
            </button>
            {kinds.map((k) => (
              <button key={k} type="button" className={chip(kind === k)} aria-pressed={kind === k} onClick={() => setKind(k)}>
                {k}
              </button>
            ))}
          </div>
        </fieldset>
      </div>
      <p className="mt-4 text-sm text-ink-400" aria-live="polite">
        {list.length} {list.length === 1 ? "event" : "events"}
        {region !== "all" ? ` in ${regionLabel[region] ?? region}` : ""}
        {kind !== "all" ? ` · ${kind}` : ""}
      </p>
      {list.length ? (
        <ul className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((e) => (
            <li key={e.slug}>
              <EventCard event={e} past />
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-6 rounded border border-ink-700 bg-ink-850 p-6 text-ink-200">No events match those filters yet.</p>
      )}
    </div>
  );
}
