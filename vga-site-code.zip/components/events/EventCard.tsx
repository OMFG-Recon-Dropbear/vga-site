import Image from "next/image";
import Link from "next/link";
import type { VgaEvent } from "@/data/events";
import { images } from "@/data/generated/images";
import { Icon } from "@/components/ui/Icon";
import { Tag } from "@/components/ui/Tag";
import { isExternal } from "@/lib/utils";

export function EventCard({ event, past = false }: { event: VgaEvent; past?: boolean }) {
  const img = event.image ? images[event.image] : null;
  const body = (
    <>
      {img ? (
        <div className="relative aspect-[16/10] overflow-hidden bg-ink-800">
          <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw" className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
        </div>
      ) : (
        <div className="flex aspect-[16/10] items-center justify-center bg-ink-800 text-ink-600" aria-hidden="true">
          <Icon name={event.kind === "Esports" ? "trophy" : event.kind === "Online" ? "discord" : "calendar"} className="h-10 w-10" />
        </div>
      )}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap items-center gap-2">
          <Tag tone={past ? "grey" : "gold"}>{event.region}</Tag>
          <Tag tone="grey">{event.kind}</Tag>
        </div>
        <h3 className="mt-3 font-display text-xl font-bold uppercase leading-tight text-ink-50 group-hover:text-gold-200">{event.title}</h3>
        <p className="mt-2 flex items-center gap-2 text-sm text-ink-300">
          <Icon name="calendar" className="h-4 w-4 text-gold-500" />
          {event.displayDate}
        </p>
        {event.location ? (
          <p className="mt-1 flex items-center gap-2 text-sm text-ink-300">
            <Icon name="map-pin" className="h-4 w-4 text-gold-500" />
            {event.location}
          </p>
        ) : null}
        <p className="mt-3 flex-1 text-sm leading-relaxed text-ink-200 line-clamp-3">{event.summary}</p>
        {event.href ? (
          <span className="mt-4 inline-flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-[0.12em] text-gold-300">
            {past ? "Read more" : "Details"} <Icon name={isExternal(event.href) ? "external" : "arrow-right"} className="h-4 w-4" />
          </span>
        ) : null}
      </div>
    </>
  );
  const cls = "card card-hover group flex h-full flex-col overflow-hidden";
  if (!event.href) return <article className={cls}>{body}</article>;
  return isExternal(event.href) ? (
    <a href={event.href} target="_blank" rel="noopener noreferrer" className={cls}>
      {body}
    </a>
  ) : (
    <Link href={event.href} className={cls}>
      {body}
    </Link>
  );
}
