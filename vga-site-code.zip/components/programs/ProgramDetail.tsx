import Image from "next/image";
import type { Program } from "@/data/programs";
import { images } from "@/data/generated/images";
import { Button } from "@/components/ui/Button";
import { Tag } from "@/components/ui/Tag";
import { Icon } from "@/components/ui/Icon";
import { SourceNote } from "@/components/ui/SourceNote";

/** Long-form program block: image + title + who/how/participate + links. Only renders the fields the source provides. */
export function ProgramDetail({ program, anchor = false, headingLevel = 3 }: { program: Program; anchor?: boolean; headingLevel?: 1 | 2 | 3 }) {
  const img = images[program.image];
  const H = (`h${headingLevel}` as unknown) as "h3";
  return (
    <article id={anchor ? program.slug : undefined} className="grid gap-8 scroll-mt-28 lg:grid-cols-[minmax(0,24rem)_1fr] lg:gap-12">
      <div className="chamfer-frame self-start">
        <div className="chamfer overflow-hidden bg-ink-850">
          <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 384px, 100vw" className="aspect-[4/3] w-full object-cover" />
        </div>
      </div>
      <div>
        <Tag>{program.category}</Tag>
        <H className={headingLevel === 1 ? "mt-3 text-display-md uppercase text-ink-50" : "mt-3 font-display text-3xl font-bold uppercase leading-none text-ink-50 sm:text-4xl"}>{program.title}</H>
        <p className="mt-4 text-lg leading-relaxed text-ink-100">{program.short}</p>
        <dl className="mt-6 grid gap-5 sm:grid-cols-2">
          {program.whoFor ? (
            <div className="rounded border border-ink-700 bg-ink-900/60 p-4">
              <dt className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">
                <Icon name="users" className="h-4 w-4" /> Who it’s for
              </dt>
              <dd className="mt-2 text-ink-200">{program.whoFor}</dd>
            </div>
          ) : null}
          {program.howToParticipate ? (
            <div className="rounded border border-ink-700 bg-ink-900/60 p-4">
              <dt className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">
                <Icon name="arrow-right" className="h-4 w-4" /> How to take part
              </dt>
              <dd className="mt-2 text-ink-200">{program.howToParticipate}</dd>
            </div>
          ) : null}
        </dl>
        {program.howItWorks?.length ? (
          <div className="mt-6">
            <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">How it works</p>
            <ul className="mt-2 space-y-2">
              {program.howItWorks.map((h) => (
                <li key={h.slice(0, 40)} className="flex gap-3 text-ink-200">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rotate-45 bg-gold-500" aria-hidden="true" />
                  <span>{h}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
        {program.links?.length || program.contact ? (
          <div className="mt-6 flex flex-wrap gap-3">
            {program.links?.map((l) => (
              <Button key={l.href} href={l.href} variant={l.external ? "discord" : "secondary"} size="sm" icon={l.external ? "external" : "arrow-right"} external={l.external}>
                {l.label}
              </Button>
            ))}
            {program.contact ? (
              <Button href={`mailto:${program.contact}`} variant="ghost" icon="mail" iconPosition="left" size="sm">
                {program.contact}
              </Button>
            ) : null}
          </div>
        ) : null}
        <SourceNote>Source: {program.source}.</SourceNote>
      </div>
    </article>
  );
}
