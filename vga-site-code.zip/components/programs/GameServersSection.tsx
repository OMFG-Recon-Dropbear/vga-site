import Image from "next/image";
import { digitalSocials, gameServers, legacyServerLogos } from "@/data/programs";
import { site } from "@/data/site";
import { images } from "@/data/generated/images";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { SourceNote } from "@/components/ui/SourceNote";

export function GameServersSection() {
  return (
    <>
      <Section tone="raised" labelledBy="schedule">
        <SectionHeader id="schedule" eyebrow="Digital socials" title="Weekly social game nights" lead="Jump on, have a game, and connect with others who get it. There’s no pressure, no expectations, and no need to be “good” at anything." action={<Button href={site.socials.discord} variant="discord" icon="discord" iconPosition="left">Join on Discord</Button>} />
        <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {digitalSocials.map((d) => (
            <li key={d.day} className="card p-5">
              <p className="font-display text-xl font-bold uppercase tracking-[0.12em] text-gold-200">{d.day}</p>
              <ul className="mt-3 divide-y divide-ink-700/70">
                {d.sessions.map((s) => (
                  <li key={s.game} className="flex items-baseline justify-between gap-4 py-2">
                    <span className="font-medium text-ink-50">{s.game}</span>
                    <span className="shrink-0 text-right text-sm text-ink-300">
                      {s.time}
                      <span className="block text-xs uppercase tracking-[0.12em] text-ink-500">{s.cadence}</span>
                    </span>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ol>
        <SourceNote>Schedule as published in the VGA May–August 2026 newsletter. Times are AEST. Check Discord for the current week.</SourceNote>
      </Section>
      <Section labelledBy="servers">
        <SectionHeader id="servers" eyebrow="24/7 community game servers" title="Always-on servers" lead="Connection isn’t limited to our scheduled social nights. VGA maintains a growing range of 24/7 community game servers so you can jump online, play together and connect at a time that works for you." />
        <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {gameServers.map((g) => {
            const img = g.image ? images[g.image] : null;
            return (
              <li key={g.name} className="card flex flex-col items-center justify-center gap-3 p-4 text-center">
                {img ? (
                  <span className="flex h-16 w-full items-center justify-center rounded bg-ink-950 p-2">
                    <Image src={img.src} alt="" width={img.width} height={img.height} sizes="160px" className="max-h-full w-auto max-w-full object-contain" />
                  </span>
                ) : (
                  <span className="flex h-16 w-full items-center justify-center rounded bg-ink-950 text-ink-600" aria-hidden="true">
                    <Icon name="server" className="h-7 w-7" />
                  </span>
                )}
                <span className="font-display text-lg font-semibold uppercase text-ink-50">{g.name}</span>
              </li>
            );
          })}
        </ul>
        <p className="mt-6 text-ink-300">
          Also seen on VGA’s servers page: {legacyServerLogos.map((l) => l.name).join(" and ")}.
        </p>
        <div className="mt-8 rounded-lg border border-discord/50 bg-discord/10 p-5 text-ink-100">
          <p className="font-display text-xl font-bold uppercase">How to get server details</p>
          <p className="mt-2">Join our Discord and select the relevant game role to find the server details. If you get stuck, raise a support ticket and our team will help you.</p>
          <Button href={site.socials.discord} variant="discord" icon="discord" iconPosition="left" className="mt-4">
            discord.gg/veterangamingaustralia
          </Button>
        </div>
        <SourceNote>Server list from the VGA May–August 2026 newsletter.</SourceNote>
      </Section>
    </>
  );
}
