import { allPosts } from "@/lib/content";
import { NewsCard } from "@/components/community/NewsCard";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";

export function CarePackageStories() {
  const stories = allPosts().filter((p) => /care-package/.test(p.slug));
  if (!stories.length) return null;
  return (
    <Section tone="raised" labelledBy="care-stories">
      <SectionHeader id="care-stories" eyebrow="Care package stories" title="What a care package can mean" lead="Real requests and real replies, as VGA published them." />
      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {stories.map((p) => (
          <li key={p.slug}>
            <NewsCard post={p} />
          </li>
        ))}
      </ul>
    </Section>
  );
}
