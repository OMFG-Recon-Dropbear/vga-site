import Image from "next/image";
import Link from "next/link";
import type { Program } from "@/data/programs";
import { images } from "@/data/generated/images";
import { Icon } from "@/components/ui/Icon";
import { Tag } from "@/components/ui/Tag";
import { isExternal } from "@/lib/utils";

export function ProgramCard({ program }: { program: Program }) {
  const img = images[program.image];
  const inner = (
    <>
      <div className="relative aspect-[4/3] overflow-hidden bg-ink-800">
        <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 400px, (min-width: 640px) 50vw, 100vw" className="h-full w-full object-cover transition duration-500 ease-out group-hover:scale-[1.04]" />
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-ink-850 to-transparent" aria-hidden="true" />
        <Tag className="absolute left-4 top-4 backdrop-blur-sm">{program.category}</Tag>
      </div>
      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <h3 className="font-display text-2xl font-bold uppercase leading-none text-ink-50 transition group-hover:text-gold-200">{program.title}</h3>
        <p className="mt-3 flex-1 text-[0.95rem] leading-relaxed text-ink-200 line-clamp-4">{program.short}</p>
        <span className="mt-5 inline-flex items-center gap-2 font-display text-base font-semibold uppercase tracking-[0.1em] text-gold-300">
          Learn more <Icon name="arrow-right" className="h-4 w-4 transition group-hover:translate-x-1" />
        </span>
      </div>
    </>
  );
  const cls = "card card-hover group flex h-full flex-col overflow-hidden";
  return isExternal(program.href) ? (
    <a href={program.href} className={cls} target="_blank" rel="noopener noreferrer">
      {inner}
    </a>
  ) : (
    <Link href={program.href} className={cls}>
      {inner}
    </Link>
  );
}
