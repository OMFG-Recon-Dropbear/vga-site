import type { ReactNode } from "react";
import { Icon } from "./Icon";
import { cn } from "@/lib/utils";

/** Native, keyboard-accessible disclosure list (no JS required). */
export function Accordion({ items, className, open = 0 }: { items: { heading: string; content: ReactNode }[]; className?: string; open?: number | null }) {
  return (
    <div className={cn("divide-y divide-ink-700 border-y border-ink-700", className)}>
      {items.map((item, i) => (
        <details key={item.heading} className="group" open={open === i ? true : undefined}>
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-4 pr-1 font-display text-xl font-semibold uppercase tracking-[0.04em] text-ink-50 transition hover:text-gold-200 [&::-webkit-details-marker]:hidden">
            <span>{item.heading}</span>
            <Icon name="chevron-down" className="h-5 w-5 shrink-0 text-gold-500 transition group-open:rotate-180" />
          </summary>
          <div className="pb-5 text-ink-200">{item.content}</div>
        </details>
      ))}
    </div>
  );
}
