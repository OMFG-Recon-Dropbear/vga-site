import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type Props = {
  eyebrow?: string;
  title: ReactNode;
  lead?: ReactNode;
  align?: "left" | "center";
  as?: "h1" | "h2" | "h3";
  size?: "lg" | "md" | "sm";
  className?: string;
  action?: ReactNode;
  id?: string;
};

export function SectionHeader({ eyebrow, title, lead, align = "left", as = "h2", size = "md", className, action, id }: Props) {
  const Tag = as;
  const titleSize = size === "lg" ? "text-display-lg" : size === "sm" ? "text-display-sm" : "text-display-md";
  return (
    <div className={cn("mb-10 sm:mb-12", align === "center" ? "text-center mx-auto max-w-3xl" : "", action ? "sm:flex sm:items-end sm:justify-between sm:gap-8" : "", className)}>
      <div className={cn(align === "center" ? "mx-auto" : "", "max-w-3xl")}>
        {eyebrow ? <p className={cn("eyebrow mb-4", align === "center" ? "justify-center" : "")}>{eyebrow}</p> : null}
        <Tag id={id} className={cn("font-display uppercase text-ink-50", titleSize)}>
          {title}
        </Tag>
        {lead ? <div className="mt-4 text-lg leading-relaxed text-ink-200 sm:text-xl">{lead}</div> : null}
      </div>
      {action ? <div className="mt-6 shrink-0 sm:mt-0">{action}</div> : null}
    </div>
  );
}
