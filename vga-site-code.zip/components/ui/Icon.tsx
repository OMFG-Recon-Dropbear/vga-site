import type { SVGProps, ReactElement } from "react";

export type IconName =
  | "discord"
  | "facebook"
  | "instagram"
  | "youtube"
  | "twitch"
  | "patreon"
  | "arrow-right"
  | "arrow-up-right"
  | "external"
  | "map-pin"
  | "calendar"
  | "clock"
  | "mail"
  | "menu"
  | "close"
  | "chevron-down"
  | "chevron-right"
  | "chevron-left"
  | "download"
  | "controller"
  | "shield"
  | "heart"
  | "users"
  | "play"
  | "check"
  | "search"
  | "share"
  | "link"
  | "x-social"
  | "linkedin"
  | "trophy"
  | "server"
  | "package"
  | "hospital"
  | "plane"
  | "paint"
  | "info"
  | "star";

const paths: Record<IconName, ReactElement> = {
  discord: (
    <path fill="currentColor" d="M20.3 4.4A19.8 19.8 0 0 0 15.4 3l-.2.4a13.5 13.5 0 0 1 3.9 1.9 16 16 0 0 0-14.2 0 13.5 13.5 0 0 1 3.9-1.9L8.6 3a19.8 19.8 0 0 0-4.9 1.5C.6 9.1-.2 13.6.2 18.1a20 20 0 0 0 6 3l1.3-2.1a12.8 12.8 0 0 1-2-1l.5-.4a14.2 14.2 0 0 0 12 0l.5.4a12.8 12.8 0 0 1-2 1l1.3 2.1a20 20 0 0 0 6-3c.5-5.2-.8-9.7-3.5-13.7ZM8 15.4c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4 2.2 1.1 2.1 2.4c0 1.3-.9 2.4-2.1 2.4Zm8 0c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4 2.2 1.1 2.1 2.4c0 1.3-.9 2.4-2.1 2.4Z" />
  ),
  facebook: <path fill="currentColor" d="M13.5 22v-8h2.7l.4-3.2h-3.1V8.8c0-.9.3-1.6 1.6-1.6h1.7V4.4c-.3 0-1.3-.1-2.5-.1-2.5 0-4.1 1.5-4.1 4.2v2.3H7.4V14h2.8v8h3.3Z" />,
  instagram: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="17.3" cy="6.7" r="1.2" fill="currentColor" />
    </>
  ),
  youtube: (
    <path fill="currentColor" d="M22.5 7.2a2.8 2.8 0 0 0-2-2C18.8 4.8 12 4.8 12 4.8s-6.8 0-8.5.4a2.8 2.8 0 0 0-2 2C1.1 8.9 1.1 12 1.1 12s0 3.1.4 4.8a2.8 2.8 0 0 0 2 2c1.7.4 8.5.4 8.5.4s6.8 0 8.5-.4a2.8 2.8 0 0 0 2-2c.4-1.7.4-4.8.4-4.8s0-3.1-.4-4.8ZM9.8 15.1V8.9l5.7 3.1-5.7 3.1Z" />
  ),
  twitch: <path fill="currentColor" d="M4.3 2 2.5 6.4v14.2h4.9V23h2.7l2.6-2.4h3.9l5.2-5.2V2H4.3Zm15.7 12.5-3 3h-4.9l-2.6 2.6v-2.6H5.3V3.9H20v10.6Zm-3-6.9h-1.9v5.4H17V7.6Zm-4.9 0h-1.9v5.4h1.9V7.6Z" />,
  patreon: (
    <>
      <circle cx="14.8" cy="9.2" r="6.2" fill="currentColor" />
      <rect x="2.5" y="3" width="3.6" height="18" fill="currentColor" />
    </>
  ),
  "arrow-right": <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m-6-6 6 6-6 6" />,
  "arrow-up-right": <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M7 17 17 7M8 7h9v9" />,
  external: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M14 4h6v6m0-6-9 9M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5" />,
  "map-pin": (
    <>
      <path fill="none" stroke="currentColor" strokeWidth="2" d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12Z" />
      <circle cx="12" cy="10" r="2.5" fill="none" stroke="currentColor" strokeWidth="2" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
      <path stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M3 10h18M8 3v4m8-4v4" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" />
      <path stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M12 7v5l3 2" />
    </>
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
      <path fill="none" stroke="currentColor" strokeWidth="2" d="m3 7 9 6 9-6" />
    </>
  ),
  menu: <path stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M4 7h16M4 12h16M4 17h16" />,
  close: <path stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M6 6l12 12M18 6 6 18" />,
  "chevron-down": <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="m6 9 6 6 6-6" />,
  "chevron-right": <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="m9 6 6 6-6 6" />,
  "chevron-left": <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="m15 6-6 6 6 6" />,
  download: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M12 4v11m0 0 4-4m-4 4-4-4M4 17v2a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-2" />,
  controller: (
    <>
      <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M6.5 7h11a4.5 4.5 0 0 1 4.4 3.6l1 6.2a2.4 2.4 0 0 1-4.1 2l-2.3-2.3H7.5L5.2 18.8a2.4 2.4 0 0 1-4.1-2l1-6.2A4.5 4.5 0 0 1 6.5 7Z" />
      <path stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M8 10.5v3M6.5 12h3" />
      <circle cx="15.5" cy="11" r="1" fill="currentColor" />
      <circle cx="17.5" cy="13" r="1" fill="currentColor" />
    </>
  ),
  shield: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M12 3 4.5 6v5.5c0 4.8 3.2 8.4 7.5 9.5 4.3-1.1 7.5-4.7 7.5-9.5V6L12 3Z" />,
  heart: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M12 20.5s-8-4.9-8-11A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8 2.5c0 6.1-8 11-8 11Z" />,
  users: (
    <>
      <circle cx="9" cy="8" r="3.5" fill="none" stroke="currentColor" strokeWidth="2" />
      <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4.5-6.2" />
    </>
  ),
  play: <path fill="currentColor" d="M8 5.5v13l11-6.5-11-6.5Z" />,
  check: <path fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" d="m5 12.5 4.5 4.5L19 7.5" />,
  search: (
    <>
      <circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" strokeWidth="2" />
      <path stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="m20 20-4.3-4.3" />
    </>
  ),
  share: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M12 3v12m0-12 4 4m-4-4L8 7" />,
  link: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" />,
  "x-social": <path fill="currentColor" d="M17.5 3h3.1l-6.8 7.8L21.8 21h-6.3l-4.9-6.4L5 21H1.9l7.3-8.3L1.5 3h6.4l4.4 5.9L17.5 3Zm-1.1 16.2h1.7L6.9 4.7H5.1l11.3 14.5Z" />,
  linkedin: <path fill="currentColor" d="M20.4 2H3.6A1.6 1.6 0 0 0 2 3.6v16.8A1.6 1.6 0 0 0 3.6 22h16.8a1.6 1.6 0 0 0 1.6-1.6V3.6A1.6 1.6 0 0 0 20.4 2ZM8 19H5V9.5h3V19ZM6.5 8.2a1.7 1.7 0 1 1 0-3.5 1.7 1.7 0 0 1 0 3.5ZM19 19h-3v-4.6c0-1.1 0-2.5-1.5-2.5s-1.8 1.2-1.8 2.4V19h-3V9.5h2.9v1.3a3.2 3.2 0 0 1 2.8-1.6c3 0 3.6 2 3.6 4.6V19Z" />,
  trophy: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M7 4h10v5a5 5 0 0 1-10 0V4Zm10 1h3a3 3 0 0 1-3 4M7 5H4a3 3 0 0 0 3 4m5 5v3m-4 3h8" />,
  server: (
    <>
      <rect x="3" y="4" width="18" height="6" rx="1.5" fill="none" stroke="currentColor" strokeWidth="2" />
      <rect x="3" y="14" width="18" height="6" rx="1.5" fill="none" stroke="currentColor" strokeWidth="2" />
      <circle cx="7" cy="7" r="1" fill="currentColor" />
      <circle cx="7" cy="17" r="1" fill="currentColor" />
    </>
  ),
  package: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Zm0 9 8-4.5M12 12v9m0-9L4 7.5" />,
  hospital: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M4 21V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16M2 21h20M12 7v6m-3-3h6M9 21v-4h6v4" />,
  plane: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M2.5 16.5 21 9.5a1.3 1.3 0 0 0-.5-2.5l-3.3.6L11 3.5 9 4.3l4.2 5-5 1.4-3.2-2-1.5.6 2.5 3.4-1.4 3.8Z" />,
  paint: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M18.5 3.5 21 6l-9 9-3.5 1 1-3.5 9-9ZM9 15.5c-2.5 0-4 1.6-4 3.5 0 1.3-1 2-2 2 1.5 1 5 1.3 6.6-1" />,
  info: (
    <>
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" />
      <path stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M12 11v5m0-8v.5" />
    </>
  ),
  star: <path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="m12 3 2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 17l-5.4 2.8 1.1-6.1L3.2 9.4l6.1-.8L12 3Z" />,
};

export function Icon({ name, className = "h-5 w-5", ...rest }: { name: IconName; className?: string } & SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" className={className} {...rest}>
      {paths[name]}
    </svg>
  );
}
