import Link from "next/link";
import type { ReactNode, ButtonHTMLAttributes } from "react";
import { cn, isExternal } from "@/lib/utils";
import { Icon, type IconName } from "./Icon";

type Variant = "primary" | "secondary" | "ghost" | "discord" | "dark";
type Size = "sm" | "md" | "lg";

const base = "group/btn inline-flex max-w-full items-center justify-center font-display font-semibold uppercase tracking-[0.08em] leading-none select-none transition duration-200 ease-out disabled:opacity-50 disabled:pointer-events-none";

const solid: Record<Exclude<Variant, "secondary" | "ghost">, string> = {
  primary: "chamfer-sm bg-gold-500 text-ink-950 hover:bg-gold-300 active:bg-gold-600",
  discord: "chamfer-sm bg-discord text-white hover:bg-[#4752C4]",
  dark: "chamfer-sm bg-ink-800 text-ink-50 border border-ink-600 hover:border-gold-500/70 hover:bg-ink-700",
};

const sizes: Record<Size, string> = {
  sm: "text-sm px-4 py-2.5",
  md: "text-[0.95rem] px-5 py-3",
  lg: "text-lg px-7 py-4",
};

export type ButtonProps = {
  href?: string;
  variant?: Variant;
  size?: Size;
  icon?: IconName;
  iconPosition?: "left" | "right";
  className?: string;
  children: ReactNode;
  external?: boolean;
} & Omit<ButtonHTMLAttributes<HTMLButtonElement>, "className" | "children">;

export function Button({ href, variant = "primary", size = "md", icon, iconPosition = "right", className, children, external, ...rest }: ButtonProps) {
  const iconEl = icon ? <Icon name={icon} className="h-[1.1em] w-[1.1em] shrink-0 transition group-hover/btn:translate-x-0.5" /> : null;
  const label = (
    <>
      {iconPosition === "left" ? iconEl : null}
      <span>{children}</span>
      {iconPosition === "right" ? iconEl : null}
    </>
  );

  let cls: string;
  let content: ReactNode;
  if (variant === "ghost") {
    cls = cn(base, "gap-2 whitespace-normal text-left text-gold-200 underline-offset-4 hover:text-gold-100 hover:underline", size === "sm" ? "text-sm" : size === "lg" ? "text-lg" : "text-[0.95rem]", className);
    content = label;
  } else if (variant === "secondary") {
    // Outlined chamfer: gold gradient frame with a dark inner face
    cls = cn(base, "chamfer-sm bg-gradient-to-br from-gold-200 via-gold-500 to-gold-700 p-px text-gold-200 hover:from-gold-100 hover:to-gold-500 hover:text-gold-100", className);
    content = <span className={cn("chamfer-sm flex w-full items-center justify-center gap-2 whitespace-normal text-center bg-ink-900 transition group-hover/btn:bg-ink-800", sizes[size])}>{label}</span>;
  } else {
    cls = cn(base, "gap-2 whitespace-normal text-center", solid[variant], sizes[size], className);
    content = label;
  }

  if (href) {
    const ext = external ?? isExternal(href);
    if (ext) {
      return (
        <a href={href} className={cls} target={href.startsWith("mailto:") || href.startsWith("tel:") ? undefined : "_blank"} rel="noopener noreferrer">
          {content}
        </a>
      );
    }
    return (
      <Link href={href} className={cls}>
        {content}
      </Link>
    );
  }
  return (
    <button type="button" className={cls} {...rest}>
      {content}
    </button>
  );
}
