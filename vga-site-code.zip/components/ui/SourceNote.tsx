import { Icon } from "./Icon";

/** Small provenance line — where a figure or statement was published. */
export function SourceNote({ children }: { children: React.ReactNode }) {
  return (
    <p className="mt-3 flex items-start gap-2 text-xs text-ink-400">
      <Icon name="info" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
      <span>{children}</span>
    </p>
  );
}
