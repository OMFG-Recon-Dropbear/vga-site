import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Tag({ children, tone = "gold", className }: { children: ReactNode; tone?: "gold" | "grey" | "green" | "discord"; className?: string }) {
  const tones = {
    gold: "border-gold-700/70 bg-gold-500/10 text-gold-200",
    grey: "border-ink-600 bg-ink-800 text-ink-200",
    green: "border-emerald-700/60 bg-emerald-500/10 text-emerald-300",
    discord: "border-discord/60 bg-discord/15 text-[#c7ccff]",
  } as const;
  return <span className={cn("inline-flex items-center gap-1 rounded-sm border px-2 py-0.5 font-sans text-[0.7rem] font-semibold uppercase tracking-[0.14em]", tones[tone], className)}>{children}</span>;
}
