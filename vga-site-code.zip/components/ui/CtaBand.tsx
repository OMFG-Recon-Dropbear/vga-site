import type { ReactNode } from "react";
import { Button } from "./Button";
import type { IconName } from "./Icon";

type Cta = { label: string; href: string; variant?: "primary" | "secondary" | "discord" | "ghost"; icon?: IconName };

export function CtaBand({ eyebrow, title, body, ctas, children }: { eyebrow?: string; title: ReactNode; body?: ReactNode; ctas: Cta[]; children?: ReactNode }) {
  return (
    <section className="container py-16 sm:py-20" aria-label="Get involved">
      <div className="chamfer-frame">
        <div className="chamfer relative overflow-hidden bg-ink-950 px-6 py-12 sm:px-12 sm:py-16">
          <div className="absolute inset-0 bg-grid opacity-40 [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" aria-hidden="true" />
          <div className="relative grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-center">
            <div>
              {eyebrow ? <p className="eyebrow mb-3">{eyebrow}</p> : null}
              <h2 className="text-display-md uppercase text-ink-50">{title}</h2>
              {body ? <div className="mt-4 max-w-2xl break-words text-lg text-ink-200">{body}</div> : null}
              {children}
            </div>
            <div className="flex flex-wrap gap-3 lg:justify-end">
              {ctas.map((c) => (
                <Button key={c.href + c.label} href={c.href} variant={c.variant ?? "primary"} size="lg" icon={c.icon} iconPosition={c.icon === "discord" || c.icon === "heart" || c.icon === "map-pin" ? "left" : "right"}>
                  {c.label}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
