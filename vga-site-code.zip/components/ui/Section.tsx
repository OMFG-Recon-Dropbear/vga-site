import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Section({ children, className, innerClassName, tone = "default", id, labelledBy }: { children: ReactNode; className?: string; innerClassName?: string; tone?: "default" | "raised" | "deep"; id?: string; labelledBy?: string }) {
  const tones = { default: "", raised: "border-y border-ink-700/60 bg-ink-850", deep: "border-y border-ink-700/60 bg-ink-950" };
  return (
    <section id={id} aria-labelledby={labelledBy} className={cn(tones[tone], className)}>
      <div className={cn("container py-16 sm:py-20 lg:py-24", innerClassName)}>{children}</div>
    </section>
  );
}
