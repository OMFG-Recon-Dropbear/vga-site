import Link from "next/link";
import { Icon } from "./Icon";
import { JsonLd } from "./JsonLd";
import { breadcrumbJsonLd } from "@/lib/seo";

export type Crumb = { name: string; path: string };

export function Breadcrumbs({ items, className = "" }: { items: Crumb[]; className?: string }) {
  const all: Crumb[] = [{ name: "Home", path: "/" }, ...items];
  return (
    <nav aria-label="Breadcrumb" className={className}>
      <JsonLd data={breadcrumbJsonLd(all)} />
      <ol className="flex flex-wrap items-center gap-1 text-sm text-ink-300">
        {all.map((c, i) => {
          const last = i === all.length - 1;
          return (
            <li key={c.path} className="flex items-center gap-1">
              {i > 0 ? <Icon name="chevron-right" className="h-3.5 w-3.5 text-ink-500" /> : null}
              {last ? (
                <span aria-current="page" className="text-ink-100">
                  {c.name}
                </span>
              ) : (
                <Link href={c.path} className="hover:text-gold-200">
                  {c.name}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
