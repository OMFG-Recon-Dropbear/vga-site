import Image from "next/image";
import type { ReactNode } from "react";
import { images, type ImageKey } from "@/data/generated/images";
import { cn } from "@/lib/utils";
import { Breadcrumbs, type Crumb } from "./Breadcrumbs";

type Props = {
  eyebrow?: string;
  title: ReactNode;
  lead?: ReactNode;
  image?: ImageKey;
  imagePosition?: string; // object-position
  crumbs?: Crumb[];
  children?: ReactNode; // CTAs
  compact?: boolean;
  align?: "left" | "center";
};

export function PageHero({ eyebrow, title, lead, image, imagePosition = "center", crumbs, children, compact, align = "left" }: Props) {
  const asset = image ? images[image] : null;
  return (
    <section className={cn("relative isolate overflow-hidden border-b border-ink-700/60", asset ? "bg-ink-950" : "bg-ink-900")}>
      {asset ? (
        <>
          <Image
            src={asset.src}
            alt=""
            width={asset.width}
            height={asset.height}
            priority
            sizes="100vw"
            className="absolute inset-0 -z-20 h-full w-full object-cover opacity-45"
            style={{ objectPosition: imagePosition }}
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-950 via-ink-950/85 to-ink-950/40" />
          <div className="absolute inset-0 -z-10 bg-gradient-to-t from-ink-900 via-transparent to-ink-950/40" />
        </>
      ) : (
        <div className="absolute inset-0 -z-10 bg-grid bg-grid-fade opacity-70" aria-hidden="true" />
      )}
      <div className={cn("container", compact ? "py-14 sm:py-18" : "py-18 sm:py-24 lg:py-28")}>
        {crumbs ? <Breadcrumbs items={crumbs} className="mb-6" /> : null}
        <div className={cn("max-w-3xl", align === "center" ? "mx-auto text-center" : "")}>
          {eyebrow ? <p className={cn("eyebrow mb-4", align === "center" ? "justify-center" : "")}>{eyebrow}</p> : null}
          <h1 className="text-display-lg uppercase text-ink-50">{title}</h1>
          {lead ? <div className="mt-5 max-w-2xl text-lg leading-relaxed text-ink-200 sm:text-xl">{lead}</div> : null}
          {children ? <div className={cn("mt-8 flex flex-wrap gap-3", align === "center" ? "justify-center" : "")}>{children}</div> : null}
        </div>
      </div>
    </section>
  );
}
