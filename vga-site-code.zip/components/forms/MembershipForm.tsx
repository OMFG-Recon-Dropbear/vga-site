"use client";

import { useState, type FormEvent } from "react";
import { membership } from "@/data/support";
import { site } from "@/data/site";
import { useFormSubmit } from "./useFormSubmit";
import { FormStatus, Honeypot, RadioGroup, SelectField, TextField } from "./Field";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

/**
 * Member Application — the same three steps and fields as the previous site's form
 * (contact details & address → service details & verification → optional postal address).
 */
const steps = ["Your details", "Service & verification", "Postal address (optional)"] as const;

export function MembershipForm() {
  const { state, submit } = useFormSubmit("membership");
  const [step, setStep] = useState(0);
  const [formEl, setFormEl] = useState<HTMLFormElement | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);

  function validateStep(): boolean {
    if (!formEl) return true;
    const fieldset = formEl.querySelector<HTMLFieldSetElement>(`[data-step="${step}"]`);
    if (!fieldset) return true;
    const controls = Array.from(fieldset.querySelectorAll<HTMLInputElement | HTMLSelectElement>("input, select"));
    for (const c of controls) {
      if (!c.checkValidity()) {
        c.reportValidity();
        return false;
      }
    }
    return true;
  }

  function next() {
    if (validateStep()) setStep((s) => Math.min(s + 1, steps.length - 1));
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!validateStep()) return;
    const fd = new FormData(e.currentTarget);
    if (fd.get("website")) return;
    const file = fd.get("verificationFile");
    if (file instanceof File && file.size > 10 * 1024 * 1024) {
      setFileError("Please upload a file smaller than 10 MB.");
      const input = e.currentTarget.querySelector<HTMLInputElement>("#f-verificationFile");
      input?.focus();
      return;
    }
    setFileError(null);
    await submit(fd);
  }

  if (state.status === "success") {
    return (
      <FormStatus
        status="success"
        successTitle="Application received."
        message={state.message ?? "One of our team will be in touch by phone or email with important information to connect with the VGA community."}
      />
    );
  }

  return (
    <form ref={setFormEl} onSubmit={onSubmit} encType="multipart/form-data" className="space-y-8">
      <Honeypot />
      <ol className="flex flex-wrap gap-2" aria-label="Application steps">
        {steps.map((s, i) => (
          <li key={s} className={cn("flex items-center gap-2 rounded-sm border px-3 py-1.5 text-sm", i === step ? "border-gold-500 bg-gold-500/10 text-gold-100" : i < step ? "border-ink-600 text-ink-200" : "border-ink-700 text-ink-400")} aria-current={i === step ? "step" : undefined}>
            <span className="font-display text-base font-bold">{i < step ? <Icon name="check" className="h-4 w-4 text-gold-300" /> : i + 1}</span>
            {s}
          </li>
        ))}
      </ol>

      {/* Step 1 */}
      <fieldset data-step={0} hidden={step !== 0} className="space-y-5">
        <legend className="font-display text-2xl font-bold uppercase text-ink-50">Your details</legend>
        <div className="grid gap-5 sm:grid-cols-2">
          <TextField label="First name" name="firstName" required autoComplete="given-name" />
          <TextField label="Last name" name="lastName" required autoComplete="family-name" />
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <TextField label="Phone" name="phone" type="tel" required autoComplete="tel" inputMode="tel" />
          <TextField label="Email" name="email" type="email" required autoComplete="email" />
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <TextField label="Address" name="address" required autoComplete="address-line1" className="sm:col-span-2" />
          <TextField label="City / Suburb" name="city" required autoComplete="address-level2" />
          <TextField label="State" name="state" required autoComplete="address-level1" />
          <TextField label="Postcode" name="postcode" required autoComplete="postal-code" inputMode="numeric" />
          <TextField label="Country" name="country" required autoComplete="country-name" defaultValue="Australia" />
        </div>
      </fieldset>

      {/* Step 2 */}
      <fieldset data-step={1} hidden={step !== 1} className="space-y-6">
        <legend className="font-display text-2xl font-bold uppercase text-ink-50">Service & verification</legend>
        <RadioGroup label="Gender" name="gender" options={membership.genders} required />
        <TextField label="Date of birth" name="dateOfBirth" type="date" required autoComplete="bday" />
        <RadioGroup label="Service" name="service" options={membership.services} required />
        <RadioGroup label="Serving or transitioned" name="status" options={membership.status} required />
        <div className="rounded border border-gold-700/50 bg-gold-500/5 p-4 text-sm text-ink-100">
          <p>{membership.verificationNotice}</p>
        </div>
        <SelectField label="Please choose verification type" name="verificationType" required hint={membership.dpnNote}>
          <option value="">Select…</option>
          {membership.verificationTypes.map((v) => (
            <option key={v} value={v}>
              {v}
            </option>
          ))}
        </SelectField>
        <div>
          <label htmlFor="f-verificationFile" className="label">
            Upload documents or images <span className="text-gold-300">*</span>
          </label>
          <input id="f-verificationFile" name="verificationFile" type="file" required accept=".pdf,.jpg,.jpeg,.png,.heic,.webp" aria-invalid={fileError ? true : undefined} aria-describedby={fileError ? "f-verificationFile-error" : undefined} onChange={() => setFileError(null)} className="input file:mr-4 file:rounded file:border-0 file:bg-gold-500 file:px-3 file:py-1.5 file:font-semibold file:text-ink-950" />
          {fileError ? (
            <p id="f-verificationFile-error" role="alert" className="mt-2 text-sm text-red-300">
              {fileError}
            </p>
          ) : null}
          <p className="mt-1.5 text-sm text-ink-300">PDF or image, up to 10 MB. Your documents are only used to verify eligibility.</p>
        </div>
        <label className="flex items-start gap-3 text-ink-100">
          <input type="checkbox" name="understand" required className="mt-1 h-4 w-4 accent-gold-500" />
          <span>I understand</span>
        </label>
        <div className="rounded border border-discord/50 bg-discord/10 p-4 text-sm text-ink-100">
          <p>
            Please join our Discord at{" "}
            <a href={site.socials.discord} target="_blank" rel="noopener noreferrer" className="text-[#c7ccff] underline underline-offset-4">
              discord.gg/veterangamingaustralia
            </a>{" "}
            and provide your Discord username below so we can give you the verified role.
          </p>
        </div>
        <TextField label="My Discord username is" name="discordUsername" autoComplete="off" />
      </fieldset>

      {/* Step 3 */}
      <fieldset data-step={2} hidden={step !== 2} className="space-y-5">
        <legend className="font-display text-2xl font-bold uppercase text-ink-50">Postal address (optional)</legend>
        <p className="text-ink-300">If your postal address is different from your home address, add it here.</p>
        <div className="grid gap-5 sm:grid-cols-2">
          <TextField label="Postal address" name="postalAddress" className="sm:col-span-2" />
          <TextField label="City / Suburb" name="postalCity" />
          <TextField label="State" name="postalState" />
          <TextField label="Postcode" name="postalPostcode" inputMode="numeric" />
          <TextField label="Country" name="postalCountry" />
        </div>
      </fieldset>

      <FormStatus status={state.status} message={state.message} />

      <div className="flex flex-wrap items-center gap-3">
        {step > 0 ? (
          <Button type="button" variant="secondary" onClick={() => setStep((s) => s - 1)} icon="chevron-left" iconPosition="left">
            Back
          </Button>
        ) : null}
        {step < steps.length - 1 ? (
          <Button type="button" onClick={next} icon="arrow-right">
            Next
          </Button>
        ) : (
          <Button type="submit" size="lg" icon="arrow-right" disabled={state.status === "submitting"}>
            {state.status === "submitting" ? "Submitting…" : "Submit application"}
          </Button>
        )}
      </div>
    </form>
  );
}
