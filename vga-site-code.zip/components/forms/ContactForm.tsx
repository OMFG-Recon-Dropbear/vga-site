"use client";

import { type FormEvent } from "react";
import { useFormSubmit } from "./useFormSubmit";
import { FormStatus, Honeypot, TextArea, TextField } from "./Field";
import { Button } from "@/components/ui/Button";
import { site } from "@/data/site";

export function ContactForm({ subject }: { subject?: string }) {
  const { state, submit } = useFormSubmit("contact");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    if (fd.get("website")) return;
    const payload = Object.fromEntries(fd.entries());
    const ok = await submit(payload);
    if (ok) form.reset();
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5" aria-describedby="contact-help">
      <Honeypot />
      {subject ? <input type="hidden" name="subject" value={subject} /> : null}
      <div className="grid gap-5 sm:grid-cols-2">
        <TextField label="First name" name="firstName" required autoComplete="given-name" />
        <TextField label="Last name" name="lastName" required autoComplete="family-name" />
      </div>
      <TextField label="Email" name="email" type="email" required autoComplete="email" />
      {!subject ? <TextField label="Subject" name="subject" placeholder="e.g. Care package nomination, sponsorship, media" /> : null}
      <TextArea label="Message" name="message" required />
      <p id="contact-help" className="text-sm text-ink-300">
        Prefer email? Write to{" "}
        <a href={`mailto:${site.email}`} className="break-all text-gold-200 underline underline-offset-4 hover:text-gold-100">
          {site.email}
        </a>
        .
      </p>
      <FormStatus status={state.status} message={state.message} successTitle="Message sent." />
      {state.status !== "success" ? (
        <Button type="submit" size="lg" icon="arrow-right" disabled={state.status === "submitting"}>
          {state.status === "submitting" ? "Sending…" : "Send message"}
        </Button>
      ) : null}
    </form>
  );
}
