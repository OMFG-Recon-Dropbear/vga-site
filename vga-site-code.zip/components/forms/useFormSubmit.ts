"use client";

import { useState } from "react";

export type SubmitState = { status: "idle" | "submitting" | "success" | "error"; message?: string };

/**
 * Posts a form to /api/forms/<name>. Sends multipart when a FormData is given (file uploads),
 * otherwise JSON. The API returns { ok, message }.
 */
export function useFormSubmit(name: string) {
  const [state, setState] = useState<SubmitState>({ status: "idle" });

  async function submit(payload: Record<string, unknown> | FormData) {
    setState({ status: "submitting" });
    try {
      const res = await fetch(`/api/forms/${name}`, {
        method: "POST",
        headers: payload instanceof FormData ? undefined : { "Content-Type": "application/json" },
        body: payload instanceof FormData ? payload : JSON.stringify(payload),
      });
      const data = (await res.json().catch(() => ({}))) as { ok?: boolean; message?: string };
      if (!res.ok || !data.ok) {
        setState({ status: "error", message: data.message || "Something went wrong. Please try again, or email us directly." });
        return false;
      }
      setState({ status: "success", message: data.message });
      return true;
    } catch {
      setState({ status: "error", message: "We couldn’t reach the server. Please check your connection and try again, or email us directly." });
      return false;
    }
  }

  return { state, submit, reset: () => setState({ status: "idle" }) };
}
