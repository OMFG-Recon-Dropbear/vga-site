import type { InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Base = { label: string; name: string; hint?: string; error?: string; required?: boolean; className?: string };

export function TextField({ label, name, hint, error, required, className, ...rest }: Base & InputHTMLAttributes<HTMLInputElement>) {
  const id = `f-${name}`;
  return (
    <div className={className}>
      <label htmlFor={id} className="label">
        {label}
        {required ? <span className="text-gold-300"> *</span> : null}
      </label>
      <input id={id} name={name} required={required} aria-invalid={!!error} aria-describedby={hint || error ? `${id}-desc` : undefined} className={cn("input", error ? "border-red-500" : "")} {...rest} />
      {hint || error ? (
        <p id={`${id}-desc`} className={cn("mt-1.5 text-sm", error ? "text-red-300" : "text-ink-300")}>
          {error || hint}
        </p>
      ) : null}
    </div>
  );
}

export function TextArea({ label, name, hint, error, required, className, ...rest }: Base & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const id = `f-${name}`;
  return (
    <div className={className}>
      <label htmlFor={id} className="label">
        {label}
        {required ? <span className="text-gold-300"> *</span> : null}
      </label>
      <textarea id={id} name={name} required={required} rows={5} aria-invalid={!!error} className={cn("input min-h-[8rem]", error ? "border-red-500" : "")} {...rest} />
      {hint || error ? <p className={cn("mt-1.5 text-sm", error ? "text-red-300" : "text-ink-300")}>{error || hint}</p> : null}
    </div>
  );
}

export function SelectField({ label, name, hint, error, required, className, children, ...rest }: Base & SelectHTMLAttributes<HTMLSelectElement> & { children: ReactNode }) {
  const id = `f-${name}`;
  return (
    <div className={className}>
      <label htmlFor={id} className="label">
        {label}
        {required ? <span className="text-gold-300"> *</span> : null}
      </label>
      <select id={id} name={name} required={required} className={cn("input", error ? "border-red-500" : "")} {...rest}>
        {children}
      </select>
      {hint || error ? <p className={cn("mt-1.5 text-sm", error ? "text-red-300" : "text-ink-300")}>{error || hint}</p> : null}
    </div>
  );
}

export function RadioGroup({ label, name, options, required, hint, className }: { label: string; name: string; options: readonly string[]; required?: boolean; hint?: string; className?: string }) {
  return (
    <fieldset className={className}>
      <legend className="label">
        {label}
        {required ? <span className="text-gold-300"> *</span> : null}
      </legend>
      <div className="mt-1 grid gap-2 sm:grid-cols-2">
        {options.map((o) => (
          <label key={o} className="flex cursor-pointer items-center gap-3 rounded border border-ink-600 bg-ink-900 px-3 py-2.5 text-ink-100 transition has-[:checked]:border-gold-500 has-[:checked]:bg-gold-500/10">
            <input type="radio" name={name} value={o} required={required} className="h-4 w-4 accent-gold-500" />
            <span>{o}</span>
          </label>
        ))}
      </div>
      {hint ? <p className="mt-1.5 text-sm text-ink-300">{hint}</p> : null}
    </fieldset>
  );
}

/** Invisible anti-spam field: real users never fill it. */
export function Honeypot() {
  return (
    <div className="absolute -left-[9999px] top-auto h-px w-px overflow-hidden" aria-hidden="true">
      <label htmlFor="website">Website</label>
      <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" />
    </div>
  );
}

export function FormStatus({ status, message, successTitle = "Thanks — we’ve got it." }: { status: "idle" | "submitting" | "success" | "error"; message?: string; successTitle?: string }) {
  if (status === "success") {
    return (
      <div role="status" className="rounded border border-emerald-700/60 bg-emerald-500/10 p-4 text-emerald-100">
        <p className="font-semibold">{successTitle}</p>
        {message ? <p className="mt-1 text-sm">{message}</p> : null}
      </div>
    );
  }
  if (status === "error") {
    return (
      <div role="alert" className="rounded border border-red-700/60 bg-red-500/10 p-4 text-red-100">
        <p className="font-semibold">That didn’t go through.</p>
        {message ? <p className="mt-1 text-sm">{message}</p> : null}
      </div>
    );
  }
  return null;
}
