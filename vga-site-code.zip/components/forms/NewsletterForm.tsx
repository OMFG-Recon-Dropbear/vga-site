"use client";

import { useState, type FormEvent } from "react";
import { useFormSubmit } from "./useFormSubmit";
import { FormStatus, Honeypot } from "./Field";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

export function NewsletterForm({ compact = false }: { compact?: boolean }) {
  const { state, submit } = useFormSubmit("newsletter");
  const [email, setEmail] = useState("");
  const [consent, setConsent] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (fd.get("website")) return; // honeypot
    const ok = await submit({ email, consent, website: fd.get("website") });
    if (ok) setEmail("");
  }

  if (state.status === "success") {
    return (
      <div className="mt-4">
        <FormStatus status="success" message={state.message ?? "You’re on the list."} successTitle="Subscribed." />
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className={cn("mt-4", compact ? "" : "max-w-xl")} noValidate={false}>
      <Honeypot />
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="flex-1">
          <label htmlFor="newsletter-email" className="sr-only">
            Email address
          </label>
          <input
            id="newsletter-email"
            type="email"
            name="email"
            required
            autoComplete="email"
            placeholder="Your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input"
          />
        </div>
        <Button type="submit" disabled={state.status === "submitting"} icon="arrow-right">
          {state.status === "submitting" ? "Sending…" : "Subscribe"}
        </Button>
      </div>
      <label className="mt-3 flex items-start gap-3 text-sm text-ink-300">
        <input type="checkbox" name="consent" required checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-1 h-4 w-4 accent-gold-500" />
        <span>Yes, subscribe me to your newsletter.</span>
      </label>
      {state.status === "error" ? (
        <div className="mt-3">
          <FormStatus status="error" message={state.message} />
        </div>
      ) : null}
    </form>
  );
}
