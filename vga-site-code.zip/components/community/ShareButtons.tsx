"use client";

import { useState } from "react";
import { Icon } from "@/components/ui/Icon";

/** Share controls — the same networks the previous site offered (Facebook, X, WhatsApp, copy link). */
export function ShareButtons({ url, title }: { url: string; title: string }) {
  const [copied, setCopied] = useState(false);
  const enc = encodeURIComponent(url);
  const links = [
    { name: "Facebook", href: `https://www.facebook.com/sharer/sharer.php?u=${enc}`, icon: "facebook" as const },
    { name: "X (Twitter)", href: `https://twitter.com/intent/tweet?url=${enc}&text=${encodeURIComponent(title)}`, icon: "x-social" as const },
    { name: "WhatsApp", href: `https://api.whatsapp.com/send/?text=${encodeURIComponent(`${title} ${url}`)}`, icon: "share" as const },
    { name: "LinkedIn", href: `https://www.linkedin.com/sharing/share-offsite/?url=${enc}`, icon: "linkedin" as const },
  ];
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };
  const cls = "flex h-10 w-10 items-center justify-center rounded-sm border border-ink-600 bg-ink-800 text-ink-100 transition hover:border-gold-500 hover:text-gold-200 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-200";
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="mr-1 font-display text-sm font-semibold uppercase tracking-[0.14em] text-ink-300">Share</span>
      {links.map((l) => (
        <a key={l.name} href={l.href} target="_blank" rel="noopener noreferrer" className={cls} aria-label={`Share on ${l.name} (opens in a new tab)`} title={l.name}>
          <Icon name={l.icon} className="h-4 w-4" />
        </a>
      ))}
      <button type="button" onClick={copy} className={cls} aria-label={copied ? "Link copied" : "Copy link"} title="Copy link">
        <Icon name={copied ? "check" : "link"} className="h-4 w-4" />
      </button>
      <span className="sr-only" aria-live="polite">
        {copied ? "Link copied to clipboard" : ""}
      </span>
    </div>
  );
}
