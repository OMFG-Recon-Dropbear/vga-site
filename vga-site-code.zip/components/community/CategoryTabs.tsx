import Link from "next/link";
import { categories, type CategorySlug } from "@/lib/content";
import { cn } from "@/lib/utils";

export function CategoryTabs({ active, counts }: { active: CategorySlug | "all"; counts: Record<string, number> }) {
  const items: { slug: CategorySlug | "all"; label: string; href: string }[] = [{ slug: "all", label: "All", href: "/news" }, ...categories.map((c) => ({ slug: c.slug, label: c.label, href: c.slug === "galleries" ? "/gallery" : `/news/category/${c.slug}` }))];
  return (
    <nav aria-label="News categories" className="-mx-4 overflow-x-auto px-4 sm:mx-0 sm:px-0">
      <ul className="flex min-w-max gap-2 border-b border-ink-700 pb-px">
        {items.map((it) => {
          const isActive = it.slug === active;
          return (
            <li key={it.slug}>
              <Link href={it.href} aria-current={isActive ? "page" : undefined} className={cn("inline-flex items-center gap-2 border-b-2 px-3 py-3 font-display text-base font-semibold uppercase tracking-[0.1em] transition", isActive ? "border-gold-500 text-gold-200" : "border-transparent text-ink-300 hover:text-ink-50")}>
                {it.label}
                <span className={cn("rounded-sm px-1.5 py-0.5 font-sans text-[0.7rem]", isActive ? "bg-gold-500/15 text-gold-200" : "bg-ink-800 text-ink-400")}>{counts[it.slug] ?? 0}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
