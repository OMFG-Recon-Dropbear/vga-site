import Image from "next/image";
import Link from "next/link";
import type { Post } from "@/lib/content-types";
import { images, type ImageKey } from "@/data/generated/images";
import { formatDate } from "@/lib/utils";
import { Tag } from "@/components/ui/Tag";
import { Icon } from "@/components/ui/Icon";

export function NewsCard({ post, featured = false }: { post: Post; featured?: boolean }) {
  const img = post.hero ? images[post.hero as ImageKey] : null;
  const href = post.category === "Galleries" && post.gallerySlug ? `/gallery/${post.gallerySlug}` : `/news/${post.slug}`;
  return (
    <Link href={href} className="card card-hover group flex h-full flex-col overflow-hidden">
      <div className={`relative overflow-hidden bg-ink-800 ${featured ? "aspect-[16/10]" : "aspect-[16/10]"}`}>
        {img ? (
          <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 768px) 33vw, 100vw" className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
        ) : null}
        <div className="absolute left-4 top-4">
          <Tag>{post.category}</Tag>
        </div>
      </div>
      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <p className="flex items-center gap-2 text-sm text-ink-300">
          <time dateTime={post.date}>{formatDate(post.date)}</time>
          <span aria-hidden="true">·</span>
          <span>{post.readingTime} min read</span>
        </p>
        <h3 className="mt-2 font-display text-2xl font-bold uppercase leading-none text-ink-50 transition group-hover:text-gold-200">{post.title}</h3>
        {post.excerpt ? <p className="mt-3 flex-1 text-[0.95rem] leading-relaxed text-ink-200 line-clamp-3">{post.excerpt}</p> : null}
        <span className="mt-5 inline-flex items-center gap-2 font-display text-base font-semibold uppercase tracking-[0.1em] text-gold-300">
          Read <Icon name="arrow-right" className="h-4 w-4 transition group-hover:translate-x-1" />
        </span>
      </div>
    </Link>
  );
}
