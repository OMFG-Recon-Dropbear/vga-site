import { donate } from "@/data/support";
import { site } from "@/data/site";
import { Button } from "@/components/ui/Button";
import { SourceNote } from "@/components/ui/SourceNote";
import { formatDate } from "@/lib/utils";

/** Campaign progress as last published. Figures are static until a donation provider is connected (see data/support.ts). */
export function DonateCampaign() {
  const c = donate.campaign;
  const pct = Math.max(1, Math.min(100, Math.round((c.raised / c.goal) * 100)));
  const fmt = (n: number) => `${c.currency}${n.toLocaleString("en-AU")}`;
  return (
    <div className="chamfer-frame">
      <div className="chamfer bg-ink-950 p-6 sm:p-8">
        <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">{c.title}</p>
        <h2 className="mt-2 font-display text-3xl font-bold uppercase leading-none text-ink-50">{c.subtitle}</h2>
        <div className="mt-6">
          <div className="flex items-end justify-between gap-4">
            <p>
              <span className="font-display text-4xl font-bold leading-none text-gold-200">{fmt(c.raised)}</span>
              <span className="ml-2 text-sm text-ink-300">raised</span>
            </p>
            <p className="text-right text-sm text-ink-300">
              Goal <span className="font-semibold text-ink-50">{fmt(c.goal)}</span>
            </p>
          </div>
          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-ink-800" role="progressbar" aria-valuemin={0} aria-valuemax={c.goal} aria-valuenow={c.raised} aria-label="Campaign progress">
            <div className="h-full rounded-full bg-gradient-to-r from-gold-700 via-gold-500 to-gold-200" style={{ width: `${pct}%` }} />
          </div>
          <p className="mt-2 text-sm text-ink-300">
            {c.donations} donation{c.donations === 1 ? "" : "s"} · {pct}% of goal
          </p>
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button href={site.donateUrl} size="lg" icon="heart" iconPosition="left" external>
            Donate now
          </Button>
          <Button href={site.socials.patreon} variant="secondary" icon="external" external>
            Give monthly on Patreon
          </Button>
        </div>
        <SourceNote>Campaign figures as displayed on {formatDate(c.asOf, { month: "long" })}. Donations are processed securely on VGA’s donation page.</SourceNote>
      </div>
    </div>
  );
}
