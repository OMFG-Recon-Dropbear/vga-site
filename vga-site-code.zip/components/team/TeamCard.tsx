import Image from "next/image";
import Link from "next/link";
import type { TeamMember } from "@/data/team";
import { images } from "@/data/generated/images";
import { Icon } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

export function TeamCard({ member, size = "md" }: { member: TeamMember; size?: "md" | "lg" }) {
  const img = member.image ? images[member.image] : null;
  const hasProfile = !!member.bio;
  const body = (
    <>
      <div className={cn("relative overflow-hidden bg-ink-800", size === "lg" ? "aspect-[4/5]" : "aspect-square")}>
        {img ? (
          <Image src={img.src} alt={`${member.name}, ${member.role}`} width={img.width} height={img.height} sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw" className="h-full w-full object-cover object-top transition duration-500 group-hover:scale-[1.03]" />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-ink-600" aria-hidden="true">
            <Icon name="users" className="h-12 w-12" />
          </div>
        )}
        <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-ink-850 to-transparent" aria-hidden="true" />
      </div>
      <div className="p-4 sm:p-5">
        <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">{member.role}</p>
        <h3 className={cn("mt-1 font-display font-bold uppercase leading-none text-ink-50", size === "lg" ? "text-3xl" : "text-2xl", member.comingSoon ? "text-ink-400" : "")}>{member.name}</h3>
        {member.summary ? <p className="mt-3 text-sm leading-relaxed text-ink-200">{member.summary}</p> : null}
        {hasProfile ? (
          <span className="mt-4 inline-flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-[0.12em] text-gold-300">
            Read profile <Icon name="arrow-right" className="h-4 w-4 transition group-hover:translate-x-1" />
          </span>
        ) : null}
      </div>
    </>
  );
  return hasProfile ? (
    <Link href={`/our-team/${member.slug}`} className="card card-hover group block overflow-hidden">
      {body}
    </Link>
  ) : (
    <article className="card block overflow-hidden">{body}</article>
  );
}
