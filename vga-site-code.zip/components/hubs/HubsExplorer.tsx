"use client";

import { useMemo, useState } from "react";
import { hubs, hubStates, type AuState, type HubType } from "@/data/hubs";
import { AustraliaMap } from "./AustraliaMap";
import { Icon } from "@/components/ui/Icon";
import { Tag } from "@/components/ui/Tag";
import { cn } from "@/lib/utils";

const stateNames: Record<AuState, string> = { QLD: "Queensland", NSW: "New South Wales", ACT: "ACT", VIC: "Victoria", TAS: "Tasmania", SA: "South Australia", WA: "Western Australia", NT: "Northern Territory" };

export function HubsExplorer() {
  const [state, setState] = useState<AuState | "ALL">("ALL");
  const [type, setType] = useState<HubType | "ALL">("ALL");
  const [active, setActive] = useState<string | null>(null);
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return hubs.filter((h) => (state === "ALL" || h.state === state) && (type === "ALL" || h.type === type) && (!q || `${h.title} ${h.address} ${h.suburb}`.toLowerCase().includes(q)));
  }, [state, type, query]);

  const activeHub = hubs.find((h) => h.slug === active);

  return (
    <div className="grid gap-8 lg:grid-cols-[1.3fr_1fr]">
      <div className="lg:sticky lg:top-[calc(var(--header-h)+1rem)] lg:self-start">
        <div className="chamfer-frame">
          <div className="chamfer bg-ink-900 p-2 sm:p-4">
            <AustraliaMap hubs={filtered} activeSlug={active} onSelect={(s) => { setActive(s); if (s) document.getElementById(`hub-${s}`)?.scrollIntoView({ behavior: "smooth", block: "nearest" }); }} />
          </div>
        </div>
        {activeHub ? (
          <div className="mt-4 rounded-lg border border-gold-700/60 bg-ink-850 p-5" role="status">
            <p className="eyebrow mb-2">Selected hub</p>
            <p className="font-display text-2xl font-bold uppercase leading-none text-ink-50">{activeHub.title}</p>
            <p className="mt-2 text-ink-200">{activeHub.address}</p>
            <p className="mt-1 text-sm text-ink-300">{activeHub.type} · {activeHub.equipment}</p>
            <a href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(activeHub.address + ", Australia")}`} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-[0.12em] text-gold-300 hover:text-gold-100">
              Directions <Icon name="external" className="h-4 w-4" />
            </a>
          </div>
        ) : null}
      </div>

      <div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <label className="relative flex-1">
            <span className="sr-only">Search hubs by name or suburb</span>
            <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-400" />
            <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by venue, suburb or address" className="input pl-10" />
          </label>
          <label className="sm:w-52">
            <span className="sr-only">Hub type</span>
            <select value={type} onChange={(e) => setType(e.target.value as HubType | "ALL")} className="input">
              <option value="ALL">All hub types</option>
              <option value="Social Gaming Hub">Social gaming hubs</option>
              <option value="Esports Hub">Esports hubs</option>
            </select>
          </label>
        </div>
        <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Filter by state or territory">
          {(["ALL", ...hubStates] as const).map((s) => {
            const count = s === "ALL" ? hubs.length : hubs.filter((h) => h.state === s).length;
            const on = state === s;
            return (
              <button key={s} type="button" onClick={() => setState(s)} aria-pressed={on} className={cn("rounded-sm border px-3 py-1.5 font-display text-sm font-semibold uppercase tracking-[0.12em] transition", on ? "border-gold-500 bg-gold-500 text-ink-950" : "border-ink-600 text-ink-100 hover:border-gold-500/70 hover:text-gold-200")}>
                {s === "ALL" ? "All" : s} <span className={cn("ml-1", on ? "text-ink-800" : "text-ink-400")}>{count}</span>
              </button>
            );
          })}
        </div>
        <p className="mt-4 text-sm text-ink-300" aria-live="polite">
          {filtered.length} {filtered.length === 1 ? "hub" : "hubs"}
          {state !== "ALL" ? ` in ${stateNames[state]}` : ""}
          {type !== "ALL" ? ` · ${type}s` : ""}
        </p>
        <ul className="mt-4 space-y-3 lg:max-h-[calc(100vh-var(--header-h)-14rem)] lg:overflow-y-auto lg:pr-2" aria-label="Hub list">
          {filtered.map((h) => {
            const on = active === h.slug;
            return (
              <li key={h.slug} id={`hub-${h.slug}`}>
                <button
                  type="button"
                  onClick={() => setActive(on ? null : h.slug)}
                  aria-pressed={on}
                  className={cn("card w-full p-5 text-left transition", on ? "border-gold-500 shadow-glow" : "hover:border-gold-700/70")}
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-display text-xl font-bold uppercase leading-tight text-ink-50">{h.title}</p>
                      <p className="mt-1 flex items-center gap-2 text-sm text-ink-300">
                        <Icon name="map-pin" className="h-4 w-4 text-gold-500" />
                        {h.address}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Tag tone={h.type === "Esports Hub" ? "gold" : "grey"}>{h.type}</Tag>
                      <Tag tone="grey">{h.state}</Tag>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-ink-200">
                    <span className="font-semibold text-ink-100">Set-up:</span> {h.equipment}
                  </p>
                </button>
              </li>
            );
          })}
          {!filtered.length ? <li className="rounded border border-ink-700 p-6 text-ink-300">No hubs match. Try another state or clear the search.</li> : null}
        </ul>
      </div>
    </div>
  );
}
