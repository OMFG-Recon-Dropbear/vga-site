"use client";

import { useId, useState } from "react";
import type { Hub } from "@/data/hubs";
import { cn } from "@/lib/utils";

/**
 * Stylised map of Australia (simplified coastline, equirectangular projection) with VGA hub pins.
 * Pure SVG — no map API, no external requests. Pins are buttons; the active hub is shown in a caption
 * and announced to assistive tech. Exact coordinates come from the previous site's map data.
 */

// Simplified coastline (longitude, latitude) — clockwise from Cape York.
const MAINLAND: [number, number][] = [
  [142.53, -10.69], [143.2, -11.9], [143.5, -12.9], [143.7, -14.2], [144.5, -14.3], [145.3, -14.9], [145.4, -16.0], [145.8, -16.9], [146.0, -17.6],
  [146.3, -18.5], [146.8, -19.3], [147.5, -19.7], [148.7, -20.2], [149.2, -21.1], [149.7, -22.4], [150.8, -22.6], [150.8, -23.4], [151.3, -24.0],
  [152.1, -24.6], [152.9, -25.3], [153.2, -25.9], [153.1, -26.7], [153.4, -27.4], [153.5, -28.2], [153.6, -28.6], [153.4, -29.4], [153.1, -30.3],
  [152.9, -31.0], [152.8, -31.9], [152.5, -32.5], [151.8, -32.9], [151.5, -33.4], [151.3, -33.9], [150.9, -34.5], [150.7, -35.0], [150.3, -35.8],
  [150.1, -36.5], [149.9, -37.3], [149.6, -37.8], [148.5, -37.8], [147.5, -38.0], [146.8, -38.5], [146.4, -39.1], [146.0, -38.7], [145.5, -38.5],
  [145.1, -38.2], [144.6, -38.3], [144.0, -38.5], [143.5, -38.8], [142.5, -38.4], [141.6, -38.4], [141.0, -38.1], [140.4, -37.9], [139.8, -37.1],
  [139.7, -36.3], [139.3, -35.7], [138.6, -35.4], [138.5, -35.0], [138.4, -34.4], [137.9, -33.2], [137.7, -32.6], [137.4, -33.4], [136.9, -34.1],
  [136.8, -34.8], [135.9, -34.8], [135.2, -34.5], [134.7, -33.6], [134.2, -33.0], [133.7, -32.2], [132.2, -32.0], [131.0, -31.5], [129.0, -31.7],
  [127.0, -32.3], [125.5, -33.2], [124.0, -33.6], [122.0, -33.9], [120.0, -33.9], [118.5, -34.7], [117.9, -35.1], [116.5, -35.0], [115.3, -34.4],
  [115.0, -33.7], [115.6, -33.3], [115.7, -32.6], [115.7, -32.0], [115.7, -31.4], [115.2, -30.4], [114.9, -29.5], [114.6, -28.8], [114.2, -28.0],
  [113.7, -26.9], [113.5, -26.0], [113.6, -25.0], [113.4, -24.5], [113.8, -23.3], [113.9, -22.2], [114.2, -21.9], [115.2, -21.5], [116.5, -20.8],
  [117.8, -20.5], [118.6, -20.3], [119.6, -20.0], [120.8, -19.7], [121.5, -18.9], [122.2, -18.0], [122.3, -17.2], [123.4, -17.2], [123.6, -16.4],
  [124.4, -15.9], [125.2, -15.0], [126.0, -14.2], [127.0, -14.0], [127.9, -14.4], [128.3, -14.9], [129.2, -14.9], [129.6, -14.5], [130.0, -13.4],
  [130.3, -12.4], [131.0, -12.2], [131.9, -11.4], [132.8, -11.4], [133.9, -11.9], [135.0, -12.1], [136.2, -12.0], [136.8, -12.5], [136.5, -13.5],
  [136.0, -14.3], [135.4, -15.0], [136.0, -15.8], [136.9, -16.1], [137.8, -16.5], [138.6, -17.0], [139.2, -17.6], [140.0, -17.7], [140.8, -17.4],
  [141.4, -16.4], [141.6, -15.2], [141.6, -13.9], [141.8, -12.7], [141.9, -11.9], [142.2, -10.9],
];
const TASMANIA: [number, number][] = [
  [144.7, -40.7], [145.3, -40.8], [146.4, -41.2], [147.4, -41.0], [148.3, -40.9], [148.3, -41.8], [148.0, -42.5], [147.9, -43.1], [147.3, -43.3],
  [146.6, -43.6], [146.0, -43.6], [145.3, -42.7], [145.2, -42.0], [144.7, -41.2],
];

const LON0 = 112, LON1 = 155, LAT0 = -9.5, LAT1 = -44.5;
const W = 860;
const PX_PER_LON = W / (LON1 - LON0);
const K = Math.cos((-27 * Math.PI) / 180); // horizontal compression at Australia's mid-latitude
const PX_PER_LAT = PX_PER_LON / K;
const H = Math.round((LAT0 - LAT1) * PX_PER_LAT); // 786
export function project(lon: number, lat: number): [number, number] {
  return [(lon - LON0) * PX_PER_LON, (LAT0 - lat) * PX_PER_LAT];
}
const toPath = (pts: [number, number][]) => pts.map(([lon, lat], i) => `${i ? "L" : "M"}${project(lon, lat).map((n) => n.toFixed(1)).join(",")}`).join(" ") + " Z";

export function AustraliaMap({ hubs, activeSlug, onSelect, className, interactive = true, compact = false }: { hubs: Hub[]; activeSlug?: string | null; onSelect?: (slug: string | null) => void; className?: string; interactive?: boolean; compact?: boolean }) {
  const [hover, setHover] = useState<string | null>(null);
  const id = useId();
  const current = hubs.find((h) => h.slug === (hover ?? activeSlug));
  return (
    <div className={cn("relative", className)}>
      <svg viewBox={`0 0 ${W} ${H}`} role="group" aria-labelledby={`${id}-title`} className="h-auto w-full">
        <title id={`${id}-title`}>{`Map of Australia showing ${hubs.length} VGA gaming hub locations`}</title>
        <defs>
          <pattern id={`${id}-grid`} width="28" height="28" patternUnits="userSpaceOnUse">
            <path d="M28 0H0V28" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
          </pattern>
          <radialGradient id={`${id}-glow`} cx="50%" cy="45%" r="60%">
            <stop offset="0%" stopColor="#C9B172" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#C9B172" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width={W} height={H} fill={`url(#${id}-glow)`} />
        <g>
          <path d={toPath(MAINLAND)} fill="#202326" stroke="#3E4347" strokeWidth="1.5" strokeLinejoin="round" />
          <path d={toPath(MAINLAND)} fill={`url(#${id}-grid)`} stroke="none" />
          <path d={toPath(TASMANIA)} fill="#202326" stroke="#3E4347" strokeWidth="1.5" strokeLinejoin="round" />
          <path d={toPath(TASMANIA)} fill={`url(#${id}-grid)`} stroke="none" />
        </g>
        {/* state labels (approximate centroids) */}
        {!compact &&
          (
            [
              ["WA", 122, -26], ["NT", 133.5, -19.5], ["SA", 135.5, -29.5], ["QLD", 144.5, -22.5], ["NSW", 146.5, -32.3], ["VIC", 143.8, -36.6], ["TAS", 146.6, -42.2], ["ACT", 149.0, -35.5],
            ] as [string, number, number][]
          ).map(([label, lon, lat]) => {
            const [x, y] = project(lon, lat);
            return (
              <text key={label} x={x} y={y} textAnchor="middle" className="fill-ink-500" style={{ fontFamily: "Inter, sans-serif", fontSize: label === "ACT" ? 9 : 13, letterSpacing: "0.12em", fontWeight: 600 }}>
                {label}
              </text>
            );
          })}
        {hubs.map((h) => {
          const [x, y] = project(h.longitude, h.latitude);
          const isActive = h.slug === (hover ?? activeSlug);
          const esports = h.type === "Esports Hub";
          return (
            <g key={h.slug} transform={`translate(${x.toFixed(1)} ${y.toFixed(1)})`}>
              {isActive ? <circle r="16" fill="#C9B172" opacity="0.18" /> : null}
              <circle r={isActive ? 7 : 5.5} fill={esports ? "#E9D58E" : "#C9B172"} stroke="#151719" strokeWidth="2" />
              {esports ? <circle r="2" fill="#151719" /> : null}
              {interactive ? (
                <circle
                  r="14"
                  fill="transparent"
                  role="button"
                  tabIndex={0}
                  aria-label={`${h.title}, ${h.suburb} ${h.state} — ${h.type}`}
                  aria-pressed={activeSlug === h.slug}
                  className="cursor-pointer outline-none focus-visible:stroke-gold-200 focus-visible:stroke-2"
                  onMouseEnter={() => setHover(h.slug)}
                  onMouseLeave={() => setHover(null)}
                  onFocus={() => setHover(h.slug)}
                  onBlur={() => setHover(null)}
                  onClick={() => onSelect?.(activeSlug === h.slug ? null : h.slug)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      onSelect?.(activeSlug === h.slug ? null : h.slug);
                    }
                  }}
                />
              ) : null}
            </g>
          );
        })}
      </svg>
      <div className="pointer-events-none absolute left-3 top-3 flex flex-col gap-1 text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-ink-300">
        <span className="flex items-center gap-2"><span className="inline-block h-2.5 w-2.5 rounded-full bg-gold-500" /> Social gaming hub</span>
        <span className="flex items-center gap-2"><span className="inline-block h-2.5 w-2.5 rounded-full bg-gold-200 ring-2 ring-inset ring-ink-900" /> Esports hub</span>
      </div>
      <p className="sr-only" aria-live="polite">
        {current ? `${current.title}, ${current.suburb} — ${current.type}` : ""}
      </p>
      {interactive && current ? (
        <div className="absolute bottom-3 left-3 right-3 rounded border border-gold-700/60 bg-ink-900/95 p-3 text-sm shadow-lift sm:left-auto sm:max-w-xs" aria-hidden="true">
          <p className="font-display text-lg font-bold uppercase leading-tight text-ink-50">{current.title}</p>
          <p className="text-ink-300">
            {current.suburb} · {current.type}
          </p>
        </div>
      ) : null}
    </div>
  );
}
