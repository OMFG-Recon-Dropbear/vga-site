import type { Metadata } from "next";
import { pages } from "@/data/generated/pages";
import { privacyPolicy } from "@/data/support";
import { buildMetadata } from "@/lib/seo";
import { Markdown } from "@/lib/markdown";
import { PageHero } from "@/components/ui/PageHero";

export const metadata: Metadata = buildMetadata({
  title: privacyPolicy.title,
  description: `${privacyPolicy.entity} respects your right to privacy and is committed to safeguarding the privacy of our customers and website visitors. This policy sets out how we collect and treat your personal information.`,
  path: "/privacy-policy",
});

export default function PrivacyPolicyPage() {
  return (
    <>
      <PageHero eyebrow="Legal" title={privacyPolicy.title} crumbs={[{ name: "Privacy Policy", path: "/privacy-policy" }]} compact />
      <section className="container py-12 lg:py-16" aria-label="Privacy policy">
        <Markdown content={pages["privacy-policy"]} className="prose-vga max-w-3xl" />
      </section>
    </>
  );
}
