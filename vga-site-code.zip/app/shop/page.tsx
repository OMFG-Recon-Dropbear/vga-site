import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { products } from "@/data/shop";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { SourceNote } from "@/components/ui/SourceNote";
import { Reveal } from "@/components/ui/Reveal";

export const metadata: Metadata = buildMetadata({
  title: "Shop — VGA merch",
  description: "Support Veteran Gaming Australia by purchasing one of our products — Pro Series hoodies and polos, long sleeves, patches, lapel pins and the VGA 5 Year Celebration Challenge Coin.",
  path: "/shop",
  image: images["shop/pro-series-hoodie"].src,
});

export default function ShopPage() {
  return (
    <>
      <PageHero
        eyebrow="Shop"
        title={
          <>
            Wear the <span className="gold-text">shield.</span>
          </>
        }
        lead="Support Veteran Gaming Australia by purchasing one of our products. Every item supports free programs for Veterans and families."
        image="shop/shop-banner"
        imagePosition="center"
        crumbs={[{ name: "Shop", path: "/shop" }]}
      >
        <Button href="#products" icon="arrow-right">
          Browse products
        </Button>
      </PageHero>

      <Section id="products" labelledBy="products-title">
        <SectionHeader id="products-title" eyebrow={`${products.length} products`} title="VGA merch" lead="Prices in Australian dollars. Sizes and options are chosen at checkout." />
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {products.map((p, i) => {
            const img = images[p.images[0]];
            return (
              <Reveal as="li" key={p.slug} delay={i * 40}>
                <Link href={`/shop/${p.slug}`} className="card card-hover group flex h-full flex-col overflow-hidden">
                  <div className="aspect-square overflow-hidden bg-[#f4f4f2]">
                    <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1280px) 25vw, (min-width: 640px) 50vw, 100vw" className="h-full w-full object-contain p-4 transition duration-500 group-hover:scale-[1.04]" />
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <h3 className="font-display text-xl font-bold uppercase leading-tight text-ink-50 transition group-hover:text-gold-200">{p.name}</h3>
                    <p className="mt-2 font-display text-2xl font-bold text-gold-200">{p.price}</p>
                    {p.options ? <p className="mt-1 text-xs uppercase tracking-[0.12em] text-ink-400">{p.options}</p> : null}
                    <span className="mt-4 inline-flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-[0.12em] text-gold-300">
                      View <Icon name="arrow-right" className="h-4 w-4 transition group-hover:translate-x-1" />
                    </span>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </ul>
        <SourceNote>Products, prices and descriptions as published in VGA’s shop (September 2026). Purchases are completed on VGA’s existing secure store checkout.</SourceNote>
      </Section>

      <CtaBand
        eyebrow="Members save"
        title="Earn points on every purchase."
        body="VGA’s loyalty program gives members 1 point for every A$1 spent — 20 points = A$1 discount."
        ctas={[
          { label: "Become a member", href: "/become-a-member", icon: "arrow-right" },
          { label: "Open the store", href: site.shopUrl, variant: "secondary", icon: "external" },
        ]}
      />
    </>
  );
}
