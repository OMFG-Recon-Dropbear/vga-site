import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { products } from "@/data/shop";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { SourceNote } from "@/components/ui/SourceNote";
import { PhotoGrid } from "@/components/gallery/Lightbox";
import { CtaBand } from "@/components/ui/CtaBand";
import Image from "next/image";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return products.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const p = products.find((x) => x.slug === slug);
  if (!p) return {};
  return buildMetadata({ title: `${p.name} — ${p.price}`, description: p.description ?? `${p.name} from the Veteran Gaming Australia shop.`, path: `/shop/${p.slug}`, image: images[p.images[0]].src });
}

export default async function ProductPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const p = products.find((x) => x.slug === slug);
  if (!p) notFound();
  const pics = p.images.map((k) => images[k]);
  const others = products.filter((x) => x.slug !== p.slug).slice(0, 4);
  return (
    <>
      <div className="container pt-10 sm:pt-12">
        <Breadcrumbs items={[{ name: "Shop", path: "/shop" }, { name: p.name, path: `/shop/${p.slug}` }]} />
      </div>
      <section className="container grid gap-10 py-10 lg:grid-cols-[1.1fr_1fr] lg:py-14">
        <div>
          {pics.length > 1 ? (
            <PhotoGrid images={pics} columns={2} />
          ) : (
            <div className="overflow-hidden rounded-lg border border-ink-700 bg-[#f4f4f2]">
              <Image src={pics[0].src} alt={pics[0].alt} width={pics[0].width} height={pics[0].height} priority sizes="(min-width: 1024px) 55vw, 100vw" className="aspect-square h-full w-full object-contain p-6" />
            </div>
          )}
        </div>
        <div>
          <h1 className="text-display-md uppercase text-ink-50">{p.name}</h1>
          <p className="mt-3 font-display text-4xl font-bold text-gold-200">{p.price}</p>
          {p.sku ? <p className="mt-1 text-xs uppercase tracking-[0.14em] text-ink-500">SKU {p.sku}</p> : null}
          {p.options ? <p className="mt-3 text-ink-200">{p.options}</p> : null}
          {p.description ? <p className="mt-5 text-lg text-ink-200">{p.description}</p> : null}
          {p.details?.length ? (
            <ul className="mt-5 space-y-2">
              {p.details.map((d) => (
                <li key={d} className="flex gap-3 text-ink-100">
                  <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-gold-500" />
                  <span>{d}</span>
                </li>
              ))}
            </ul>
          ) : null}
          <div className="mt-8 flex flex-wrap gap-3">
            <Button href={p.buyUrl} size="lg" icon="external" external>
              Buy now
            </Button>
            <Button href="/shop" variant="secondary" icon="arrow-right">
              Back to shop
            </Button>
          </div>
          <SourceNote>Sizes and options are chosen at checkout. Purchases are completed on VGA’s existing secure store; this page opens the product there.</SourceNote>
        </div>
      </section>
      {others.length ? (
        <section className="container pb-16" aria-labelledby="more-products">
          <h2 id="more-products" className="text-display-sm uppercase text-ink-50">
            More from the shop
          </h2>
          <ul className="mt-6 grid gap-4 grid-cols-2 lg:grid-cols-4">
            {others.map((o) => {
              const img = images[o.images[0]];
              return (
                <li key={o.slug}>
                  <Link href={`/shop/${o.slug}`} className="card card-hover group block overflow-hidden">
                    <div className="aspect-square overflow-hidden bg-[#f4f4f2]">
                      <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 25vw, 50vw" className="h-full w-full object-contain p-3 transition duration-500 group-hover:scale-[1.04]" />
                    </div>
                    <div className="p-4">
                      <p className="font-display text-lg font-bold uppercase leading-tight text-ink-50 group-hover:text-gold-200">{o.name}</p>
                      <p className="mt-1 font-display text-lg font-bold text-gold-200">{o.price}</p>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
      ) : null}
      <CtaBand eyebrow="Members save" title="Earn points on every purchase." body="VGA’s loyalty program gives members 1 point for every A$1 spent — 20 points = A$1 discount." ctas={[{ label: "Become a member", href: "/become-a-member", icon: "arrow-right" }]} />
    </>
  );
}
