import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { guides, educationIntro } from "@/data/education";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { Reveal } from "@/components/ui/Reveal";

export const metadata: Metadata = buildMetadata({
  title: "Education — healthy gaming and online safety guides",
  description: "Check the latest tips and information for safe gaming and social networks — Veteran Gaming Australia’s guides to healthy digital gaming, 3D printing basics, and Facebook, Instagram and TikTok safety for parents and kids.",
  path: "/education",
  image: images["education/healthy-gaming-ergonomics"].src,
});

export default function EducationPage() {
  return (
    <>
      <PageHero
        eyebrow="Education"
        title={
          <>
            Play well. <span className="gold-text">Stay safe.</span>
          </>
        }
        lead={educationIntro[0]}
        image="education/3d-printing"
        imagePosition="center"
        crumbs={[{ name: "Education", path: "/education" }]}
      >
        <Button href="#guides" icon="arrow-right">
          Browse the guides
        </Button>
      </PageHero>

      <Section id="guides" labelledBy="guides-title">
        <SectionHeader id="guides-title" eyebrow="Guides" title={`${guides.length} guides, free to read and download`} lead={educationIntro[1]} />
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {guides.map((g, i) => {
            const img = images[g.image];
            return (
              <Reveal as="li" key={g.slug} delay={i * 50}>
                <Link href={`/education/${g.slug}`} className="card card-hover group flex h-full flex-col overflow-hidden">
                  <div className="aspect-[16/10] overflow-hidden bg-ink-800">
                    <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw" className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
                  </div>
                  <div className="flex flex-1 flex-col p-6">
                    <h3 className="font-display text-2xl font-bold uppercase leading-none text-ink-50 transition group-hover:text-gold-200">{g.title}</h3>
                    <p className="mt-2 flex-1 text-ink-200">{g.subtitle}</p>
                    {g.author ? <p className="mt-3 text-xs text-ink-400">{g.author}</p> : null}
                    <span className="mt-5 inline-flex items-center gap-2 font-display text-base font-semibold uppercase tracking-[0.1em] text-gold-300">
                      Start now <Icon name="arrow-right" className="h-4 w-4 transition group-hover:translate-x-1" />
                    </span>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </ul>
      </Section>

      <CtaBand
        eyebrow="Questions?"
        title="Talk to the community."
        body="VGA’s Discord has channels for support, tech help and healthy gaming — and real people who have been there."
        ctas={[
          { label: "Join Discord", href: "https://discord.gg/veterangamingaustralia", variant: "discord", icon: "discord" },
          { label: "Contact VGA", href: "/contact", variant: "secondary", icon: "mail" },
        ]}
      />
    </>
  );
}
