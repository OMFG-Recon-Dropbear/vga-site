import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { guides } from "@/data/education";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { Markdown } from "@/lib/markdown";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { CtaBand } from "@/components/ui/CtaBand";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return guides.map((g) => ({ slug: g.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const g = guides.find((x) => x.slug === slug);
  if (!g) return {};
  return buildMetadata({ title: `${g.subtitle} — Education`, description: `${g.subtitle}. A Veteran Gaming Australia education guide — read online or download the PDF.`, path: `/education/${g.slug}`, image: images[g.image].src, type: "article" });
}

export default async function GuidePage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const g = guides.find((x) => x.slug === slug);
  if (!g) notFound();
  const img = images[g.image];
  const inline = g.inlineImage ? images[g.inlineImage] : null;
  const others = guides.filter((x) => x.slug !== g.slug);
  return (
    <>
      <article>
        <header className="relative isolate overflow-hidden border-b border-ink-700/60 bg-ink-950">
          <Image src={img.src} alt="" width={img.width} height={img.height} priority sizes="100vw" className="absolute inset-0 -z-20 h-full w-full object-cover opacity-35" />
          <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-950 via-ink-950/85 to-ink-950/40" />
          <div className="container py-16 sm:py-20">
            <Breadcrumbs items={[{ name: "Education", path: "/education" }, { name: g.title, path: `/education/${g.slug}` }]} className="mb-6" />
            <p className="eyebrow mb-4">Education · {g.title}</p>
            <h1 className="max-w-3xl text-display-lg uppercase text-ink-50">{g.subtitle}</h1>
            {g.author ? <p className="mt-4 text-ink-300">{g.author}</p> : null}
            <div className="mt-8 flex flex-wrap gap-3">
              <Button href={g.pdf} icon="download" external>
                Download the PDF
              </Button>
              <Button href="/education" variant="secondary" icon="arrow-right">
                All guides
              </Button>
            </div>
          </div>
        </header>
        <div className="container grid gap-12 py-12 lg:grid-cols-[minmax(0,1fr)_18rem] lg:py-16">
          <div className="min-w-0">
            {inline ? (
              <figure className="mb-8 max-w-3xl overflow-hidden rounded-md border border-ink-700">
                <Image src={inline.src} alt={inline.alt} width={inline.width} height={inline.height} sizes="(min-width: 1024px) 760px, 100vw" className="w-full" />
              </figure>
            ) : null}
            <Markdown content={g.body} className="prose-vga max-w-3xl" />
            <p className="mt-10 flex items-start gap-3 rounded border border-ink-700 bg-ink-850 p-4 text-sm text-ink-300">
              <Icon name="download" className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" />
              <span>
                Prefer a printable copy?{" "}
                <a href={g.pdf} target="_blank" rel="noopener noreferrer" className="text-gold-200 underline underline-offset-4 hover:text-gold-100">
                  Download {g.subtitle} (PDF)
                </a>
              </span>
            </p>
          </div>
          <aside className="lg:sticky lg:top-[calc(var(--header-h)+1.5rem)] lg:self-start">
            <div className="card p-5">
              <h2 className="font-display text-lg font-bold uppercase text-ink-50">More guides</h2>
              <ul className="mt-3 divide-y divide-ink-700/70">
                {others.map((o) => (
                  <li key={o.slug}>
                    <Link href={`/education/${o.slug}`} className="group flex items-center justify-between gap-3 py-2.5 text-ink-100 hover:text-gold-200">
                      <span>
                        <span className="block font-display text-base font-semibold uppercase leading-tight">{o.title}</span>
                        <span className="block text-xs text-ink-400">{o.subtitle}</span>
                      </span>
                      <Icon name="chevron-right" className="h-4 w-4 shrink-0 text-ink-500 group-hover:text-gold-200" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </article>
      <CtaBand eyebrow="Healthy gaming, together" title="Play with people who get it." body="Join the VGA community — free for Veterans and families." ctas={[{ label: "Become a member", href: "/become-a-member", icon: "arrow-right" }, { label: "Join Discord", href: "https://discord.gg/veterangamingaustralia", variant: "discord", icon: "discord" }]} />
    </>
  );
}
