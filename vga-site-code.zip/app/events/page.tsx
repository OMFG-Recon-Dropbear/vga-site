import type { Metadata } from "next";
import { pastEvents, upcomingEvents, eventRegionsWithData, eventsNotice } from "@/data/events";
import { digitalSocials, programs } from "@/data/programs";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata, eventJsonLd } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { JsonLd } from "@/components/ui/JsonLd";
import { SourceNote } from "@/components/ui/SourceNote";
import { EventCard } from "@/components/events/EventCard";
import { EventsExplorer } from "@/components/events/EventsExplorer";

export const metadata: Metadata = buildMetadata({
  title: "Events",
  description: "Veteran Gaming Australia events — weekly digital social game nights on Discord, in-person social connection events across Australia, and esports competitions. See what’s on and how events are announced.",
  path: "/events",
  image: images["news/vga-social-event-stadium"].src,
});

export default function EventsPage() {
  const eventsProgram = programs.find((p) => p.slug === "events")!;
  const regions = eventRegionsWithData();
  return (
    <>
      {upcomingEvents.map((e) => (
        <JsonLd key={e.slug} data={eventJsonLd({ name: e.title, startDate: e.date, endDate: e.endDate, location: e.location, description: e.summary, path: `/events#${e.slug}`, image: e.image ? images[e.image].src : undefined, online: e.kind === "Online" })} />
      ))}
      <PageHero
        eyebrow="Events"
        title={
          <>
            Something on <span className="gold-text">every week.</span>
          </>
        }
        lead={eventsProgram.short}
        image="news/vga-social-event-stadium"
        imagePosition="center 35%"
        crumbs={[{ name: "Events", path: "/events" }]}
      >
        <Button href={eventsNotice.facebook} icon="facebook" iconPosition="left" external>
          Events on Facebook
        </Button>
        <Button href={site.socials.discord} variant="discord" icon="discord" iconPosition="left">
          Events on Discord
        </Button>
      </PageHero>

      <Section labelledBy="upcoming">
        <SectionHeader
          id="upcoming"
          eyebrow="Upcoming"
          title={upcomingEvents.length ? "Upcoming events" : "Upcoming in-person events"}
          lead={upcomingEvents.length ? "In person and online — all free for members." : undefined}
        />
        {upcomingEvents.length ? (
          <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {upcomingEvents.map((e) => (
              <li key={e.slug} id={e.slug}>
                <EventCard event={e} />
              </li>
            ))}
          </ul>
        ) : (
          <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
            <div className="chamfer-frame">
              <div className="chamfer bg-ink-900 p-6 sm:p-8">
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">{eventsNotice.heading}</p>
                <p className="mt-3 text-lg text-ink-100">{eventsNotice.body}</p>
                <p className="mt-3 text-ink-300">{eventsProgram.howToParticipate}</p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <Button href={eventsNotice.facebook} icon="facebook" iconPosition="left" external>
                    Follow on Facebook
                  </Button>
                  <Button href={eventsNotice.discord} variant="discord" icon="discord" iconPosition="left">
                    Join Discord
                  </Button>
                </div>
              </div>
            </div>
            <div className="card p-6">
              <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-ink-300">The last 12 months</p>
              <p className="mt-3 font-display text-5xl font-bold leading-none text-gold-200">40+</p>
              <p className="mt-2 text-ink-100">family-inclusive, in-person social connection events delivered — the fastest reaching full capacity in 15 minutes.</p>
              <SourceNote>VGA statement, 29 July 2026.</SourceNote>
            </div>
          </div>
        )}
      </Section>

      <Section tone="raised" labelledBy="online">
        <SectionHeader id="online" eyebrow="Online · every week" title="Weekly digital socials" lead="Regular game nights on the VGA Discord. Times are AEST." action={<Button href="/programs/game-servers" variant="secondary" icon="arrow-right">24/7 servers</Button>} />
        <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {digitalSocials.map((d) => (
            <li key={d.day} className="card p-5">
              <p className="font-display text-lg font-bold uppercase tracking-[0.1em] text-gold-500">{d.day}</p>
              <ul className="mt-3 space-y-2">
                {d.sessions.map((s) => (
                  <li key={s.game} className="flex items-start justify-between gap-4">
                    <span className="font-display text-xl font-semibold uppercase leading-tight text-ink-50">{s.game}</span>
                    <span className="shrink-0 text-right text-sm text-ink-300">
                      {s.time}
                      <br />
                      {s.cadence}
                    </span>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ol>
        <SourceNote>Schedule from the VGA May–August 2026 newsletter. Check Discord for the current week — sessions rotate.</SourceNote>
      </Section>

      <Section labelledBy="past">
        <SectionHeader id="past" eyebrow="Past events" title="Where we’ve been" lead="Events documented on the VGA website and newsletters, 2022 to 2026. Filter by region or type." />
        <EventsExplorer events={pastEvents} regions={regions} />
      </Section>

      <Section tone="deep" labelledBy="host">
        <div className="grid gap-8 md:grid-cols-3">
          {[
            { icon: "users" as const, title: "Who comes", body: eventsProgram.whoFor },
            { icon: "calendar" as const, title: "What happens", body: "Fun Game Days, Movie Outings, STEM educational sessions, Social BBQs — and esports competitions streamed on Twitch." },
            { icon: "heart" as const, title: "What it costs", body: "Nothing. Veteran Gaming Australia offers free support services, programs, and activities to registered participants." },
          ].map((x) => (
            <div key={x.title} className="flex gap-4">
              <span className="chamfer-sm flex h-12 w-12 shrink-0 items-center justify-center bg-gold-500/10 text-gold-300">
                <Icon name={x.icon} className="h-6 w-6" />
              </span>
              <div>
                <h3 className="font-display text-2xl font-bold uppercase text-ink-50">{x.title}</h3>
                <p className="mt-2 text-ink-200">{x.body}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <CtaBand
        eyebrow="Don’t miss the next one"
        title="Members hear first."
        body="Membership is free for current and ex-serving ADF and NZDF members and their immediate family (18+)."
        ctas={[
          { label: "Become a member", href: "/become-a-member", icon: "arrow-right" },
          { label: "Subscribe to the newsletter", href: "/contact#newsletter", variant: "secondary" },
        ]}
      />
    </>
  );
}
