import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { albums } from "@/lib/content";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { formatDate } from "@/lib/utils";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { Tag } from "@/components/ui/Tag";
import { Reveal } from "@/components/ui/Reveal";

export const metadata: Metadata = buildMetadata({
  title: "Photo Gallery",
  description: "Veteran Gaming Australia photo galleries from events past — care packages, Veteran Health Week, Oz Comic-Con Brisbane, Queensland Mental Health Week, Christmas celebrations, sim racing and community moments across Australia.",
  path: "/gallery",
  image: images["gallery/vhw-2024/cover"].src,
});

export default function GalleryPage() {
  const list = albums();
  const total = list.reduce((n, a) => n + a.images.length, 0);
  return (
    <>
      <PageHero
        eyebrow="Photo gallery"
        title={
          <>
            Real people. <span className="gold-text">Real moments.</span>
          </>
        }
        lead={`${total} photos across ${list.length} albums — from VGA events, hubs and programs around Australia.`}
        image="gallery/vhw-2024/cover"
        imagePosition="center 30%"
        crumbs={[{ name: "Gallery", path: "/gallery" }]}
      >
        <Button href="#albums" icon="arrow-right">
          Browse albums
        </Button>
        <Button href={site.socials.instagram} variant="secondary" icon="instagram" iconPosition="left" external>
          VGA on Instagram
        </Button>
      </PageHero>

      <Section id="albums" labelledBy="albums-title">
        <SectionHeader id="albums-title" eyebrow="Albums" title="Browse by event" />
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((a, i) => {
            const cover = images[a.cover];
            return (
              <Reveal as="li" key={a.slug} delay={i * 40}>
                <Link href={`/gallery/${a.slug}`} className="card card-hover group flex h-full flex-col overflow-hidden">
                  <div className="relative aspect-[4/3] overflow-hidden bg-ink-800">
                    <Image src={cover.src} alt={cover.alt} width={cover.width} height={cover.height} sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw" className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
                    <span className="absolute bottom-3 right-3 inline-flex items-center gap-1.5 rounded-sm bg-ink-950/80 px-2 py-1 text-xs font-semibold text-ink-50">
                      <Icon name="play" className="h-3 w-3 text-gold-300" /> {a.images.length} photos
                    </span>
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <div className="flex flex-wrap gap-2">
                      {a.program ? <Tag tone="grey">{a.program}</Tag> : null}
                    </div>
                    <h3 className="mt-3 font-display text-2xl font-bold uppercase leading-none text-ink-50 transition group-hover:text-gold-200">{a.title}</h3>
                    <p className="mt-2 text-sm text-ink-300">
                      <time dateTime={a.date}>{formatDate(a.date, { month: "long", day: false })}</time>
                      {a.location ? ` · ${a.location}` : ""}
                    </p>
                    {a.description ? <p className="mt-3 flex-1 text-sm text-ink-200 line-clamp-2">{a.description}</p> : null}
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </ul>
      </Section>

      <CtaBand
        eyebrow="Be in the next one"
        title="Come to an event."
        body="In-person events are announced on Facebook and Discord and often book out within minutes — members hear first."
        ctas={[
          { label: "Events", href: "/events", icon: "arrow-right" },
          { label: "Become a member", href: "/become-a-member", variant: "secondary" },
        ]}
      />
    </>
  );
}
