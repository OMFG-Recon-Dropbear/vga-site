import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { albums, getAlbum, getPost } from "@/lib/content";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { formatDate, absoluteUrl } from "@/lib/utils";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Button } from "@/components/ui/Button";
import { Tag } from "@/components/ui/Tag";
import { Icon } from "@/components/ui/Icon";
import { PhotoGrid } from "@/components/gallery/Lightbox";
import { ShareButtons } from "@/components/community/ShareButtons";
import { CtaBand } from "@/components/ui/CtaBand";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return albums().map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const a = getAlbum(slug);
  if (!a) return {};
  return buildMetadata({ title: `${a.title} — Photo Gallery`, description: a.description ?? `${a.images.length} photos from ${a.title}.`, path: `/gallery/${a.slug}`, image: images[a.cover].src });
}

export default async function AlbumPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const a = getAlbum(slug);
  if (!a) notFound();
  const post = a.postSlug ? getPost(a.postSlug) : undefined;
  const photos = a.images.map((k) => images[k]);
  const all = albums();
  const idx = all.findIndex((x) => x.slug === a.slug);
  const prev = all[idx + 1];
  const next = all[idx - 1];
  return (
    <>
      <section className="border-b border-ink-700/60 bg-ink-950">
        <div className="container py-10 sm:py-14">
          <Breadcrumbs items={[{ name: "Gallery", path: "/gallery" }, { name: a.title, path: `/gallery/${a.slug}` }]} className="mb-6" />
          <div className="flex flex-wrap items-center gap-2">
            <Tag>Gallery</Tag>
            {a.program ? <Tag tone="grey">{a.program}</Tag> : null}
          </div>
          <h1 className="mt-4 text-display-lg uppercase text-ink-50">{a.title}</h1>
          <p className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-ink-300">
            <span className="inline-flex items-center gap-2">
              <Icon name="calendar" className="h-4 w-4 text-gold-500" />
              <time dateTime={a.date}>{formatDate(a.date, { month: "long", day: false })}</time>
            </span>
            {a.location ? (
              <span className="inline-flex items-center gap-2">
                <Icon name="map-pin" className="h-4 w-4 text-gold-500" /> {a.location}
              </span>
            ) : null}
            <span className="inline-flex items-center gap-2">
              <Icon name="play" className="h-4 w-4 text-gold-500" /> {photos.length} photos
            </span>
          </p>
          {a.description ? <p className="mt-4 max-w-2xl text-lg text-ink-200">{a.description}</p> : null}
          <div className="mt-6 flex flex-wrap items-center gap-4">
            {post && post.category !== "Galleries" ? (
              <Button href={`/news/${post.slug}`} variant="secondary" icon="arrow-right">
                Read the story
              </Button>
            ) : null}
            <ShareButtons url={absoluteUrl(`/gallery/${a.slug}`)} title={a.title} />
          </div>
        </div>
      </section>

      <section className="container py-10 sm:py-14" aria-label={`${a.title} photos`}>
        <PhotoGrid images={photos} columns={3} />
      </section>

      <nav className="container flex flex-wrap items-center justify-between gap-4 border-t border-ink-700 py-8" aria-label="Other albums">
        {prev ? (
          <Link href={`/gallery/${prev.slug}`} className="group inline-flex items-center gap-2 text-ink-200 hover:text-gold-200">
            <Icon name="chevron-left" className="h-5 w-5" />
            <span>
              <span className="block text-xs uppercase tracking-[0.14em] text-ink-400">Older</span>
              <span className="font-display text-lg font-semibold uppercase">{prev.title}</span>
            </span>
          </Link>
        ) : (
          <span />
        )}
        <Link href="/gallery" className="font-display text-base font-semibold uppercase tracking-[0.1em] text-gold-200 hover:text-gold-100">
          All albums
        </Link>
        {next ? (
          <Link href={`/gallery/${next.slug}`} className="group inline-flex items-center gap-2 text-right text-ink-200 hover:text-gold-200">
            <span>
              <span className="block text-xs uppercase tracking-[0.14em] text-ink-400">Newer</span>
              <span className="font-display text-lg font-semibold uppercase">{next.title}</span>
            </span>
            <Icon name="chevron-right" className="h-5 w-5" />
          </Link>
        ) : (
          <span />
        )}
      </nav>
      <CtaBand eyebrow="Be in the next one" title="Come to an event." body="In-person events are announced on Facebook and Discord and often book out within minutes." ctas={[{ label: "Events", href: "/events", icon: "arrow-right" }, { label: "Join Discord", href: "https://discord.gg/veterangamingaustralia", variant: "discord", icon: "discord" }]} />
    </>
  );
}
