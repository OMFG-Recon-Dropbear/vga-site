import { NextResponse, type NextRequest } from "next/server";
import { deliver, type Delivery } from "@/lib/forms";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const FORMS = ["contact", "newsletter", "membership"] as const;
type FormName = (typeof FORMS)[number];

const MAX_FILE = 10 * 1024 * 1024;
const rate = new Map<string, number[]>();

function limited(ip: string): boolean {
  const now = Date.now();
  const hits = (rate.get(ip) ?? []).filter((t) => now - t < 10 * 60 * 1000);
  hits.push(now);
  rate.set(ip, hits);
  return hits.length > 12;
}

function str(v: FormDataEntryValue | unknown, max = 2000): string {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ form: string }> }) {
  const { form } = await ctx.params;
  if (!FORMS.includes(form as FormName)) return NextResponse.json({ ok: false, message: "Unknown form." }, { status: 404 });
  const ip = req.headers.get("cf-connecting-ip") ?? req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  if (limited(ip)) return NextResponse.json({ ok: false, message: "Too many submissions. Please try again later." }, { status: 429 });

  let fields: Record<string, string> = {};
  let file: { filename: string; content: Buffer; contentType: string } | undefined;
  const type = req.headers.get("content-type") ?? "";
  try {
    if (type.includes("multipart/form-data")) {
      const fd = await req.formData();
      for (const [k, v] of fd.entries()) {
        if (v instanceof File) {
          if (v.size > MAX_FILE) return NextResponse.json({ ok: false, message: "File is larger than 10 MB." }, { status: 413 });
          if (v.size > 0) file = { filename: v.name.replace(/[^\w.\-]+/g, "_").slice(0, 120), content: Buffer.from(await v.arrayBuffer()), contentType: v.type || "application/octet-stream" };
        } else fields[k] = str(v);
      }
    } else {
      const body = (await req.json()) as Record<string, unknown>;
      for (const [k, v] of Object.entries(body)) fields[k] = typeof v === "boolean" ? String(v) : str(v);
    }
  } catch {
    return NextResponse.json({ ok: false, message: "Could not read the submission." }, { status: 400 });
  }

  if (fields.website) return NextResponse.json({ ok: true, message: "Thanks." }); // honeypot: pretend success

  const email = fields.email ?? "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({ ok: false, message: "Please enter a valid email address." }, { status: 422 });

  let delivery: Delivery;
  if (form === "newsletter") {
    if (fields.consent !== "true" && fields.consent !== "on") return NextResponse.json({ ok: false, message: "Please tick the subscribe box." }, { status: 422 });
    delivery = { form, subject: `Newsletter subscription: ${email}`, replyTo: email, fields: { email } };
  } else if (form === "contact") {
    if (!fields.firstName || !fields.lastName || !fields.message) return NextResponse.json({ ok: false, message: "Please fill in your name and message." }, { status: 422 });
    delivery = { form, subject: `Website contact${fields.subject ? `: ${fields.subject}` : ""} — ${fields.firstName} ${fields.lastName}`, replyTo: email, fields };
  } else {
    const required = ["firstName", "lastName", "phone", "email", "address", "city", "state", "postcode", "country", "gender", "dateOfBirth", "service", "status", "verificationType"];
    const missing = required.filter((k) => !fields[k]);
    if (missing.length) return NextResponse.json({ ok: false, message: `Please complete: ${missing.join(", ")}.` }, { status: 422 });
    if (!file) return NextResponse.json({ ok: false, message: "Please upload a verification document or image." }, { status: 422 });
    delivery = { form, subject: `Member application — ${fields.firstName} ${fields.lastName} (${fields.status}, ${fields.service})`, replyTo: email, fields, file };
  }

  const result = await deliver(delivery);
  if (!result.ok) {
    return NextResponse.json({ ok: false, message: result.message }, { status: result.status ?? 500 });
  }
  const message =
    form === "newsletter"
      ? "You’re subscribed. Welcome aboard."
      : form === "membership"
        ? "One of our team will be in touch by phone or email with important information to connect with the VGA community."
        : "We’ll get back to you as soon as we can.";
  return NextResponse.json({ ok: true, message });
}
