import { NextResponse, type NextRequest } from "next/server";
import { AUTH_COOKIE, checkCredentials, gateEnabled, issueToken, safeNext } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// simple per-IP throttle: 10 attempts per 10 minutes
const attempts = new Map<string, { n: number; t: number }>();
function throttled(ip: string): boolean {
  const now = Date.now();
  const a = attempts.get(ip);
  if (!a || now - a.t > 10 * 60 * 1000) {
    attempts.set(ip, { n: 1, t: now });
    return false;
  }
  a.n += 1;
  return a.n > 10;
}

/**
 * Redirect with a *relative* Location header. Behind the Cloudflare Tunnel the container only knows its
 * bind address (0.0.0.0:3000), so building an absolute URL from `req.url` would send visitors to the wrong host.
 * Browsers resolve a relative Location against the page's own origin (RFC 9110 §10.2.2).
 */
function redirectTo(path: string): NextResponse {
  return new NextResponse(null, { status: 303, headers: { location: path, "cache-control": "no-store" } });
}

export async function POST(req: NextRequest) {
  if (!gateEnabled()) return redirectTo("/");
  const ip = req.headers.get("cf-connecting-ip") ?? req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  const form = await req.formData().catch(() => null);
  const user = String(form?.get("username") ?? "");
  const pass = String(form?.get("password") ?? "");
  const next = safeNext(form?.get("next"));
  const back = (code: string) => {
    const q = new URLSearchParams({ error: code });
    if (next !== "/") q.set("next", next);
    return redirectTo(`/login?${q.toString()}`);
  };
  if (throttled(ip)) return back("throttled");
  if (!checkCredentials(user, pass)) return back("invalid");
  const token = issueToken();
  const res = redirectTo(next);
  res.cookies.set(AUTH_COOKIE, token.value, {
    httpOnly: true,
    sameSite: "lax",
    secure: req.nextUrl.protocol === "https:" || req.headers.get("x-forwarded-proto") === "https",
    path: "/",
    maxAge: token.maxAge,
  });
  return res;
}
