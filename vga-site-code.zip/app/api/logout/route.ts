import { NextResponse } from "next/server";
import { AUTH_COOKIE } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Clears the preview cookie. Relative Location on purpose — see app/api/login/route.ts. */
export async function POST() {
  const res = new NextResponse(null, { status: 303, headers: { location: "/login", "cache-control": "no-store" } });
  res.cookies.set(AUTH_COOKIE, "", { httpOnly: true, sameSite: "lax", path: "/", maxAge: 0 });
  return res;
}
