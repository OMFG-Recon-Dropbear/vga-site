import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { sponsorYears } from "@/data/sponsors";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { CtaBand } from "@/components/ui/CtaBand";
import { Button } from "@/components/ui/Button";
import { SponsorYearSection } from "@/components/sponsors/SponsorYearSection";
import { cn } from "@/lib/utils";

type Params = { year: string };

export function generateStaticParams(): Params[] {
  return sponsorYears.map((y) => ({ year: String(y.year) }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { year } = await params;
  const y = sponsorYears.find((x) => String(x.year) === year);
  if (!y) return {};
  return buildMetadata({ title: y.title, description: y.intro, path: `/sponsors/${y.year}`, image: images["esports/team-vga-banner"].src });
}

export default async function SponsorYearPage({ params }: { params: Promise<Params> }) {
  const { year } = await params;
  const y = sponsorYears.find((x) => String(x.year) === year);
  if (!y) notFound();
  return (
    <>
      <PageHero eyebrow="Our valued sponsors" title={y.title} lead={y.intro} crumbs={[{ name: "Sponsors", path: "/sponsors" }, { name: String(y.year), path: `/sponsors/${y.year}` }]} compact>
        <Button href="/become-a-sponsor" icon="arrow-right">
          Become a sponsor
        </Button>
      </PageHero>
      <Section labelledBy="year-title">
        <h2 id="year-title" className="sr-only">
          {y.title} sponsors by tier
        </h2>
        <nav aria-label="Sponsor years" className="-mx-4 mb-8 overflow-x-auto px-4 sm:mx-0 sm:px-0">
          <ul className="flex min-w-max gap-2 border-b border-ink-700 pb-px">
            {sponsorYears.map((x) => (
              <li key={x.year}>
                <Link href={x === sponsorYears[0] ? "/sponsors" : `/sponsors/${x.year}`} aria-current={x.year === y.year ? "page" : undefined} className={cn("inline-block border-b-2 px-3 py-3 font-display text-base font-semibold uppercase tracking-[0.1em] transition", x.year === y.year ? "border-gold-500 text-gold-200" : "border-transparent text-ink-300 hover:text-ink-50")}>
                  {x.year}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        {y.grants ? <p className="max-w-3xl text-ink-300">{y.grants}</p> : null}
        <SponsorYearSection year={y} headingLevel={3} compact />
      </Section>
      <CtaBand eyebrow="Join the wall" title="Back the mission." body="Sponsorship packages from A$1,000 put your logo on the Legends wall, VGA socials and the Team VGA sim cars." ctas={[{ label: "Sponsorship packages", href: "/become-a-sponsor", icon: "arrow-right" }, { label: "All sponsors", href: "/sponsors", variant: "secondary" }]} />
    </>
  );
}
