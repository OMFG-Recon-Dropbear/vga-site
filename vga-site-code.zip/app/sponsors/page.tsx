import type { Metadata } from "next";
import Link from "next/link";
import { sponsorYears, currentSponsorYear } from "@/data/sponsors";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { SponsorYearSection } from "@/components/sponsors/SponsorYearSection";

export const metadata: Metadata = buildMetadata({
  title: "Our Sponsors — the Legends wall",
  description: currentSponsorYear.intro,
  path: "/sponsors",
  image: images["esports/team-vga-banner"].src,
});

export default function SponsorsPage() {
  const past = sponsorYears.slice(1);
  return (
    <>
      <PageHero
        eyebrow="Our valued sponsors"
        title={
          <>
            The <span className="gold-text">Legends</span> wall
          </>
        }
        lead="Grants, sponsors, equipment donors and partners who make free programs possible for Veterans and families — by year."
        image="esports/team-vga-banner"
        imagePosition="center"
        crumbs={[{ name: "Sponsors", path: "/sponsors" }]}
      >
        <Button href="/become-a-sponsor" icon="arrow-right">
          Become a sponsor
        </Button>
        <Button href="#past-years" variant="secondary">
          Previous years
        </Button>
      </PageHero>

      <Section labelledBy="current">
        <SectionHeader id="current" eyebrow="Current" title={currentSponsorYear.title} />
        <SponsorYearSection year={currentSponsorYear} headingLevel={3} />
      </Section>

      <Section tone="raised" id="past-years" labelledBy="past-title">
        <SectionHeader id="past-title" eyebrow="Previous years" title="Legends, year by year" lead="Every organisation that has backed VGA since 2022." />
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {past.map((y) => {
            const count = y.tiers.reduce((n, t) => n + t.sponsors.length, 0);
            return (
              <li key={y.year}>
                <Link href={`/sponsors/${y.year}`} className="card card-hover group flex h-full flex-col p-6">
                  <p className="font-display text-5xl font-bold leading-none text-gold-200">{y.year}</p>
                  <p className="mt-3 font-display text-xl font-semibold uppercase text-ink-50 transition group-hover:text-gold-200">{y.title}</p>
                  <p className="mt-2 flex-1 text-sm text-ink-300">
                    {count} sponsor{count === 1 ? "" : "s"} and partners across {y.tiers.length} tier{y.tiers.length === 1 ? "" : "s"}
                  </p>
                  <span className="mt-4 inline-flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-[0.12em] text-gold-300">
                    View sponsors <Icon name="arrow-right" className="h-4 w-4 transition group-hover:translate-x-1" />
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </Section>

      <CtaBand
        eyebrow="Join the wall"
        title="Back the mission in 2026."
        body="Sponsorship packages from A$1,000 put your logo on the Legends wall, VGA socials and the Team VGA sim cars — and fund free programs for Veterans and families."
        ctas={[
          { label: "Sponsorship packages", href: "/become-a-sponsor", icon: "arrow-right" },
          { label: "Talk to us", href: "/contact?subject=Sponsorship%20enquiry", variant: "secondary", icon: "mail" },
        ]}
      />
    </>
  );
}
