import type { Metadata } from "next";
import Image from "next/image";
import { hubs, hubStates, recentHubMentions } from "@/data/hubs";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { HubsExplorer } from "@/components/hubs/HubsExplorer";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { SourceNote } from "@/components/ui/SourceNote";
import { Icon } from "@/components/ui/Icon";
import { NewsCard } from "@/components/community/NewsCard";
import { allPosts } from "@/lib/content";

export const metadata: Metadata = buildMetadata({
  title: "Gaming Hubs — find a VGA hub near you",
  description: `${hubs.length} VGA social gaming and esports hubs across ${hubStates.length} states and territories — on Defence bases, in Veteran and Family wellbeing centres, RSLs and hospitals. Search by state, suburb or venue.`,
  path: "/gaming-hubs",
  image: images["programs/gaming-hub-pcs"].src,
});

/** Verbatim from the “Retrofit — Social & Esports Gaming Hubs” pages of VGA’s 5 Years in the Game impact report (2026). */
const retrofit = [
  "At its core, Retrofit is about meeting Veterans where they already are. Whether that is on-base, within a Veteran and Family Wellbeing Centre, at an RSL, or in a hospital setting, VGA works to install social gaming and esports hubs that provide an immediate and accessible way for Veterans to engage. These hubs are more than just equipment. They are connection points that bring people together in a natural and familiar way.",
  "Each hub is designed to be simple, welcoming, and easy to use. With gaming consoles, screens, and shared spaces, they create an environment where conversation happens naturally, where Veterans can decompress, and where support can be delivered without the formality of traditional settings. Gaming becomes the bridge, allowing meaningful engagement without pressure.",
  "Gaming hubs have proven to be effective informal wellbeing spaces. They allow Veterans to connect without pressure, offering a shared activity that builds trust, familiarity, and a sense of belonging over time.",
];

const hubPhotos = ["hubs/riverina-hub-setup-1", "hubs/hampton-rsl-esports-hub", "hubs/defence-base-social-gaming", "hubs/nowra-hub-meeting"] as const;

export default function GamingHubsPage() {
  const esports = hubs.filter((h) => h.type === "Esports Hub").length;
  const hubPosts = allPosts().filter((p) => /gaming-hub/.test(p.slug));
  return (
    <>
      <PageHero
        eyebrow="Retrofit — gaming hubs"
        title={
          <>
            Is there a VGA hub <span className="gold-text">near you?</span>
          </>
        }
        lead={`VGA is facilitating and setting up social gaming hubs and esports hubs, information & resources to Veteran Hospitals and Veteran Support Organisations in enhancing social connections, health and wellbeing. ${hubs.length} hubs are on the map today, including ${esports} esports hubs.`}
        image="programs/gaming-hub-pcs"
        imagePosition="center"
        crumbs={[
          { name: "Programs", path: "/programs" },
          { name: "Gaming Hubs", path: "/gaming-hubs" },
        ]}
      >
        <Button href="#map" icon="map-pin" iconPosition="left">
          Use the map
        </Button>
        <Button href="/contact" variant="secondary">
          Ask about hosting a hub
        </Button>
      </PageHero>

      <Section id="map" labelledBy="explorer">
        <SectionHeader id="explorer" eyebrow="Interactive map" title="Search hubs by state, suburb or venue" lead="Tap a pin or a venue for details and directions. Hub venues are hosted by partner organisations — check with the venue about access before you visit." />
        <HubsExplorer />
        <SourceNote>Locations, equipment and coordinates as published on VGA’s Gaming Hubs map ({hubs.length} pins, September 2026).</SourceNote>
        {recentHubMentions.length ? (
          <div className="mt-8 rounded-lg border border-ink-700 bg-ink-850 p-5">
            <p className="font-display text-lg font-bold uppercase text-ink-50">Recently announced</p>
            <ul className="mt-2 space-y-2 text-ink-200">
              {recentHubMentions.map((m) => (
                <li key={m.title} className="flex gap-3">
                  <Icon name="star" className="mt-1 h-4 w-4 shrink-0 text-gold-500" />
                  <span>
                    <strong className="text-ink-50">{m.title}</strong> — {m.note}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </Section>

      <Section tone="raised" labelledBy="how">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="eyebrow mb-4">How hubs work</p>
            <h2 id="how" className="text-display-md uppercase text-ink-50">
              Meeting Veterans where they already are
            </h2>
            <div className="mt-5 space-y-4 text-lg text-ink-200">
              {retrofit.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <SourceNote>From the “Retrofit — Social &amp; Esports Gaming Hubs” pages of VGA’s 5 Years in the Game impact report (2026). Hub equipment per venue is listed on the map above.</SourceNote>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button href="/contact" icon="arrow-right">
                Host a hub at your venue
              </Button>
              <Button href="/donate" variant="secondary">
                Fund a hub
              </Button>
            </div>
          </div>
          <ul className="grid grid-cols-2 gap-3">
            {hubPhotos.map((k, i) => {
              const a = images[k];
              return (
                <li key={k} className={i % 3 === 0 ? "row-span-1" : ""}>
                  <div className="overflow-hidden rounded-md border border-ink-700">
                    <Image src={a.src} alt={a.alt} width={a.width} height={a.height} sizes="(min-width: 1024px) 25vw, 50vw" className="aspect-[4/3] h-full w-full object-cover" />
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </Section>

      {hubPosts.length ? (
        <Section labelledBy="hub-news">
          <SectionHeader id="hub-news" eyebrow="Hub stories" title="New hubs, in their own words" />
          <ul className="grid gap-6 md:grid-cols-2">
            {hubPosts.map((p) => (
              <li key={p.slug}>
                <NewsCard post={p} />
              </li>
            ))}
          </ul>
        </Section>
      ) : null}

      <CtaBand
        eyebrow="Can’t get to a hub?"
        title="The online hub is open 24/7."
        body="VGA’s Discord is the always-on community — game nights every week, 24/7 servers, and mates to talk to."
        ctas={[
          { label: "Join Discord", href: site.socials.discord, variant: "discord", icon: "discord" },
          { label: "Game servers & socials", href: "/programs/game-servers", variant: "secondary", icon: "arrow-right" },
        ]}
      />
    </>
  );
}
