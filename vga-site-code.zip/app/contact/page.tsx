import type { Metadata } from "next";
import { site } from "@/data/site";
import { team } from "@/data/team";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { Button } from "@/components/ui/Button";
import { Icon, type IconName } from "@/components/ui/Icon";
import { ContactForm } from "@/components/forms/ContactForm";
import { NewsletterForm } from "@/components/forms/NewsletterForm";
import { TeamCard } from "@/components/team/TeamCard";

export const metadata: Metadata = buildMetadata({
  title: "Contact Us",
  description: "Veteran Gaming Australia’s mission is to enhance Veterans’ and Veteran Families’ social connections, health and wellbeing. Get in touch by email, the contact form or Discord.",
  path: "/contact",
  image: images["about/community-dinner"].src,
});

const safeSubject = (v: unknown) => (typeof v === "string" ? v.replace(/[\r\n]/g, " ").slice(0, 120) : undefined);

export default async function ContactPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const subject = safeSubject(sp.subject);
  const reps = team.filter((m) => m.group === "state-rep");
  const channels: { icon: IconName; label: string; value: string; href: string; external?: boolean }[] = [
    { icon: "mail", label: "Email", value: site.email, href: `mailto:${site.email}` },
    { icon: "discord", label: "Discord", value: "discord.gg/veterangamingaustralia", href: site.socials.discord, external: true },
    { icon: "facebook", label: "Facebook", value: "@VeteranGamingAustralia", href: site.socials.facebook, external: true },
    { icon: "instagram", label: "Instagram", value: "@veterangamingaustralia", href: site.socials.instagram, external: true },
  ];
  return (
    <>
      <PageHero eyebrow="Contact" title={<>Get in <span className="gold-text">touch.</span></>} lead="Questions about membership, hubs, sponsorship, events or media — send a message and one of the volunteer team will get back to you." crumbs={[{ name: "Contact", path: "/contact" }]} compact />

      <Section labelledBy="form-title">
        <div className="grid gap-12 lg:grid-cols-[1.2fr_1fr]">
          <div className="chamfer-frame self-start">
            <div className="chamfer bg-ink-950 p-6 sm:p-8">
              <h2 id="form-title" className="font-display text-3xl font-bold uppercase text-ink-50">
                Contact us
              </h2>
              <p className="mt-2 text-sm text-ink-300">Fields marked * are required.</p>
              <div className="mt-6">
                <ContactForm subject={subject} />
              </div>
            </div>
          </div>
          <div className="space-y-6">
            <ul className="space-y-3">
              {channels.map((c) => (
                <li key={c.label}>
                  <a href={c.href} target={c.external ? "_blank" : undefined} rel={c.external ? "noopener noreferrer" : undefined} className="card card-hover flex items-center gap-4 p-4">
                    <span className="chamfer-sm flex h-11 w-11 shrink-0 items-center justify-center bg-gold-500/10 text-gold-300">
                      <Icon name={c.icon} className="h-5 w-5" />
                    </span>
                    <span className="min-w-0">
                      <span className="block font-display text-sm font-semibold uppercase tracking-[0.14em] text-ink-300">{c.label}</span>
                      <span className="block break-all text-ink-50">{c.value}</span>
                    </span>
                  </a>
                </li>
              ))}
            </ul>
            <div className="card p-5">
              <p className="font-display text-lg font-bold uppercase text-ink-50">Need support now?</p>
              <p className="mt-2 text-sm text-ink-200">The VGA Discord has a #support channel staffed by volunteers. For urgent help, contact emergency services or a crisis line in your state.</p>
              <Button href={site.socials.discord} variant="discord" size="sm" icon="discord" iconPosition="left" className="mt-4">
                Open Discord
              </Button>
            </div>
            <div id="newsletter" className="card scroll-mt-24 p-5">
              <p className="font-display text-lg font-bold uppercase text-ink-50">Subscribe to the newsletter</p>
              <div className="mt-3">
                <NewsletterForm compact />
              </div>
            </div>
          </div>
        </div>
      </Section>

      {reps.length ? (
        <Section tone="raised" labelledBy="reps-title">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow mb-3">In your state</p>
              <h2 id="reps-title" className="text-display-sm uppercase text-ink-50">
                State &amp; regional representatives
              </h2>
            </div>
            <Button href="/our-team" variant="secondary" icon="arrow-right">
              The whole team
            </Button>
          </div>
          <ul className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {reps.map((m) => (
              <li key={m.slug}>
                <TeamCard member={m} />
              </li>
            ))}
          </ul>
        </Section>
      ) : null}
    </>
  );
}
