import type { Metadata } from "next";
import { site } from "@/data/site";
import { Hero } from "@/components/home/Hero";
import { ImpactStrip } from "@/components/home/ImpactStrip";
import { WhatWeDo } from "@/components/home/WhatWeDo";
import { HubsPreview } from "@/components/home/HubsPreview";
import { CommunitySection } from "@/components/home/CommunitySection";
import { EventsPreview } from "@/components/home/EventsPreview";
import { LatestNews } from "@/components/home/LatestNews";
import { SponsorsStrip } from "@/components/home/SponsorsStrip";
import { FinalCta } from "@/components/home/FinalCta";

export const metadata: Metadata = {
  title: `${site.name} — Improving Veteran wellbeing through gaming`,
  description: site.description,
  alternates: { canonical: site.url },
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <ImpactStrip />
      <WhatWeDo />
      <HubsPreview />
      <CommunitySection />
      <EventsPreview />
      <LatestNews />
      <SponsorsStrip />
      <FinalCta />
    </>
  );
}
