import type { Metadata } from "next";
import Image from "next/image";
import { donate } from "@/data/support";
import { headlineStats } from "@/data/stats";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { absoluteUrl } from "@/lib/utils";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { AnimatedNumber } from "@/components/ui/Stat";
import { Reveal } from "@/components/ui/Reveal";
import { SourceNote } from "@/components/ui/SourceNote";
import { DonateCampaign } from "@/components/support/DonateCampaign";
import { ShareButtons } from "@/components/community/ShareButtons";

export const metadata: Metadata = buildMetadata({
  title: "Donate — support Veterans by donating today",
  description: donate.intro,
  path: "/donate",
  image: images["community/vga-care-package"].src,
});

const photos = ["community/sa-family-day", "community/vga-care-package", "news/darwin-history-tour", "community/discord-server"] as const;

export default function DonatePage() {
  return (
    <>
      <PageHero
        eyebrow="Donate"
        title={
          <>
            Your donation creates <span className="gold-text">real impact.</span>
          </>
        }
        lead={donate.intro}
        image="community/vga-care-package"
        imagePosition="center 30%"
        crumbs={[{ name: "Support VGA", path: "/support" }, { name: "Donate", path: "/donate" }]}
      >
        <Button href={site.donateUrl} size="lg" icon="heart" iconPosition="left" external>
          Donate now
        </Button>
        <Button href="#funds" variant="secondary" icon="arrow-right">
          What your support funds
        </Button>
      </PageHero>

      <Section labelledBy="campaign-title">
        <div className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-start">
          <div>
            <h2 id="campaign-title" className="sr-only">
              Support our campaign
            </h2>
            <DonateCampaign />
            <div className="mt-6">
              <ShareButtons url={absoluteUrl("/donate")} title="Support Veteran Gaming Australia" />
            </div>
          </div>
          <div id="funds">
            <p className="eyebrow mb-4">{donate.fundsLead}</p>
            <ul className="grid gap-3 sm:grid-cols-2">
              {donate.funds.map((f, i) => (
                <Reveal as="li" key={f.text} delay={i * 40} className="card flex items-start gap-3 p-4">
                  <span className="text-2xl leading-none" aria-hidden="true">
                    {f.icon}
                  </span>
                  <span className="text-ink-100">{f.text}</span>
                </Reveal>
              ))}
            </ul>
            <p className="mt-6 text-sm text-ink-300">{site.volunteerRun} {site.charityStatement}.</p>
          </div>
        </div>
      </Section>

      <Section tone="raised" labelledBy="impact-title">
        <SectionHeader id="impact-title" eyebrow={donate.impactHeading} title="What five years of support has built" action={<Button href="/impact" variant="secondary" icon="arrow-right">Our impact</Button>} />
        <ul className="grid grid-cols-2 gap-4 md:grid-cols-3">
          {headlineStats.map((s, i) => (
            <Reveal as="li" key={s.label} delay={i * 50} className="card p-5">
              <p className="font-display text-4xl font-bold leading-none text-gold-200 sm:text-5xl">
                <AnimatedNumber value={s.value} prefix={s.prefix} suffix={s.suffix} />
              </p>
              <p className="mt-2 font-display text-lg font-semibold uppercase leading-tight text-ink-50">{s.label}</p>
            </Reveal>
          ))}
        </ul>
        <ul className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4">
          {photos.map((k) => {
            const a = images[k];
            return (
              <li key={k} className="overflow-hidden rounded-md border border-ink-700">
                <Image src={a.src} alt={a.alt} width={a.width} height={a.height} sizes="(min-width: 768px) 25vw, 50vw" className="aspect-[4/3] h-full w-full object-cover" />
              </li>
            );
          })}
        </ul>
        <SourceNote>Statistics and photos as published on VGA’s Donate page and home page (September 2026).</SourceNote>
      </Section>

      <CtaBand
        eyebrow="Other ways to help"
        title="Not just money."
        body="Sponsor a program, enter the gaming PC raffle, buy VGA merch, or lend a hand as a volunteer."
        ctas={[
          { label: "All the ways to help", href: "/support", icon: "arrow-right" },
          { label: "Become a sponsor", href: "/become-a-sponsor", variant: "secondary" },
        ]}
      />
    </>
  );
}
