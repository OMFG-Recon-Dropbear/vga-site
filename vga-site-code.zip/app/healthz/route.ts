/** Liveness probe for container healthchecks and the Cloudflare route test. */
export function GET() {
  return new Response("ok", { status: 200, headers: { "content-type": "text/plain", "cache-control": "no-store" } });
}
