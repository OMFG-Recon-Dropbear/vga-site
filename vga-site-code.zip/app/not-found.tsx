import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { mainNav } from "@/data/navigation";

export default function NotFound() {
  return (
    <section className="relative isolate overflow-hidden bg-ink-950">
      <div className="absolute inset-0 -z-10 bg-grid bg-grid-fade opacity-70" aria-hidden="true" />
      <div className="container py-24 sm:py-32">
        <p className="eyebrow mb-4">404 — page not found</p>
        <h1 className="text-display-lg uppercase text-ink-50">
          That page has <span className="gold-text">redeployed.</span>
        </h1>
        <p className="mt-5 max-w-xl text-lg text-ink-200">The page you’re after doesn’t exist on the new VGA site, or has moved. Try one of the main sections below, or head back to the home page.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button href="/" icon="arrow-right">
            Home
          </Button>
          <Button href="/contact" variant="secondary">
            Contact VGA
          </Button>
        </div>
        <ul className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {mainNav.map((g) => (
            <li key={g.href}>
              <Link href={g.href} className="card card-hover block p-4 font-display text-lg font-semibold uppercase tracking-[0.06em] text-ink-50 hover:text-gold-200">
                {g.label}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
