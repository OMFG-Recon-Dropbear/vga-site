import type { MetadataRoute } from "next";
import { site } from "@/data/site";

export default function robots(): MetadataRoute.Robots {
  if (process.env.SITE_NOINDEX === "1") {
    // Staging/preview host: keep the whole site out of search engines
    return { rules: [{ userAgent: "*", disallow: "/" }], host: site.url };
  }
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/api/", "/healthz"] }],
    sitemap: `${site.url}/sitemap.xml`,
    host: site.url,
  };
}
