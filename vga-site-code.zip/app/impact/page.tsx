import type { Metadata } from "next";
import Image from "next/image";
import { headlineStats, evaluationStats } from "@/data/stats";
import { about } from "@/data/about";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { AnimatedNumber } from "@/components/ui/Stat";
import { SourceNote } from "@/components/ui/SourceNote";
import { CtaBand } from "@/components/ui/CtaBand";
import { Reveal } from "@/components/ui/Reveal";
import { Icon } from "@/components/ui/Icon";

export const metadata: Metadata = buildMetadata({
  title: "Our Impact",
  description: "Five years of Veteran Gaming Australia in numbers — 46,000+ Veterans and families supported, 19 gaming hubs, 700+ events, and an independent evaluation confirming strong social connection outcomes.",
  path: "/impact",
  image: images["news/vga-social-event-stadium"].src,
});

const reach = [
  { value: 7, label: "states and territories" },
  { value: 17, label: "Social Connection Events evaluated" },
  { value: 256, suffix: "+", label: "direct event participants" },
  { value: 9000, label: "Veterans reached nationally through grant-supported activities" },
  { value: 10000, suffix: "+", label: "Veteran family and community members reached" },
];

const twelveMonths = [
  "Established 14 new Social Gaming and Esports Hubs across Defence bases, Veteran and Family Hubs, and veteran support organisations.",
  "Delivered more than 40 family-inclusive, in-person social connection events, with our fastest event reaching full capacity in just 15 minutes.",
  "Increased digital server capacity two fold whilst also delivering over 200 digital social events over the last 12 months.",
  "Over 70 hours of voice conversations in our digital servers each week between Veterans and family members.",
  "Seen our online community exchange more than 1,000 messages every week, strengthening peer support and social connectedness.",
];

export default function ImpactPage() {
  const care = images["programs/care-package-bundle"];
  return (
    <>
      <PageHero
        eyebrow="Our impact"
        title={
          <>
            Connection you can <span className="gold-text">measure.</span>
          </>
        }
        lead="Since 2021, Veteran Gaming Australia has supported over 46,000 Veterans and Veteran families across Australia, delivering connection through both digital and in-person programs. In 2026 an independent evaluation confirmed the model works."
        image="news/vga-social-event-stadium"
        imagePosition="center 35%"
        crumbs={[{ name: "About", path: "/about-us" }, { name: "Our Impact", path: "/impact" }]}
      >
        <Button href={about.impactReportPdf} icon="download" external>
          5 Years in the Game report (PDF)
        </Button>
        <Button href={about.evaluationReportUrl} variant="secondary" icon="external" external>
          Independent evaluation report
        </Button>
      </PageHero>

      <Section labelledBy="numbers">
        <SectionHeader id="numbers" eyebrow="Since 2021" title="VGA by the numbers" />
        <ul className="grid grid-cols-2 gap-4 md:grid-cols-3">
          {headlineStats.map((s, i) => (
            <Reveal as="li" key={s.label} delay={i * 50} className="card p-6">
              <p className="font-display text-5xl font-bold leading-none text-gold-200">
                <AnimatedNumber value={s.value} prefix={s.prefix} suffix={s.suffix} />
              </p>
              <p className="mt-3 font-display text-xl font-semibold uppercase leading-tight text-ink-50">{s.label}</p>
              {s.detail ? <p className="mt-2 text-sm text-ink-300">{s.detail}</p> : null}
              <p className="mt-3 text-[0.7rem] uppercase tracking-[0.14em] text-ink-500">Source: {s.source}</p>
            </Reveal>
          ))}
        </ul>
      </Section>

      <Section tone="raised" labelledBy="evaluation">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
          <div>
            <p className="eyebrow mb-4">Independent evaluation · March 2026</p>
            <h2 id="evaluation" className="text-display-md uppercase text-ink-50">
              Externally validated results
            </h2>
            <p className="mt-5 text-lg text-ink-200">
              VGA completed an independent external evaluation of its Social Connection Events, STEM Learning and Esports program, funded through the Veteran Wellbeing Grants Program. The evaluation was independently delivered by First Person Consulting, using participant surveys, staff feedback, and delivery data collected across seven states and territories.
            </p>
            <p className="mt-4 text-ink-200">This independence is critical — the findings are not self-reported impact claims, but externally validated results.</p>
            <ul className="mt-6 grid grid-cols-2 gap-3">
              {reach.map((r) => (
                <li key={r.label} className="rounded border border-ink-700 bg-ink-900/70 p-4">
                  <p className="font-display text-3xl font-bold leading-none text-gold-200">
                    <AnimatedNumber value={r.value} suffix={r.suffix} />
                  </p>
                  <p className="mt-1 text-sm text-ink-300">{r.label}</p>
                </li>
              ))}
            </ul>
            <Button href="/news/independent-evaluation-confirms-veteran-gaming-australia-programs-deliver-strong-social-connection-a" variant="ghost" icon="arrow-right" className="mt-6">
              Read the full announcement
            </Button>
          </div>
          <div className="space-y-4">
            <div className="chamfer-frame">
              <div className="chamfer bg-ink-900 p-6 sm:p-8">
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">Social connection</p>
                <p className="mt-3 font-display text-6xl font-bold leading-none text-ink-50">
                  18% <span className="text-gold-500">→</span> 68%
                </p>
                <p className="mt-3 text-ink-100">Veterans reporting feeling very or extremely connected — before events → after events. Average social connection score increased by +1.0 on a 5-point scale.</p>
              </div>
            </div>
            <ul className="grid gap-4 sm:grid-cols-2">
              {evaluationStats
                .filter((s) => s.value !== 68 && s.value !== 7)
                .map((s) => (
                  <li key={s.label} className="card p-5">
                    <p className="font-display text-4xl font-bold leading-none text-gold-200">
                      {s.value}
                      {s.suffix}
                    </p>
                    <p className="mt-2 text-sm text-ink-200">{s.label}</p>
                  </li>
                ))}
            </ul>
            <div className="card p-5">
              <p className="font-display text-lg font-semibold uppercase text-ink-50">What the evaluation confirmed</p>
              <ul className="mt-3 space-y-2 text-ink-200">
                {["Social connection is a measurable, achievable outcome", "Gaming and technology can be protective, not harmful, when delivered safely", "Hybrid models (digital + physical) outperform one-off events", "Family inclusion emerged as one of the strongest protective and wellbeing factors", "Veterans consistently described VGA’s online Discord community as a bridge to real-world connection"].map((l) => (
                  <li key={l} className="flex gap-3">
                    <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-gold-500" />
                    <span>{l}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        <SourceNote>All figures from VGA’s announcement “Independent Evaluation Confirms Veteran Gaming Australia Programs Deliver Strong Social Connection and Wellbeing Outcomes” (4 March 2026) and the 5 Years in the Game report.</SourceNote>
      </Section>

      <Section labelledBy="year">
        <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-center">
          <div>
            <p className="eyebrow mb-4">The last 12 months</p>
            <h2 id="year" className="text-display-md uppercase text-ink-50">
              Demand has never been greater
            </h2>
            <p className="mt-4 text-ink-300">Over the 12 months to July 2026, Veteran Gaming Australia has:</p>
            <ul className="mt-5 space-y-3">
              {twelveMonths.map((t) => (
                <li key={t} className="flex gap-3 text-ink-100">
                  <span className="mt-2 h-2 w-2 shrink-0 rotate-45 bg-gold-500" aria-hidden="true" />
                  <span>{t}</span>
                </li>
              ))}
            </ul>
            <SourceNote>From “Veteran Gaming Australia Disappointed Following Unsuccessful DVA Wellbeing Grant Application” (29 July 2026).</SourceNote>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button href="/donate" icon="arrow-right">
                Support the programs
              </Button>
              <Button href="/become-a-sponsor" variant="secondary">
                Sponsor VGA
              </Button>
            </div>
          </div>
          <div className="overflow-hidden rounded-lg border border-ink-700">
            <Image src={care.src} alt={care.alt} width={care.width} height={care.height} sizes="(min-width: 1024px) 40vw, 100vw" className="h-full w-full object-cover" />
          </div>
        </div>
      </Section>

      <Section tone="deep" labelledBy="recognition">
        <SectionHeader id="recognition" eyebrow="Recognition & awards" title="Awards that reflect the people behind VGA" />
        <ol className="grid gap-6 md:grid-cols-3">
          {about.recognition.map((r) => (
            <li key={r.year} className="card p-6">
              <p className="font-display text-4xl font-bold text-gold-200">{r.year}</p>
              <p className="mt-3 text-ink-100">{r.text}</p>
            </li>
          ))}
        </ol>
      </Section>

      <CtaBand
        eyebrow="Read the full story"
        title="Five years in the game."
        body="The April 2026 impact report covers the mission, programs, recognition, statistics, sponsors, team and board."
        ctas={[
          { label: "Download the report (PDF, 22 MB)", href: about.impactReportPdf, icon: "download" },
          { label: "About VGA", href: "/about-us", variant: "secondary", icon: "arrow-right" },
        ]}
      />
    </>
  );
}
