import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { team } from "@/data/team";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Button } from "@/components/ui/Button";
import { TeamCard } from "@/components/team/TeamCard";

type Params = { slug: string };
const profiles = team.filter((m) => m.bio);

export function generateStaticParams(): Params[] {
  return profiles.map((m) => ({ slug: m.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const m = profiles.find((x) => x.slug === slug);
  if (!m) return {};
  return buildMetadata({ title: `${m.name} — ${m.role}`, description: m.summary ?? `${m.name}, ${m.role} at Veteran Gaming Australia.`, path: `/our-team/${m.slug}`, image: m.image ? images[m.image].src : undefined, type: "article" });
}

export default async function TeamProfilePage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const m = profiles.find((x) => x.slug === slug);
  if (!m) notFound();
  const img = m.image ? images[m.image] : null;
  const others = profiles.filter((x) => x.slug !== m.slug);
  return (
    <article className="container py-12 sm:py-16">
      <Breadcrumbs items={[{ name: "About", path: "/about-us" }, { name: "Our Team", path: "/our-team" }, { name: m.name, path: `/our-team/${m.slug}` }]} className="mb-8" />
      <div className="grid gap-10 lg:grid-cols-[minmax(0,20rem)_1fr] lg:gap-16">
        <div>
          {img ? (
            <div className="chamfer-frame">
              <div className="chamfer overflow-hidden bg-ink-850">
                <Image src={img.src} alt={`${m.name}, ${m.role}`} width={img.width} height={img.height} sizes="(min-width: 1024px) 320px, 100vw" priority className="aspect-square w-full object-cover object-top" />
              </div>
            </div>
          ) : null}
        </div>
        <div>
          <p className="eyebrow mb-3">{m.role}</p>
          <h1 className="text-display-lg uppercase text-ink-50">{m.name}</h1>
          {m.summary ? <p className="mt-5 text-xl leading-relaxed text-ink-100">{m.summary}</p> : null}
          {m.bio ? <div className="prose-vga mt-6"><p>{m.bio}</p></div> : null}
          <div className="mt-8 flex flex-wrap gap-3">
            <Button href="/our-team" variant="secondary" icon="chevron-left" iconPosition="left">
              Back to the team
            </Button>
          </div>
        </div>
      </div>
      {others.length ? (
        <section className="mt-16 border-t border-ink-700/70 pt-10" aria-labelledby="more-profiles">
          <h2 id="more-profiles" className="font-display text-2xl font-bold uppercase text-ink-50">
            More profiles
          </h2>
          <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {others.map((o) => (
              <li key={o.slug}>
                <TeamCard member={o} />
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </article>
  );
}
