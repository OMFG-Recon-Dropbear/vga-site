import type { Metadata } from "next";
import { team, teamGroups, volunteerThanks, volunteerWorkforce, boardStatement } from "@/data/team";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { TeamCard } from "@/components/team/TeamCard";
import { CtaBand } from "@/components/ui/CtaBand";
import { Reveal } from "@/components/ui/Reveal";

export const metadata: Metadata = buildMetadata({
  title: "Our Team",
  description: "Meet the volunteers behind Veteran Gaming Australia — the board, ambassador, state and regional representatives, and the community team.",
  path: "/our-team",
  image: images["gallery/newsletter-may-aug-2026/03"].src,
});

export default function TeamPage() {
  return (
    <>
      <PageHero
        eyebrow="Our team"
        title={
          <>
            100% volunteer run. <span className="gold-text">100% Veteran led.</span>
          </>
        }
        lead={volunteerWorkforce}
        image="gallery/newsletter-may-aug-2026/03"
        imagePosition="center 30%"
        crumbs={[{ name: "About", path: "/about-us" }, { name: "Our Team", path: "/our-team" }]}
      />
      {teamGroups.map((g, gi) => {
        const members = team.filter((m) => m.group === g.key);
        if (!members.length) return null;
        return (
          <Section key={g.key} tone={gi % 2 === 1 ? "raised" : "default"} labelledBy={`group-${g.key}`}>
            <SectionHeader id={`group-${g.key}`} eyebrow={`0${gi + 1}`} title={g.title} lead={g.key === "board" ? boardStatement : g.blurb || undefined} size="sm" />
            <ul className={g.key === "board" ? "grid gap-6 sm:grid-cols-2 lg:grid-cols-3" : "grid gap-5 grid-cols-2 md:grid-cols-3 lg:grid-cols-4"}>
              {members.map((m, i) => (
                <Reveal as="li" key={m.slug} delay={i * 40}>
                  <TeamCard member={m} size={g.key === "board" ? "lg" : "md"} />
                </Reveal>
              ))}
            </ul>
            {g.key === "ambassador" ? <p className="mt-8 max-w-3xl text-lg text-ink-200">{volunteerThanks}</p> : null}
          </Section>
        );
      })}
      <CtaBand
        eyebrow="Volunteer"
        title="Want to help behind the scenes?"
        body="From event coordinators and state reps to server admins, Discord moderators, Padres and esports coaches — VGA runs on volunteers. Get in touch and tell us what you’re good at."
        ctas={[
          { label: "Contact us", href: "/contact", icon: "arrow-right" },
          { label: "Become a member first", href: "/become-a-member", variant: "secondary" },
        ]}
      />
    </>
  );
}
