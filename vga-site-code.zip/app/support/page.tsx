import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { sponsorshipPlans } from "@/data/sponsors";
import { volunteerWorkforce } from "@/data/team";
import { products } from "@/data/shop";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon, type IconName } from "@/components/ui/Icon";
import { SourceNote } from "@/components/ui/SourceNote";
import { NewsletterForm } from "@/components/forms/NewsletterForm";
import { Reveal } from "@/components/ui/Reveal";

export const metadata: Metadata = buildMetadata({
  title: "Support VGA — ways to help",
  description: "Ways to support Veteran Gaming Australia: donate, become a sponsor, enter the gaming PC raffle, support VGA on Patreon, buy VGA merch, volunteer, or follow and share.",
  path: "/support",
  image: images["news/gaming-pc-raffle-2026"].src,
});

type Way = { icon: IconName; title: string; body: string; href: string; cta: string; external?: boolean; source?: string };

const ways: Way[] = [
  { icon: "heart", title: "Donate", body: "Every donation helps Veteran Gaming Australia provide free programs that reduce social isolation and strengthen connection for Veterans and their families.", href: "/donate", cta: "Donate" },
  { icon: "star", title: "Become a sponsor", body: `Sponsorship packages from ${sponsorshipPlans[0].price} to ${sponsorshipPlans[sponsorshipPlans.length - 1].price}, valid for 12 months — Legends wall, socials, Team VGA sim cars and more.`, href: "/become-a-sponsor", cta: "Sponsorship packages" },
  { icon: "trophy", title: "Enter the gaming PC raffle", body: "VGA’s fundraising raffle launched on 3 August 2026 with a custom gaming PC setup donated by Campbell’s Custom Computers. 100% of raffle proceeds support VGA’s 100% volunteer-run and led community-charity programs for Veterans and Veteran Families.", href: site.raffleUrl, cta: "Buy raffle tickets", external: true, source: "VGA May–August 2026 newsletter" },
  { icon: "users", title: "Support us through Patreon", body: "Back VGA month to month on Patreon.", href: site.socials.patreon, cta: "VGA on Patreon", external: true },
  { icon: "package", title: "Shop VGA merch", body: `Support Veteran Gaming Australia by purchasing one of our products — ${products.length} items from hoodies and polos to patches, pins and the 5 Year Celebration Challenge Coin.`, href: "/shop", cta: "Visit the shop" },
  { icon: "controller", title: "Volunteer", body: volunteerWorkforce, href: "/contact?subject=Volunteering", cta: "Ask about volunteering", source: "5 Years in the Game report (2026)" },
];

export default function SupportPage() {
  const raffle = images["news/gaming-pc-raffle-2026"];
  return (
    <>
      <PageHero
        eyebrow="Support VGA"
        title={
          <>
            Ways to <span className="gold-text">help.</span>
          </>
        }
        lead={`${site.volunteerRun} Every program is free for Veterans and families — here is how you can keep it that way.`}
        image="news/gaming-pc-raffle-2026"
        imagePosition="center"
        crumbs={[{ name: "Support VGA", path: "/support" }]}
      >
        <Button href="/donate" icon="heart" iconPosition="left">
          Donate
        </Button>
        <Button href="/become-a-sponsor" variant="secondary" icon="arrow-right">
          Become a sponsor
        </Button>
      </PageHero>

      <Section labelledBy="ways-title">
        <SectionHeader id="ways-title" eyebrow="Pick your way" title="Six ways to back Veterans and families" />
        <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {ways.map((w, i) => (
            <Reveal as="li" key={w.title} delay={i * 40} className="card flex h-full flex-col p-6">
              <span className="chamfer-sm flex h-12 w-12 items-center justify-center bg-gold-500/10 text-gold-300">
                <Icon name={w.icon} className="h-6 w-6" />
              </span>
              <h3 className="mt-4 font-display text-2xl font-bold uppercase text-ink-50">{w.title}</h3>
              <p className="mt-2 flex-1 text-ink-200">{w.body}</p>
              {w.source ? <p className="mt-2 text-xs text-ink-500">Source: {w.source}</p> : null}
              <Button href={w.href} variant="ghost" icon={w.external ? "external" : "arrow-right"} className="mt-4" external={w.external}>
                {w.cta}
              </Button>
            </Reveal>
          ))}
        </ul>
      </Section>

      <Section tone="raised" labelledBy="raffle-title">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="overflow-hidden rounded-lg border border-ink-700">
            <Image src={raffle.src} alt={raffle.alt} width={raffle.width} height={raffle.height} sizes="(min-width: 1024px) 50vw, 100vw" className="h-full w-full object-cover" />
          </div>
          <div>
            <p className="eyebrow mb-4">Fundraiser · launched 3 August 2026</p>
            <h2 id="raffle-title" className="text-display-md uppercase text-ink-50">
              Win a custom gaming PC
            </h2>
            <p className="mt-5 text-lg text-ink-200">Our latest VGA fundraising raffle officially launched on 3 August 2026, with an incredible gaming PC setup generously donated by Campbell’s Custom Computers. The prize package gives one lucky winner the chance to take home a fantastic custom gaming setup while directly supporting VGA’s work.</p>
            <p className="mt-3 text-ink-300">Importantly, 100% of raffle proceeds support VGA’s 100% volunteer-run and led community-charity programs for Veterans and Veteran Families.</p>
            <Button href={site.raffleUrl} icon="external" className="mt-6" external>
              Enter the raffle on RaffleTix
            </Button>
            <SourceNote>From the VGA May–August 2026 newsletter. Check the raffle page for the current draw status and terms.</SourceNote>
          </div>
        </div>
      </Section>

      <Section labelledBy="follow-title">
        <div className="grid gap-10 lg:grid-cols-[1fr_1fr]">
          <div>
            <p className="eyebrow mb-4">Free, and it matters</p>
            <h2 id="follow-title" className="text-display-md uppercase text-ink-50">
              Follow, share, subscribe
            </h2>
            <p className="mt-4 text-lg text-ink-200">Sharing VGA’s posts helps Veterans find the community. Follow along and get the newsletter.</p>
            <ul className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
              {(
                [
                  ["discord", "Discord", site.socials.discord],
                  ["facebook", "Facebook", site.socials.facebook],
                  ["instagram", "Instagram", site.socials.instagram],
                  ["youtube", "YouTube", site.socials.youtube],
                  ["twitch", "Twitch", site.socials.twitch],
                  ["patreon", "Patreon", site.socials.patreon],
                ] as [IconName, string, string][]
              ).map(([icon, label, href]) => (
                <li key={label}>
                  <a href={href} target="_blank" rel="noopener noreferrer" className="card card-hover flex items-center gap-3 p-4 text-ink-100 hover:text-gold-200" aria-label={`${label} (opens in a new tab)`}>
                    <Icon name={icon} className="h-5 w-5 text-gold-300" /> {label}
                  </a>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-sm text-ink-300">
              Also on Facebook:{" "}
              <Link href={site.socials.facebookGroup} className="text-gold-200 underline underline-offset-4 hover:text-gold-100" target="_blank" rel="noopener noreferrer">
                the VGA community group
              </Link>
            </p>
          </div>
          <div className="chamfer-frame self-start">
            <div className="chamfer bg-ink-950 p-6 sm:p-8">
              <p className="eyebrow mb-3">Newsletter</p>
              <h3 className="font-display text-3xl font-bold uppercase text-ink-50">Subscribe</h3>
              <p className="mt-2 text-ink-300">Activities, events, advocacy and community updates.</p>
              <div className="mt-5">
                <NewsletterForm />
              </div>
            </div>
          </div>
        </div>
      </Section>

      <CtaBand eyebrow="Questions?" title="Talk to the team." body={`Email ${site.email} or send a message through the contact form.`} ctas={[{ label: "Contact VGA", href: "/contact", icon: "mail" }, { label: "Become a member", href: "/become-a-member", variant: "secondary", icon: "arrow-right" }]} />
    </>
  );
}
