import type { MetadataRoute } from "next";
import { site } from "@/data/site";
import { allPosts, albums } from "@/lib/content";
import { programs } from "@/data/programs";
import { guides } from "@/data/education";
import { sponsorYears } from "@/data/sponsors";
import { products } from "@/data/shop";
import { team } from "@/data/team";

const detailPrograms = ["game-servers", "care-packages", "hospital-loan-program", "air-assault"];

export default function sitemap(): MetadataRoute.Sitemap {
  const base = site.url;
  const now = new Date();
  const staticRoutes: { path: string; priority: number; changeFrequency: MetadataRoute.Sitemap[number]["changeFrequency"] }[] = [
    { path: "/", priority: 1, changeFrequency: "weekly" },
    { path: "/about-us", priority: 0.8, changeFrequency: "monthly" },
    { path: "/our-team", priority: 0.7, changeFrequency: "monthly" },
    { path: "/impact", priority: 0.7, changeFrequency: "monthly" },
    { path: "/programs", priority: 0.9, changeFrequency: "monthly" },
    { path: "/gaming-hubs", priority: 0.9, changeFrequency: "monthly" },
    { path: "/esports", priority: 0.8, changeFrequency: "monthly" },
    { path: "/esports/ovel", priority: 0.7, changeFrequency: "monthly" },
    { path: "/esports/sim-racing", priority: 0.6, changeFrequency: "monthly" },
    { path: "/esports/call-of-duty", priority: 0.4, changeFrequency: "monthly" },
    { path: "/events", priority: 0.8, changeFrequency: "weekly" },
    { path: "/news", priority: 0.8, changeFrequency: "weekly" },
    { path: "/news/category/news", priority: 0.5, changeFrequency: "weekly" },
    { path: "/news/category/newsletter", priority: 0.5, changeFrequency: "monthly" },
    { path: "/education", priority: 0.6, changeFrequency: "yearly" },
    { path: "/gallery", priority: 0.6, changeFrequency: "monthly" },
    { path: "/sponsors", priority: 0.7, changeFrequency: "monthly" },
    { path: "/become-a-sponsor", priority: 0.7, changeFrequency: "yearly" },
    { path: "/donate", priority: 0.9, changeFrequency: "monthly" },
    { path: "/support", priority: 0.7, changeFrequency: "monthly" },
    { path: "/become-a-member", priority: 0.9, changeFrequency: "yearly" },
    { path: "/shop", priority: 0.6, changeFrequency: "monthly" },
    { path: "/contact", priority: 0.6, changeFrequency: "yearly" },
    { path: "/privacy-policy", priority: 0.2, changeFrequency: "yearly" },
  ];
  const entries: MetadataRoute.Sitemap = staticRoutes.map((r) => ({ url: `${base}${r.path}`, lastModified: now, changeFrequency: r.changeFrequency, priority: r.priority }));
  for (const p of programs.filter((x) => detailPrograms.includes(x.slug))) entries.push({ url: `${base}/programs/${p.slug}`, lastModified: now, changeFrequency: "monthly", priority: 0.7 });
  for (const m of team.filter((x) => x.bio)) entries.push({ url: `${base}/our-team/${m.slug}`, lastModified: now, changeFrequency: "yearly", priority: 0.4 });
  for (const g of guides) entries.push({ url: `${base}/education/${g.slug}`, lastModified: now, changeFrequency: "yearly", priority: 0.5 });
  for (const y of sponsorYears.slice(1)) entries.push({ url: `${base}/sponsors/${y.year}`, lastModified: now, changeFrequency: "yearly", priority: 0.4 });
  for (const p of products) entries.push({ url: `${base}/shop/${p.slug}`, lastModified: now, changeFrequency: "monthly", priority: 0.4 });
  for (const a of albums()) entries.push({ url: `${base}/gallery/${a.slug}`, lastModified: new Date(a.date), changeFrequency: "yearly", priority: 0.4 });
  for (const p of allPosts()) entries.push({ url: `${base}/news/${p.slug}`, lastModified: new Date(p.updated ?? p.date), changeFrequency: "yearly", priority: 0.6 });
  return entries;
}
