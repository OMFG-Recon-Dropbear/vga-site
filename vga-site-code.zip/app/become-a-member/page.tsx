import type { Metadata } from "next";
import Image from "next/image";
import { membership } from "@/data/support";
import { loyaltyProgram } from "@/data/shop";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { SourceNote } from "@/components/ui/SourceNote";
import { MembershipForm } from "@/components/forms/MembershipForm";

export const metadata: Metadata = buildMetadata({
  title: "Become a Member — free membership",
  description: "Are you currently serving, a transitioned veteran or a family member of someone who served and meets the eligibility criteria? You can access the awesome gaming community of VGA. We provide a fun and supportive community with a focus on social and emotional well-being.",
  path: "/become-a-member",
  image: images["about/community-dinner"].src,
});

export default function BecomeAMemberPage() {
  const photo = images["about/community-dinner"];
  return (
    <>
      <PageHero
        eyebrow="Membership is free"
        title={
          <>
            Become a <span className="gold-text">member.</span>
          </>
        }
        lead={membership.intro}
        image="about/community-dinner"
        imagePosition="center 40%"
        crumbs={[{ name: "Become a Member", path: "/become-a-member" }]}
      >
        <Button href="#apply" icon="arrow-right">
          Apply now
        </Button>
        <Button href={site.socials.discord} variant="discord" icon="discord" iconPosition="left">
          Join Discord
        </Button>
      </PageHero>

      <Section labelledBy="eligibility-title">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
          <div className="space-y-8 lg:sticky lg:top-[calc(var(--header-h)+1.5rem)] lg:self-start">
            <div>
              <p className="eyebrow mb-4">Eligibility criteria</p>
              <h2 id="eligibility-title" className="text-display-md uppercase text-ink-50">
                Who can join
              </h2>
              <p className="mt-4 text-lg text-ink-200">{membership.promise}</p>
              <ul className="mt-5 space-y-3">
                {membership.eligibility.map((e) => (
                  <li key={e} className="flex gap-3 text-ink-100">
                    <Icon name="check" className="mt-1 h-5 w-5 shrink-0 text-gold-500" />
                    <span>{e}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-5 text-ink-200">{membership.process}</p>
              <p className="mt-3 font-display text-xl font-semibold uppercase text-gold-200">{membership.cost}</p>
            </div>
            <div className="card p-5">
              <h3 className="font-display text-lg font-bold uppercase text-ink-50">Verification</h3>
              <p className="mt-2 text-sm text-ink-200">{membership.verificationNotice}</p>
              <ul className="mt-3 flex flex-wrap gap-2">
                {membership.verificationTypes.map((v) => (
                  <li key={v} className="rounded-sm border border-ink-600 bg-ink-800 px-2.5 py-1 text-xs font-semibold uppercase tracking-[0.1em] text-ink-100">
                    {v}
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-xs text-ink-400">{membership.dpnNote}</p>
              <p className="mt-2 text-xs text-ink-400">{membership.discordNote}</p>
            </div>
            <div className="overflow-hidden rounded-lg border border-ink-700">
              <Image src={photo.src} alt={photo.alt} width={photo.width} height={photo.height} sizes="(min-width: 1024px) 40vw, 100vw" className="aspect-[4/3] h-full w-full object-cover" />
            </div>
          </div>

          <div id="apply" className="scroll-mt-24">
            <div className="chamfer-frame">
              <div className="chamfer bg-ink-950 p-6 sm:p-8">
                <p className="eyebrow mb-3">Member application</p>
                <h2 className="font-display text-3xl font-bold uppercase text-ink-50">Apply for membership</h2>
                <p className="mt-2 text-sm text-ink-300">Three short steps. Fields marked * are required. Your details are only used to verify eligibility and get you connected.</p>
                <div className="mt-6">
                  <MembershipForm />
                </div>
              </div>
            </div>
            <SourceNote>Your details are used only to verify eligibility and connect you with the community.</SourceNote>
          </div>
        </div>
      </Section>

      <Section tone="raised" labelledBy="rewards-title">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr] lg:items-center">
          <div>
            <p className="eyebrow mb-4">Member rewards</p>
            <h2 id="rewards-title" className="text-display-md uppercase text-ink-50">
              Loyalty program
            </h2>
            <p className="mt-4 text-ink-200">Members earn points on VGA purchases and redeem them for discounts in the shop.</p>
            <SourceNote>Points are managed through VGA’s shop account system.</SourceNote>
          </div>
          <ol className="grid gap-4 sm:grid-cols-3">
            {loyaltyProgram.steps.map((s, i) => (
              <li key={s.title} className="card p-5">
                <p className="font-display text-4xl font-bold text-gold-700">{String(i + 1).padStart(2, "0")}</p>
                <p className="mt-2 font-display text-xl font-bold uppercase text-ink-50">{s.title}</p>
                <p className="mt-2 text-sm text-ink-200">{s.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </Section>
    </>
  );
}
