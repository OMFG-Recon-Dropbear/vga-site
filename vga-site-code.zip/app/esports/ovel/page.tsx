import type { Metadata } from "next";
import { ovel, ovelRocketLeague2026 } from "@/data/esports";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { SourceNote } from "@/components/ui/SourceNote";
import { Icon } from "@/components/ui/Icon";
import { Accordion } from "@/components/ui/Accordion";

export const metadata: Metadata = buildMetadata({
  title: "OVEL — Oceania Veteran Esports League (Call of Duty: Black Ops 6)",
  description: "The Oceania Veteran Esports League is a premier competitive gaming event for Veterans: a five-week Call of Duty: Black Ops 6 season, double-elimination format, training, streamed matches and prizes. League overview, structure, rules, gentlemen’s agreements, registration and standings.",
  path: "/esports/ovel",
  image: images["esports/ovel-banner"].src,
});

function List({ items }: { items: string[] }) {
  return (
    <ul className="space-y-2">
      {items.map((t) => (
        <li key={t} className="flex gap-3">
          <span className="mt-2.5 h-1.5 w-1.5 shrink-0 rotate-45 bg-gold-500" aria-hidden="true" />
          <span>{t}</span>
        </li>
      ))}
    </ul>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid gap-1 border-b border-ink-700/70 py-3 sm:grid-cols-[11rem_1fr] sm:gap-4">
      <dt className="font-display text-sm font-semibold uppercase tracking-[0.14em] text-gold-500">{label}</dt>
      <dd className="text-ink-100">{value}</dd>
    </div>
  );
}

export default function OvelPage() {
  const f = ovel.format;
  const facts = [
    { label: "Game", value: f.game, icon: "controller" as const },
    { label: "Mode", value: f.mode, icon: "users" as const },
    { label: "Season", value: f.schedule.duration, icon: "calendar" as const },
    { label: "Match days", value: `${f.schedule.matchDays}, ${f.schedule.time}`, icon: "clock" as const },
  ];
  return (
    <>
      <PageHero
        eyebrow="Oceania Veteran Esports League"
        title={
          <>
            OVEL <span className="gold-text">Call of Duty: Black Ops 6</span>
          </>
        }
        lead={ovel.overview[0]}
        image="esports/ovel-banner"
        imagePosition="center"
        crumbs={[
          { name: "Programs", path: "/programs" },
          { name: "Esports", path: "/esports" },
          { name: "OVEL", path: "/esports/ovel" },
        ]}
      >
        <Button href="#register" icon="arrow-right">
          Register a team
        </Button>
        <Button href={ovel.infoPdf} variant="secondary" icon="download" external>
          Download information (PDF)
        </Button>
        <Button href="#standings" variant="ghost" icon="trophy">
          View standings
        </Button>
      </PageHero>

      <Section labelledBy="overview">
        <div className="grid gap-12 lg:grid-cols-[1.2fr_1fr]">
          <div>
            <SectionHeader id="overview" eyebrow="League overview" title="Respect, teamwork and fair play" />
            <div className="space-y-4 text-lg text-ink-200">
              {ovel.overview.slice(1).map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <div className="mt-8 rounded-md border border-gold-700/50 bg-gold-500/5 p-5">
              <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">Season status</p>
              <p className="mt-2 text-ink-100">
                The Black Ops 6 season published here was scheduled to start on {f.schedule.expectedStart}, with registrations closing 11 May 2025. Standings below are as last published. For the current OVEL competition — the 2026 Rocket League league ({ovelRocketLeague2026.challengerQualifiers.top8.length} Challenger League finalists from 33 registered teams) — see the <a href="/esports#rocket-league" className="text-gold-200 underline underline-offset-4 hover:text-gold-100">esports overview</a> and the VGA Discord.
              </p>
            </div>
          </div>
          <div className="space-y-4">
            <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              {facts.map((x) => (
                <li key={x.label} className="card flex items-start gap-4 p-5">
                  <span className="chamfer-sm flex h-11 w-11 shrink-0 items-center justify-center bg-gold-500/10 text-gold-300">
                    <Icon name={x.icon} className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="font-display text-sm font-semibold uppercase tracking-[0.14em] text-ink-300">{x.label}</p>
                    <p className="mt-1 font-display text-xl font-bold uppercase leading-tight text-ink-50">{x.value}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      <Section tone="raised" labelledBy="format">
        <SectionHeader id="format" eyebrow="Structure & format" title="How the league runs" />
        <div className="grid gap-10 lg:grid-cols-2">
          <dl>
            <Row label="Game" value={f.game} />
            <Row label="Mode" value={f.mode} />
            <Row label="Teams" value={f.teams} />
            <Row label="Elimination" value={f.elimination} />
            <Row label="Match length" value={f.matchLength} />
            <Row label="Standings" value={f.standings.join(", then ")} />
            <Row label="Duration" value={f.schedule.duration} />
            <Row label="Match days" value={`${f.schedule.matchDays}, ${f.schedule.time}`} />
            <Row label="Expected start" value={f.schedule.expectedStart} />
          </dl>
          <div className="space-y-6">
            <div className="card p-6">
              <h3 className="font-display text-xl font-bold uppercase text-ink-50">Match format</h3>
              <ol className="mt-3 grid gap-2 sm:grid-cols-2">
                {f.matchFormat.map((g) => (
                  <li key={g} className="rounded-sm border border-ink-700 bg-ink-900/60 px-3 py-2 text-ink-100">
                    {g}
                  </li>
                ))}
              </ol>
            </div>
            <div className="card p-6">
              <h3 className="font-display text-xl font-bold uppercase text-ink-50">Finals format</h3>
              <div className="mt-3 text-ink-200">
                <List items={f.finals} />
              </div>
            </div>
            <div className="card p-6">
              <h3 className="font-display text-xl font-bold uppercase text-ink-50">Training</h3>
              <p className="mt-3 text-ink-200">{f.schedule.training}</p>
            </div>
          </div>
        </div>
      </Section>

      <Section labelledBy="prizes">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr]">
          <div>
            <SectionHeader id="prizes" eyebrow="Prizes" title="What’s on the line" />
            <div className="space-y-4">
              <div className="chamfer-frame">
                <div className="chamfer bg-ink-900 p-6">
                  <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">Winners</p>
                  <div className="mt-3 text-ink-100">
                    <List items={ovel.prizes.winners} />
                  </div>
                </div>
              </div>
              <div className="card p-6">
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-ink-300">Runners-up</p>
                <div className="mt-3 text-ink-100">
                  <List items={ovel.prizes.runnersUp} />
                </div>
              </div>
            </div>
          </div>
          <div>
            <SectionHeader id="rules" eyebrow="Rules & code of conduct" title="League rules" lead="Expand a heading to read the rule in full." />
            <Accordion items={ovel.rules.map((r) => ({ heading: r.heading, content: <List items={r.items} /> }))} />
          </div>
        </div>
      </Section>

      <Section tone="raised" labelledBy="agreements">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <SectionHeader id="agreements" eyebrow="Gentlemen’s agreements" title="In-game settings & restrictions" />
            <Accordion items={ovel.agreements.map((r) => ({ heading: r.heading, content: <List items={r.items} /> }))} open={null} />
          </div>
          <div id="register">
            <SectionHeader eyebrow="Registration" title="How to join the league" />
            <div className="space-y-5 text-ink-200">
              <div>
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">Deadline</p>
                <p className="mt-1">{ovel.registration.deadline}</p>
              </div>
              <div>
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">How to join</p>
                <p className="mt-1">{ovel.registration.howToJoin}</p>
              </div>
              <div>
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">Submission</p>
                <p className="mt-1">{ovel.registration.submission}</p>
              </div>
              <div>
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">Required information</p>
                <div className="mt-2">
                  <List items={ovel.registration.required} />
                </div>
              </div>
              <p className="font-display text-xl font-semibold uppercase text-ink-50">{ovel.registration.closing}</p>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button href="/contact?subject=OVEL%20team%20registration" icon="mail" iconPosition="left">
                Register your team
              </Button>
              <Button href={site.socials.discord} variant="discord" icon="discord" iconPosition="left">
                Submit rosters on Discord
              </Button>
            </div>
            <SourceNote>Registrations are handled by email and on Discord as described above.</SourceNote>
          </div>
        </div>
      </Section>

      <Section labelledBy="standings">
        <SectionHeader id="standings" eyebrow="OVEL standings" title="Ladder" lead={ovel.standings.note} />
        <div className="overflow-x-auto rounded-lg border border-ink-700">
          <table className="w-full min-w-[32rem] text-left">
            <thead className="bg-ink-800 font-display text-sm uppercase tracking-[0.14em] text-ink-300">
              <tr>
                {ovel.standings.columns.map((c) => (
                  <th key={c} scope="col" className="px-5 py-3 font-semibold">
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-700">
              {ovel.standings.rows.map((r) => (
                <tr key={r.team} className={r.rank === 1 ? "bg-gold-500/5" : ""}>
                  <th scope="row" className="px-5 py-4 font-display text-xl font-bold uppercase text-ink-50">
                    {r.team}
                  </th>
                  <td className="px-5 py-4 font-display text-2xl font-bold text-gold-200">{r.rank}</td>
                  <td className="px-5 py-4 text-ink-100">{r.losses}</td>
                  <td className="px-5 py-4 text-ink-100">{r.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      <CtaBand
        eyebrow="Watch and follow"
        title="Every match, streamed."
        body="VGA streams matches wherever possible on the official Twitch channel — with team logos and representative organisations on screen."
        ctas={[
          { label: "VGA on Twitch", href: site.socials.twitch, icon: "external" },
          { label: "Back to esports", href: "/esports", variant: "secondary", icon: "arrow-right" },
        ]}
      />
    </>
  );
}
