import type { Metadata } from "next";
import Image from "next/image";
import { simRacing } from "@/data/esports";
import { images, type ImageKey } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { SourceNote } from "@/components/ui/SourceNote";
import { PhotoGrid } from "@/components/gallery/Lightbox";

export const metadata: Metadata = buildMetadata({
  title: "Sim Racing — Team VGA",
  description: "Team VGA sim racing: the members who have completed 3+ races for VGA (2024), the Team VGA liveries and race-day screenshots.",
  path: "/esports/sim-racing",
  image: images["esports/vga-race-car"].src,
});

export default function SimRacingPage() {
  const shots = (Object.keys(images) as ImageKey[]).filter((k) => k.startsWith("esports/sim-racing/")).map((k) => images[k]);
  const car = images["esports/vga-race-car"];
  return (
    <>
      <PageHero
        eyebrow="Team VGA"
        title={
          <>
            Sim <span className="gold-text">Racing</span>
          </>
        }
        lead="Team VGA on the virtual grid. Every livery carries the VGA shield — and our sponsors’ logos ride with it."
        image="esports/team-vga-banner"
        imagePosition="center"
        crumbs={[
          { name: "Programs", path: "/programs" },
          { name: "Esports", path: "/esports" },
          { name: "Sim Racing", path: "/esports/sim-racing" },
        ]}
      >
        <Button href={site.socials.discord} variant="discord" icon="discord" iconPosition="left">
          Race with VGA on Discord
        </Button>
        <Button href="/become-a-sponsor" variant="secondary" icon="arrow-right">
          Put your logo on the car
        </Button>
      </PageHero>

      <Section labelledBy="roster">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:items-start">
          <div>
            <SectionHeader id="roster" eyebrow="The roster" title={simRacing.rosterTitle} />
            <ol className="divide-y divide-ink-700 border-y border-ink-700">
              {simRacing.roster.map((r, i) => (
                <li key={r.name + r.handle} className="flex items-center gap-4 py-3">
                  <span className="w-8 shrink-0 font-display text-2xl font-bold text-gold-700">{String(i + 1).padStart(2, "0")}</span>
                  <div className="min-w-0">
                    <p className="font-display text-xl font-bold uppercase leading-tight text-ink-50">{r.name}</p>
                    <p className="truncate font-mono text-sm text-ink-300">{r.handle}</p>
                  </div>
                </li>
              ))}
            </ol>
            <SourceNote>Roster as published by VGA (2024 season).</SourceNote>
          </div>
          <div className="lg:sticky lg:top-[calc(var(--header-h)+1.5rem)]">
            <div className="chamfer-frame">
              <div className="chamfer overflow-hidden bg-ink-900">
                <Image src={car.src} alt={car.alt} width={car.width} height={car.height} sizes="(min-width: 1024px) 50vw, 100vw" className="h-full w-full object-cover" />
              </div>
            </div>
            <p className="mt-3 text-sm text-ink-300">{car.alt}</p>
          </div>
        </div>
      </Section>

      <Section tone="raised" labelledBy="shots">
        <SectionHeader id="shots" eyebrow="Race day" title="On track" lead="Screenshots from Team VGA races and liveries." />
        <PhotoGrid images={shots} columns={3} />
      </Section>

      <CtaBand
        eyebrow="Sponsor the team"
        title="Your logo. Our cars."
        body="Core and Hard Core sponsors get their logo on the Team VGA sim cars, plus a place on the Legends wall and VGA socials."
        ctas={[
          { label: "Sponsorship packages", href: "/become-a-sponsor", icon: "arrow-right" },
          { label: "Back to esports", href: "/esports", variant: "secondary" },
        ]}
      />
    </>
  );
}
