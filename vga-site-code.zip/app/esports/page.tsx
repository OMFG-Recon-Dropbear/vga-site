import type { Metadata } from "next";
import Image from "next/image";
import { ovel, ovelRocketLeague2026, callOfDuty } from "@/data/esports";
import { programs } from "@/data/programs";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { SourceNote } from "@/components/ui/SourceNote";
import { Icon } from "@/components/ui/Icon";
import { Reveal } from "@/components/ui/Reveal";
import { EsportsCard } from "@/components/esports/EsportsCard";

export const metadata: Metadata = buildMetadata({
  title: "Esports — Team VGA & the Oceania Veteran Esports League",
  description: "Keep up to date with Veteran Gaming Australia Esports Teams events and results — the Oceania Veteran Esports League (Call of Duty: Black Ops 6 and Rocket League), sim racing and more.",
  path: "/esports",
  image: images["esports/team-vga-banner"].src,
});

export default function EsportsPage() {
  const esportsProgram = programs.find((p) => p.slug === "esports")!;
  const tournaments = programs.find((p) => p.slug === "tournaments")!;
  const top8 = images["news/ovel-rocket-league-top-8"];
  return (
    <>
      <PageHero
        eyebrow="VGA Esports Team"
        title={
          <>
            Compete. Connect. <span className="gold-text">Represent.</span>
          </>
        }
        lead={esportsProgram.short}
        image="esports/team-vga-banner"
        imagePosition="center"
        crumbs={[
          { name: "Programs", path: "/programs" },
          { name: "Esports", path: "/esports" },
        ]}
      >
        <Button href="/esports/ovel" icon="trophy" iconPosition="left">
          OVEL — the league
        </Button>
        <Button href={site.socials.twitch} variant="secondary" icon="twitch" iconPosition="left">
          Watch on Twitch
        </Button>
      </PageHero>

      <Section labelledBy="teams">
        <SectionHeader id="teams" eyebrow="Competitions" title="Where Team VGA competes" lead="Structured competition for Veterans of every skill level — from a national league to the sim racing grid." />
        <ul className="grid gap-6 md:grid-cols-3">
          <Reveal as="li">
            <EsportsCard title="OVEL" subtitle={ovel.title} href="/esports/ovel" image="esports/ovel-banner" status="Call of Duty: Black Ops 6" body="The Oceania Veteran Esports League — a five-week, double-elimination Call of Duty: Black Ops 6 season with training, streamed matches and prizes. Rules, format, standings and registration." />
          </Reveal>
          <Reveal as="li" delay={60}>
            <EsportsCard title="Sim Racing" subtitle="Team VGA" href="/esports/sim-racing" image="esports/vga-race-car" body="Team VGA on the virtual grid — the members who have completed three or more races for VGA, the liveries and the race-day screenshots." />
          </Reveal>
          <Reveal as="li" delay={120}>
            <EsportsCard title="COD Black Ops 6" subtitle="Call of Duty" href="/esports/call-of-duty" image="esports/cod-black-ops-6" status={callOfDuty.status} body="A dedicated Call of Duty page is coming soon. Black Ops 6 competition currently runs through the Oceania Veteran Esports League." />
          </Reveal>
        </ul>
      </Section>

      <Section tone="raised" labelledBy="rocket-league">
        <div className="grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:items-center">
          <div className="overflow-hidden rounded-lg border border-ink-700">
            <Image src={top8.src} alt={top8.alt} width={top8.width} height={top8.height} sizes="(min-width: 1024px) 50vw, 100vw" className="h-full w-full object-cover" />
          </div>
          <div>
            <p className="eyebrow mb-4">OVEL Rocket League · 2026</p>
            <h2 id="rocket-league" className="text-display-md uppercase text-ink-50">
              101 Veterans. 33 teams. One league.
            </h2>
            <p className="mt-5 text-lg text-ink-200">{ovelRocketLeague2026.participants}</p>
            <div className="mt-6 space-y-4">
              <div className="card p-5">
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">Challenger League qualifiers — {ovelRocketLeague2026.challengerQualifiers.date}</p>
                <p className="mt-2 text-ink-200">{ovelRocketLeague2026.challengerQualifiers.summary}</p>
                <p className="mt-3 text-sm font-semibold uppercase tracking-[0.12em] text-ink-300">Top 8</p>
                <ul className="mt-2 flex flex-wrap gap-2">
                  {ovelRocketLeague2026.challengerQualifiers.top8.map((t) => (
                    <li key={t} className="rounded-sm border border-ink-600 bg-ink-800 px-2.5 py-1 font-display text-sm font-semibold uppercase tracking-[0.06em] text-ink-50">
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="card p-5">
                <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">Premier League qualifiers — {ovelRocketLeague2026.premierQualifiers.date}</p>
                <p className="mt-2 text-ink-200">{ovelRocketLeague2026.premierQualifiers.summary}</p>
              </div>
            </div>
            <SourceNote>From the VGA May–August 2026 newsletter.</SourceNote>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button href="/news/vga-may-august-newsletter" variant="secondary" icon="arrow-right">
                Read the newsletter
              </Button>
              <Button href={site.socials.twitch} variant="ghost" icon="external">
                VGA on Twitch
              </Button>
            </div>
          </div>
        </div>
      </Section>

      <Section labelledBy="why">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <p className="eyebrow mb-4">Why esports</p>
            <h2 id="why" className="text-display-md uppercase text-ink-50">
              Built on connection
            </h2>
            <div className="mt-5 space-y-4 text-lg text-ink-200">
              {(esportsProgram.howItWorks ?? []).map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <p className="mt-5 text-ink-300">
              <strong className="text-ink-50">Who can play:</strong> {esportsProgram.whoFor}
            </p>
          </div>
          <div>
            <p className="eyebrow mb-4">Tournaments</p>
            <h3 className="font-display text-3xl font-bold uppercase text-ink-50">{tournaments.short}</h3>
            <div className="mt-5 space-y-4 text-ink-200">
              {(tournaments.howItWorks ?? []).map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <ul className="mt-6 space-y-2">
              {[
                { label: "Register through the VGA Discord", href: site.socials.discord, icon: "discord" as const },
                { label: "Matches streamed on VGA’s Twitch", href: site.socials.twitch, icon: "twitch" as const },
              ].map((l) => (
                <li key={l.href}>
                  <a href={l.href} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-gold-200 hover:text-gold-100 hover:underline">
                    <Icon name={l.icon} className="h-4 w-4" /> {l.label}
                  </a>
                </li>
              ))}
            </ul>
            <SourceNote>Source: {esportsProgram.source}; {tournaments.source}.</SourceNote>
          </div>
        </div>
      </Section>

      <CtaBand
        eyebrow="Join the roster"
        title="Ready to represent?"
        body={esportsProgram.howToParticipate}
        ctas={[
          { label: "Join Discord", href: site.socials.discord, variant: "discord", icon: "discord" },
          { label: "Become a member", href: "/become-a-member", variant: "secondary", icon: "arrow-right" },
        ]}
      />
    </>
  );
}
