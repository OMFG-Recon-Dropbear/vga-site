import type { Metadata } from "next";
import { callOfDuty, ovel } from "@/data/esports";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { CtaBand } from "@/components/ui/CtaBand";
import { Button } from "@/components/ui/Button";

export const metadata: Metadata = buildMetadata({
  title: "Call of Duty: Black Ops 6",
  description: "VGA’s Call of Duty: Black Ops 6 page is coming soon. Black Ops 6 competition currently runs through the Oceania Veteran Esports League (OVEL).",
  path: "/esports/call-of-duty",
  image: images["esports/cod-black-ops-6"].src,
});

export default function CallOfDutyPage() {
  return (
    <>
      <PageHero
        eyebrow={callOfDuty.status}
        title={
          <>
            Call of Duty <span className="gold-text">Black Ops 6</span>
          </>
        }
        lead="This page is coming soon. In the meantime, VGA’s Black Ops 6 competition runs through the Oceania Veteran Esports League — a 4v4, double-elimination season with training nights, streamed matches and prizes."
        image="esports/cod-black-ops-6"
        imagePosition="center"
        crumbs={[
          { name: "Programs", path: "/programs" },
          { name: "Esports", path: "/esports" },
          { name: "Call of Duty", path: "/esports/call-of-duty" },
        ]}
      >
        <Button href="/esports/ovel" icon="trophy" iconPosition="left">
          OVEL — {ovel.game}
        </Button>
        <Button href={site.socials.discord} variant="discord" icon="discord" iconPosition="left">
          Find a squad on Discord
        </Button>
      </PageHero>
      <CtaBand
        eyebrow="While you wait"
        title="Game night is every week."
        body="Discord hosts VGA’s weekly digital socials and 24/7 game servers — the easiest way to find mates to play with tonight."
        ctas={[
          { label: "Game servers & socials", href: "/programs/game-servers", icon: "arrow-right" },
          { label: "All esports", href: "/esports", variant: "secondary" },
        ]}
      />
    </>
  );
}
