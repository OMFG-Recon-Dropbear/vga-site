import type { Metadata } from "next";
import Image from "next/image";
import { sponsorshipPlans, currentSponsorYear } from "@/data/sponsors";
import { headlineStats } from "@/data/stats";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Icon } from "@/components/ui/Icon";
import { SourceNote } from "@/components/ui/SourceNote";
import { SponsorLogo } from "@/components/sponsors/SponsorLogo";
import { Reveal } from "@/components/ui/Reveal";
import { cn } from "@/lib/utils";

export const metadata: Metadata = buildMetadata({
  title: "Become a Sponsor — sponsorship packages",
  description: "Support Veteran Gaming Australia as a Casual, Core, Hard Core or Elite sponsor. Packages from A$1,000, valid for 12 months — Legends wall, social media, Team VGA sim car logos, Twitch and more.",
  path: "/become-a-sponsor",
  image: images["esports/vga-race-car"].src,
});

export default function BecomeASponsorPage() {
  const car = images["esports/vga-race-car"];
  const elite = currentSponsorYear.tiers[0];
  const stats = headlineStats.slice(0, 4);
  return (
    <>
      <PageHero
        eyebrow="Support us"
        title={
          <>
            Become a <span className="gold-text">sponsor</span>
          </>
        }
        lead="Sponsorship funds free gaming, esports, hub and care-package programs for Veterans and families — and puts your brand in front of a national community that notices who shows up for them."
        image="esports/vga-race-car"
        imagePosition="center"
        crumbs={[{ name: "Support VGA", path: "/support" }, { name: "Become a Sponsor", path: "/become-a-sponsor" }]}
      >
        <Button href="#packages" icon="arrow-right">
          See the packages
        </Button>
        <Button href="/contact?subject=Sponsorship%20enquiry" variant="secondary" icon="mail" iconPosition="left">
          Talk to us
        </Button>
      </PageHero>

      <Section labelledBy="why-title">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr] lg:items-center">
          <div>
            <p className="eyebrow mb-4">Why sponsor VGA</p>
            <h2 id="why-title" className="text-display-md uppercase text-ink-50">
              A community that shows up
            </h2>
            <p className="mt-5 text-lg text-ink-200">{site.mission}</p>
            <p className="mt-4 text-ink-300">{site.volunteerRun}</p>
            <ul className="mt-8 grid grid-cols-2 gap-4">
              {stats.map((s) => (
                <li key={s.label} className="card p-4">
                  <p className="font-display text-3xl font-bold leading-none text-gold-200">
                    {s.prefix}
                    {s.value.toLocaleString("en-AU")}
                    {s.suffix}
                  </p>
                  <p className="mt-1 text-sm text-ink-300">{s.label}</p>
                </li>
              ))}
            </ul>
            <SourceNote>Figures as published on VGA’s home page and impact report (2026).</SourceNote>
          </div>
          <div className="chamfer-frame">
            <div className="chamfer overflow-hidden bg-ink-900">
              <Image src={car.src} alt={car.alt} width={car.width} height={car.height} sizes="(min-width: 1024px) 50vw, 100vw" className="h-full w-full object-cover" />
            </div>
          </div>
        </div>
      </Section>

      <Section tone="raised" id="packages" labelledBy="packages-title">
        <SectionHeader id="packages-title" eyebrow="Sponsorship packages" title="Choose your level" lead="All packages are valid for 12 months. Every sponsor is listed on the Legends wall." />
        <ul className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {sponsorshipPlans.map((p, i) => {
            const top = i === sponsorshipPlans.length - 1;
            return (
              <Reveal as="li" key={p.name} delay={i * 60} className="h-full">
                <div className={cn("flex h-full flex-col", top ? "chamfer-frame" : "")}>
                  <div className={cn("flex h-full flex-col p-6", top ? "chamfer bg-ink-950" : "card")}>
                    <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">{p.name}</p>
                    <p className="mt-3 font-display text-5xl font-bold leading-none text-ink-50">{p.price}</p>
                    <p className="mt-1 text-sm text-ink-300">{p.validity}</p>
                    <ul className="mt-5 flex-1 space-y-2.5">
                      {p.benefits.map((b) => (
                        <li key={b} className="flex gap-3 text-ink-100">
                          <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-gold-500" />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-6 flex flex-col gap-2">
                      <Button href={`/contact?subject=${encodeURIComponent(`${p.name} sponsorship (${p.price})`)}`} size="sm" icon="arrow-right">
                        Enquire
                      </Button>
                      <Button href={site.sponsorCheckoutUrl} size="sm" variant="ghost" icon="external" external>
                        Purchase online
                      </Button>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </ul>
        <SourceNote>Packages and benefits as published on VGA’s Support Us page. Online purchase currently uses the existing sponsorship checkout.</SourceNote>
      </Section>

      <Section labelledBy="legends-title">
        <SectionHeader id="legends-title" eyebrow="You’d be in good company" title={`${currentSponsorYear.title.replace("Sponsors", "Elite sponsors")}`} action={<Button href="/sponsors" variant="secondary" icon="arrow-right">The full Legends wall</Button>} />
        <ul className="flex flex-wrap gap-4">
          {elite.sponsors.map((s) => (
            <li key={s.name}>
              <SponsorLogo sponsor={s} size="lg" />
            </li>
          ))}
        </ul>
      </Section>

      <Section tone="deep" labelledBy="other-title">
        <SectionHeader id="other-title" eyebrow="Other ways to support" title="Not ready for a package?" />
        <ul className="grid gap-6 md:grid-cols-3">
          {[
            { icon: "heart" as const, title: "Donate", body: "One-off or regular donations fund free programs directly.", href: "/donate", cta: "Donate" },
            { icon: "package" as const, title: "Donate equipment", body: "Sponsors have also supported VGA by donating equipment and care packages — the Legends wall thanks them alongside financial sponsors.", href: "/contact?subject=Equipment%20donation", cta: "Get in touch" },
            { icon: "star" as const, title: "Patreon", body: "Support VGA month to month through Patreon.", href: site.socials.patreon, cta: "VGA on Patreon" },
          ].map((x) => (
            <li key={x.title} className="card flex flex-col p-6">
              <span className="chamfer-sm flex h-12 w-12 items-center justify-center bg-gold-500/10 text-gold-300">
                <Icon name={x.icon} className="h-6 w-6" />
              </span>
              <h3 className="mt-4 font-display text-2xl font-bold uppercase text-ink-50">{x.title}</h3>
              <p className="mt-2 flex-1 text-ink-200">{x.body}</p>
              <Button href={x.href} variant="ghost" icon="arrow-right" className="mt-4">
                {x.cta}
              </Button>
            </li>
          ))}
        </ul>
      </Section>

      <CtaBand eyebrow="Let’s talk" title="Ready to back Team VGA?" body={`Email ${site.email} or use the contact form and one of the team will be in touch.`} ctas={[{ label: "Sponsorship enquiry", href: "/contact?subject=Sponsorship%20enquiry", icon: "mail" }, { label: `Email ${site.shortName}`, href: `mailto:${site.email}?subject=Sponsorship%20enquiry`, variant: "secondary" }]} />
    </>
  );
}
