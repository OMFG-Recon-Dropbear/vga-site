import Image from "next/image";
import type { Metadata } from "next";
import { about } from "@/data/about";
import { site } from "@/data/site";
import { researchStats, headlineStats } from "@/data/stats";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { CtaBand } from "@/components/ui/CtaBand";
import { Reveal } from "@/components/ui/Reveal";
import { SourceNote } from "@/components/ui/SourceNote";
import { AnimatedNumber } from "@/components/ui/Stat";

export const metadata: Metadata = buildMetadata({
  title: "About Us — Our Story",
  description: about.metaDescription,
  path: "/about-us",
  image: images["about/community-dinner"].src,
});

const story = images["about/community-dinner"];
const cap = images["about/vga-cap-and-patch"];
const fiveYears = images["news/celebrating-5-years-of-impact"];

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About Veteran Gaming Australia"
        title={
          <>
            Built by Veterans, <span className="gold-text">for Veterans and families.</span>
          </>
        }
        lead={about.intro[0]}
        image="news/independent-evaluation-group"
        imagePosition="center 30%"
        crumbs={[{ name: "About", path: "/about-us" }]}
      >
        <Button href="/our-team" icon="arrow-right">
          Meet the team
        </Button>
        <Button href="/impact" variant="secondary">
          Our impact
        </Button>
      </PageHero>

      {/* Mission */}
      <Section labelledBy="mission">
        <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-center">
          <div>
            <p className="eyebrow mb-4">Our mission</p>
            <h2 id="mission" className="text-display-md uppercase text-ink-50">
              A community around a shared love of gaming
            </h2>
            <p className="mt-6 text-xl leading-relaxed text-ink-100">{about.missionStatement}</p>
            <p className="mt-5 text-lg leading-relaxed text-ink-200">{about.intro[1]}</p>
            <p className="mt-5 text-lg leading-relaxed text-ink-200">{site.freeServices}</p>
            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {[
                ["Founded", "2021, by Veteran and gamer Samuel Harris"],
                ["Who it’s for", "Current and ex-serving ADF & NZDF members and their immediate family (18+)"],
                ["How it runs", "100% volunteer run and led — a team of over 60 volunteers"],
                ["Status", "ACNC registered charity"],
              ].map(([k, v]) => (
                <li key={k} className="rounded border border-ink-700 bg-ink-850 px-4 py-3">
                  <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">{k}</p>
                  <p className="mt-1 text-ink-100">{v}</p>
                </li>
              ))}
            </ul>
          </div>
          <Reveal>
            <div className="relative">
              <div className="chamfer-frame">
                <div className="chamfer overflow-hidden bg-ink-850">
                  <Image src={story.src} alt={story.alt} width={story.width} height={story.height} sizes="(min-width: 1024px) 45vw, 100vw" className="h-full w-full object-cover" />
                </div>
              </div>
              <div className="absolute -bottom-6 -left-4 hidden w-40 rotate-[-4deg] overflow-hidden rounded-md border border-ink-700 shadow-lift sm:block">
                <Image src={cap.src} alt={cap.alt} width={cap.width} height={cap.height} sizes="160px" className="h-full w-full object-cover" />
              </div>
            </div>
          </Reveal>
        </div>
      </Section>

      {/* Story / timeline */}
      <Section tone="raised" labelledBy="story">
        <SectionHeader id="story" eyebrow="Our story" title="From a Facebook group to a national community-charity" lead={about.origin} />
        <ol className="relative grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {about.timeline.map((t, i) => (
            <Reveal as="li" key={t.year} delay={i * 50} className="card p-6">
              <p className="font-display text-4xl font-bold leading-none text-gold-200">{t.year}</p>
              <p className="mt-3 text-ink-100">{t.text}</p>
            </Reveal>
          ))}
        </ol>
        <SourceNote>Milestones as published by VGA on its website, in newsletters and in the April 2026 <em>5 Years in the Game</em> report.</SourceNote>
      </Section>

      {/* What we do */}
      <Section labelledBy="what-we-do">
        <SectionHeader id="what-we-do" eyebrow="What we do" title="Gaming & esports hubs, community & social impact" />
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="card p-6 sm:p-8">
            <Icon name="controller" className="h-8 w-8 text-gold-500" />
            <h3 className="mt-4 font-display text-2xl font-bold uppercase text-ink-50">Gaming & Esports Hubs</h3>
            <p className="mt-3 text-ink-200">{about.whatWeDo.hubs}</p>
            <Button href="/gaming-hubs" variant="ghost" icon="arrow-right" className="mt-4">
              See the hubs map
            </Button>
          </div>
          <div className="card p-6 sm:p-8">
            <Icon name="users" className="h-8 w-8 text-gold-500" />
            <h3 className="mt-4 font-display text-2xl font-bold uppercase text-ink-50">Community & Social Impact</h3>
            <ul className="mt-3 space-y-2 text-ink-200">
              {about.whatWeDo.communityImpact.map((line) => (
                <li key={line} className="flex gap-3">
                  <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-gold-500" />
                  <span>{line}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <p className="mt-10 max-w-3xl text-lg leading-relaxed text-ink-100">{about.belief}</p>
        <SourceNote>VGA’s About Us page has quoted 42,000+ Veterans and families supported; VGA’s later publications (April–August 2026) say 46,000+. The newer figure is used elsewhere on this site.</SourceNote>
      </Section>

      {/* Achievements */}
      <Section tone="deep" labelledBy="achievements">
        <SectionHeader id="achievements" eyebrow="Our achievements" title="Recognised for what the community delivers" />
        <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
          <ul className="space-y-4">
            {about.achievements.map((a) => (
              <li key={a} className="flex gap-4 rounded-lg border border-ink-700 bg-ink-900/60 p-5">
                <Icon name="trophy" className="h-6 w-6 shrink-0 text-gold-500" />
                <p className="text-ink-100">{a}</p>
              </li>
            ))}
          </ul>
          <ol className="relative space-y-6 border-l border-gold-700/50 pl-6">
            {about.recognition.map((r) => (
              <li key={r.year} className="relative">
                <span className="absolute -left-[1.85rem] top-1 h-3 w-3 rotate-45 bg-gold-500" aria-hidden="true" />
                <p className="font-display text-xl font-bold text-gold-200">{r.year}</p>
                <p className="mt-1 text-ink-200">{r.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </Section>

      {/* Why gaming */}
      <Section labelledBy="why-gaming">
        <div className="grid gap-12 lg:grid-cols-[1fr_1fr] lg:items-start">
          <div>
            <p className="eyebrow mb-4">Why gaming?</p>
            <h2 id="why-gaming" className="text-display-md uppercase text-ink-50">
              A de-stressor you could always rely on
            </h2>
            <div className="mt-6 space-y-4 text-lg leading-relaxed text-ink-200">
              {about.whyGaming.map((p) => (
                <p key={p.slice(0, 30)}>{p}</p>
              ))}
            </div>
            <blockquote className="mt-8 border-l-2 border-gold-500 pl-5">
              <p className="text-lg text-ink-100">“Our recent independent evaluation also highlighted that gaming was a low-pressure entry point for socially isolated Veterans and Veteran Families.”</p>
              <footer className="mt-2 text-sm text-ink-400">— VGA, <em>5 Years in the Game</em> (April 2026)</footer>
            </blockquote>
          </div>
          <div className="space-y-6">
            <div className="card p-6 sm:p-8">
              <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">{researchStats.australiaPlays2025.title}</p>
              <p className="mt-1 text-sm text-ink-300">{researchStats.australiaPlays2025.by}</p>
              <ul className="mt-4 grid grid-cols-2 gap-4">
                {researchStats.australiaPlays2025.findings.map((f) => {
                  const [num, ...rest] = f.split(" ");
                  return (
                    <li key={f}>
                      <p className="font-display text-4xl font-bold leading-none text-gold-200">{num}</p>
                      <p className="mt-1 text-sm text-ink-200">{rest.join(" ")}</p>
                    </li>
                  );
                })}
              </ul>
              <SourceNote>As quoted by VGA in the 5 Years in the Game report.</SourceNote>
            </div>
            <div className="card p-6 sm:p-8">
              <p className="font-display text-sm font-semibold uppercase tracking-[0.16em] text-gold-500">{researchStats.digitalAustralia2023.title}</p>
              <p className="mt-1 text-sm text-ink-300">{researchStats.digitalAustralia2023.by}</p>
              <p className="mt-4 text-ink-200">
                The report found the top five reasons to play games were to {researchStats.digitalAustralia2023.topReasons.slice(0, -1).join(", ")} and {researchStats.digitalAustralia2023.topReasons.slice(-1)}.
              </p>
              <ul className="mt-4 space-y-2 text-sm text-ink-200">
                {researchStats.digitalAustralia2023.findings.map((f) => (
                  <li key={f} className="flex gap-3">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rotate-45 bg-gold-500" aria-hidden="true" />
                    {f}
                  </li>
                ))}
              </ul>
              <SourceNote>Statistics from the Interactive Games and Entertainment Association (IGEA), as quoted by VGA. Health and wellbeing claims are VGA’s published statements and the cited research — not medical advice.</SourceNote>
            </div>
          </div>
        </div>
      </Section>

      {/* CEO message */}
      <Section tone="raised" labelledBy="ceo">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr] lg:items-center">
          <div className="overflow-hidden rounded-lg border border-ink-700">
            <Image src={fiveYears.src} alt={fiveYears.alt} width={fiveYears.width} height={fiveYears.height} sizes="(min-width: 1024px) 40vw, 100vw" className="h-full w-full object-cover" />
          </div>
          <div>
            <p className="eyebrow mb-4">A message from our founder</p>
            <h2 id="ceo" className="text-display-sm uppercase text-ink-50">
              Five years of Veteran Gaming Australia
            </h2>
            <blockquote className="mt-6 space-y-4 text-lg leading-relaxed text-ink-100">
              {about.ceoMessage.paragraphs.map((p) => (
                <p key={p.slice(0, 24)}>{p}</p>
              ))}
              <footer className="pt-2 text-sm text-ink-300">
                — {about.ceoMessage.name}, {about.ceoMessage.title} · {about.ceoMessage.date}
              </footer>
            </blockquote>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button href={about.impactReportPdf} variant="secondary" icon="download" external>
                Read the 5-year impact report (PDF, 22 MB)
              </Button>
            </div>
            <p className="mt-6 font-display text-xl uppercase tracking-[0.2em] text-gold-500">{about.values}</p>
          </div>
        </div>
      </Section>

      {/* Numbers */}
      <Section labelledBy="numbers">
        <SectionHeader id="numbers" eyebrow="Our impact" title="The numbers behind the community" action={<Button href="/impact" variant="secondary" icon="arrow-right">Full impact page</Button>} />
        <ul className="grid grid-cols-2 gap-4 md:grid-cols-3">
          {headlineStats.map((s) => (
            <li key={s.label} className="card p-5">
              <p className="font-display text-4xl font-bold leading-none text-gold-200">
                <AnimatedNumber value={s.value} prefix={s.prefix} suffix={s.suffix} />
              </p>
              <p className="mt-2 font-display text-lg font-semibold uppercase leading-tight text-ink-50">{s.label}</p>
            </li>
          ))}
        </ul>
      </Section>

      <CtaBand
        eyebrow="Get involved"
        title="Find your people."
        body="Membership is free. Join the Discord tonight, come to an event, or back the mission as a sponsor or donor."
        ctas={[
          { label: "Become a member", href: "/become-a-member", icon: "arrow-right" },
          { label: "Join Discord", href: site.socials.discord, variant: "discord", icon: "discord" },
        ]}
      />
    </>
  );
}
