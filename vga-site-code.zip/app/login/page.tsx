import type { Metadata } from "next";
import Image from "next/image";
import { images } from "@/data/generated/images";
import { site } from "@/data/site";
import { safeNext } from "@/lib/auth-shared";
import { Icon } from "@/components/ui/Icon";

export const metadata: Metadata = {
  title: "Sign in — website preview",
  robots: { index: false, follow: false },
};

export default async function LoginPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const next = safeNext(sp.next);
  const error = typeof sp.error === "string" ? sp.error : null;
  const logo = images["brand/vga-logo"];
  return (
    <section className="relative isolate flex min-h-[calc(100svh-var(--header-h))] items-center overflow-hidden bg-ink-950">
      <div className="absolute inset-0 -z-10 bg-grid bg-grid-fade opacity-70" aria-hidden="true" />
      <div className="container py-16">
        <div className="mx-auto max-w-md">
          <div className="chamfer-frame">
            <div className="chamfer bg-ink-900 p-7 sm:p-9">
              <div className="flex items-center gap-4">
                <Image src={logo.src} alt="" width={logo.width} height={logo.height} className="h-14 w-auto" priority />
                <div>
                  <p className="eyebrow">Website preview</p>
                  <h1 className="mt-1 font-display text-3xl font-bold uppercase leading-none text-ink-50">Sign in</h1>
                </div>
              </div>
              <p className="mt-5 text-sm text-ink-300">This is a private preview of the new {site.name} website for the VGA and Disruptive Labs project team. Sign in with the preview credentials you were given.</p>
              {error ? (
                <p role="alert" className="mt-4 flex items-start gap-2 rounded border border-red-700/60 bg-red-500/10 p-3 text-sm text-red-200">
                  <Icon name="info" className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{error === "throttled" ? "Too many attempts. Please wait ten minutes and try again." : "That username or password is not right. Please try again."}</span>
                </p>
              ) : null}
              <form method="POST" action="/api/login" className="mt-6 space-y-4">
                <input type="hidden" name="next" value={next} />
                <div>
                  <label htmlFor="username" className="label">
                    Username
                  </label>
                  <input id="username" name="username" type="text" autoComplete="username" required autoFocus className="input" />
                </div>
                <div>
                  <label htmlFor="password" className="label">
                    Password
                  </label>
                  <input id="password" name="password" type="password" autoComplete="current-password" required className="input" />
                </div>
                <button type="submit" className="chamfer-sm inline-flex w-full items-center justify-center gap-2 bg-gold-500 px-5 py-3 font-display text-[0.95rem] font-semibold uppercase tracking-[0.08em] text-ink-950 transition hover:bg-gold-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold-200">
                  Sign in <Icon name="arrow-right" className="h-4 w-4" />
                </button>
              </form>
              <p className="mt-6 text-xs text-ink-500">Your sign-in lasts 30 days on this device. Nothing else is stored.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
