import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { allPosts, getPost, relatedPosts, categorySlug, getAlbum } from "@/lib/content";
import { images, type ImageKey } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata, articleJsonLd } from "@/lib/seo";
import { absoluteUrl, formatDate } from "@/lib/utils";
import { Markdown } from "@/lib/markdown";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { JsonLd } from "@/components/ui/JsonLd";
import { Tag } from "@/components/ui/Tag";
import { Icon } from "@/components/ui/Icon";
import { Button } from "@/components/ui/Button";
import { NewsCard } from "@/components/community/NewsCard";
import { ShareButtons } from "@/components/community/ShareButtons";
import { PhotoGrid } from "@/components/gallery/Lightbox";
import { CtaBand } from "@/components/ui/CtaBand";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return allPosts().map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) return {};
  return buildMetadata({
    title: post.title,
    description: post.excerpt,
    path: `/news/${post.slug}`,
    image: post.hero ? images[post.hero as ImageKey].src : undefined,
    type: "article",
    publishedTime: post.date,
    modifiedTime: post.updated,
  });
}

export default async function PostPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) notFound();
  const hero = post.hero ? images[post.hero as ImageKey] : null;
  const cat = categorySlug(post.category);
  const catLabel = post.category === "Galleries" ? "Galleries" : post.category === "Newsletter" ? "Newsletters" : "News";
  const catHref = cat === "galleries" ? "/gallery" : `/news/category/${cat}`;
  const album = post.gallerySlug ? getAlbum(post.gallerySlug) : undefined;
  const galleryImages = post.gallery?.filter((k) => k in images).map((k) => images[k as ImageKey]) ?? [];
  const related = relatedPosts(post, 3);
  const url = absoluteUrl(`/news/${post.slug}`);
  return (
    <>
      <JsonLd data={articleJsonLd({ title: post.title, description: post.excerpt, path: `/news/${post.slug}`, image: hero?.src, datePublished: post.date, dateModified: post.updated })} />
      <article>
        <header className="border-b border-ink-700/60 bg-ink-950">
          <div className="container pt-10 sm:pt-12">
            <Breadcrumbs items={[{ name: "News", path: "/news" }, { name: catLabel, path: catHref }, { name: post.title, path: `/news/${post.slug}` }]} />
          </div>
          <div className="container grid gap-10 py-10 lg:grid-cols-[1.1fr_1fr] lg:items-center lg:py-16">
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <Link href={catHref}>
                  <Tag>{post.category}</Tag>
                </Link>
                <p className="text-sm text-ink-300">
                  <time dateTime={post.date}>{formatDate(post.date, { month: "long" })}</time>
                  {post.updated && post.updated !== post.date ? <> · Updated <time dateTime={post.updated}>{formatDate(post.updated, { month: "long" })}</time></> : null}
                  {" · "}
                  {post.readingTime} min read
                </p>
              </div>
              <h1 className="mt-5 text-display-md uppercase text-ink-50 lg:text-display-lg">{post.title}</h1>
              {post.excerpt ? <p className="mt-5 max-w-2xl text-lg text-ink-200">{post.excerpt}</p> : null}
              <div className="mt-6">
                <ShareButtons url={url} title={post.title} />
              </div>
            </div>
            {hero ? (
              <div className="chamfer-frame">
                <div className="chamfer overflow-hidden bg-ink-900">
                  <Image src={hero.src} alt={hero.alt} width={hero.width} height={hero.height} priority sizes="(min-width: 1024px) 45vw, 100vw" className="aspect-[16/10] h-full w-full object-cover" />
                </div>
              </div>
            ) : null}
          </div>
        </header>

        <div className="container grid gap-12 py-12 lg:grid-cols-[minmax(0,1fr)_18rem] lg:py-16">
          <div className="min-w-0">
            <Markdown content={post.body} className="prose-vga max-w-3xl" />

            {galleryImages.length ? (
              <section className="mt-12" aria-labelledby="post-gallery">
                <h2 id="post-gallery" className="font-display text-3xl font-bold uppercase text-ink-50">
                  Photos
                </h2>
                <p className="mt-2 text-ink-300">
                  {galleryImages.length} photos{album ? <> · <Link href={`/gallery/${album.slug}`} className="text-gold-200 underline underline-offset-4 hover:text-gold-100">view in the gallery</Link></> : null}
                </p>
                <div className="mt-6">
                  <PhotoGrid images={galleryImages} columns={3} />
                </div>
              </section>
            ) : null}

            <footer className="mt-12 flex flex-wrap items-center justify-between gap-4 border-t border-ink-700 pt-6">
              <ShareButtons url={url} title={post.title} />
              <Button href={catHref} variant="ghost" icon="arrow-right">
                More {catLabel.toLowerCase()}
              </Button>
            </footer>
          </div>

          <aside className="space-y-6 lg:sticky lg:top-[calc(var(--header-h)+1.5rem)] lg:self-start">
            {post.attachments?.length ? (
              <div className="card p-5">
                <h2 className="font-display text-lg font-bold uppercase text-ink-50">Attachments</h2>
                <ul className="mt-3 space-y-2">
                  {post.attachments.map((a) => (
                    <li key={a.href}>
                      <a href={a.href} target="_blank" rel="noopener noreferrer" className="group flex items-start gap-3 text-sm text-gold-200 hover:text-gold-100">
                        <Icon name="download" className="mt-0.5 h-4 w-4 shrink-0" />
                        <span className="underline-offset-4 group-hover:underline">{a.label}</span>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
            <div className="card p-5">
              <h2 className="font-display text-lg font-bold uppercase text-ink-50">Published by</h2>
              <div className="mt-3 flex items-center gap-3">
                <Image src={images["brand/vga-logo-mark"].src} alt="" width={40} height={42} className="h-10 w-auto" />
                <div>
                  <p className="font-semibold text-ink-50">{site.name}</p>
                  <p className="text-xs text-ink-400">{site.charityStatement}</p>
                </div>
              </div>
            </div>
            <div className="card p-5">
              <h2 className="font-display text-lg font-bold uppercase text-ink-50">Get involved</h2>
              <div className="mt-3 flex flex-col gap-2">
                <Button href="/become-a-member" size="sm" icon="arrow-right">
                  Become a member
                </Button>
                <Button href="/donate" size="sm" variant="secondary">
                  Donate
                </Button>
                <Button href={site.socials.discord} size="sm" variant="discord" icon="discord" iconPosition="left">
                  Join Discord
                </Button>
              </div>
            </div>
          </aside>
        </div>
      </article>

      {related.length ? (
        <section className="border-t border-ink-700/60 bg-ink-850" aria-labelledby="related">
          <div className="container py-16">
            <h2 id="related" className="text-display-sm uppercase text-ink-50">
              More from VGA
            </h2>
            <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((p) => (
                <li key={p.slug}>
                  <NewsCard post={p} />
                </li>
              ))}
            </ul>
          </div>
        </section>
      ) : null}
      <CtaBand eyebrow="Support the mission" title="Help keep Veterans connected." body="Every donation funds free programs that reduce social isolation for Veterans and families." ctas={[{ label: "Donate", href: "/donate", icon: "heart" }, { label: "Become a sponsor", href: "/become-a-sponsor", variant: "secondary" }]} />
    </>
  );
}
