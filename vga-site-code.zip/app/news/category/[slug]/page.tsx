import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { allPosts, categories, postsByCategory, type CategorySlug } from "@/lib/content";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { NewsCard } from "@/components/community/NewsCard";
import { CategoryTabs } from "@/components/community/CategoryTabs";
import { CtaBand } from "@/components/ui/CtaBand";
import { site } from "@/data/site";

type Params = { slug: string };
const slugs: string[] = categories.filter((c) => c.slug !== "galleries").map((c) => c.slug);

export function generateStaticParams(): Params[] {
  return slugs.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const cat = categories.find((c) => c.slug === slug);
  if (!cat || !slugs.includes(cat.slug)) return {};
  return buildMetadata({
    title: `${cat.label} — News`,
    description: cat.slug === "newsletter" ? "Veteran Gaming Australia newsletters — activities, events, advocacy and community updates." : "Veteran Gaming Australia news and announcements.",
    path: `/news/category/${cat.slug}`,
    image: images["news/celebrating-5-years-of-impact"].src,
  });
}

export default async function CategoryPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const cat = categories.find((c) => c.slug === slug);
  if (!cat || !slugs.includes(cat.slug)) notFound();
  const posts = postsByCategory(cat.slug as CategorySlug);
  const all = allPosts();
  const counts: Record<string, number> = { all: all.length };
  for (const c of categories) counts[c.slug] = all.filter((p) => p.category === c.match).length;
  return (
    <>
      <PageHero eyebrow="News" title={cat.label} lead={cat.slug === "newsletter" ? "Activities, events, advocacy and community updates from the VGA newsletter." : "Announcements, stories and advocacy from Veteran Gaming Australia."} crumbs={[{ name: "News", path: "/news" }, { name: cat.label, path: `/news/category/${cat.slug}` }]} compact />
      <Section labelledBy="list-title">
        <h2 id="list-title" className="sr-only">
          {cat.label}
        </h2>
        <CategoryTabs active={cat.slug as CategorySlug} counts={counts} />
        {posts.length ? (
          <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {posts.map((p) => (
              <li key={p.slug}>
                <NewsCard post={p} />
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-8 text-ink-200">Nothing published in this category yet.</p>
        )}
      </Section>
      <CtaBand eyebrow="Stay in the loop" title="Join the community." body="Members hear about events first — on Discord and in the newsletter." ctas={[{ label: "Become a member", href: "/become-a-member", icon: "arrow-right" }, { label: "Join Discord", href: site.socials.discord, variant: "discord", icon: "discord" }]} />
    </>
  );
}
