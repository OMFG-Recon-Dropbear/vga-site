import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { allPosts, categories } from "@/lib/content";
import { images, type ImageKey } from "@/data/generated/images";
import { site } from "@/data/site";
import { buildMetadata } from "@/lib/seo";
import { formatDate } from "@/lib/utils";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Tag } from "@/components/ui/Tag";
import { Icon } from "@/components/ui/Icon";
import { NewsCard } from "@/components/community/NewsCard";
import { CategoryTabs } from "@/components/community/CategoryTabs";
import { NewsletterForm } from "@/components/forms/NewsletterForm";
import { guides } from "@/data/education";

export const metadata: Metadata = buildMetadata({
  title: "News & Advocacy",
  description: "Keep up to date with Veteran Gaming Australia news and articles — announcements, newsletters, advocacy submissions on behalf of Veterans and families, and photo galleries.",
  path: "/news",
  image: images["news/celebrating-5-years-of-impact"].src,
});

export default function NewsPage() {
  const posts = allPosts();
  const counts: Record<string, number> = { all: posts.length };
  for (const c of categories) counts[c.slug] = posts.filter((p) => p.category === c.match).length;
  const [featured, ...rest] = posts.filter((p) => p.category !== "Galleries");
  const hero = featured.hero ? images[featured.hero as ImageKey] : null;
  const advocacy = posts.filter((p) => /dva|submission|clarification/i.test(p.slug));
  return (
    <>
      <PageHero eyebrow="Community" title={<>News &amp; <span className="gold-text">advocacy</span></>} lead="Announcements, newsletters, submissions on behalf of Veterans and families, and photos from the community." crumbs={[{ name: "News", path: "/news" }]} compact>
        <Button href="#latest" icon="arrow-right">
          Latest news
        </Button>
        <Button href="/gallery" variant="secondary" icon="arrow-right">
          Photo gallery
        </Button>
      </PageHero>

      <Section labelledBy="featured-title" innerClassName="pb-0 sm:pb-0 lg:pb-0">
        <Link href={`/news/${featured.slug}`} className="card card-hover group grid overflow-hidden lg:grid-cols-[1.3fr_1fr]">
          <div className="relative aspect-[16/9] overflow-hidden bg-ink-800 lg:aspect-auto lg:min-h-[24rem]">
            {hero ? <Image src={hero.src} alt={hero.alt} width={hero.width} height={hero.height} priority sizes="(min-width: 1024px) 60vw, 100vw" className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.03]" /> : null}
            <div className="absolute left-4 top-4">
              <Tag>{featured.category}</Tag>
            </div>
          </div>
          <div className="flex flex-col justify-center p-6 sm:p-10">
            <p className="eyebrow mb-3">Latest</p>
            <h2 id="featured-title" className="font-display text-3xl font-bold uppercase leading-none text-ink-50 transition group-hover:text-gold-200 sm:text-4xl">
              {featured.title}
            </h2>
            <p className="mt-3 text-sm text-ink-300">
              <time dateTime={featured.date}>{formatDate(featured.date, { month: "long" })}</time> · {featured.readingTime} min read
            </p>
            <p className="mt-4 text-lg text-ink-200 line-clamp-4">{featured.excerpt}</p>
            <span className="mt-6 inline-flex items-center gap-2 font-display text-base font-semibold uppercase tracking-[0.1em] text-gold-300">
              Read the story <Icon name="arrow-right" className="h-4 w-4 transition group-hover:translate-x-1" />
            </span>
          </div>
        </Link>
      </Section>

      <Section id="latest" labelledBy="latest-title">
        <SectionHeader id="latest-title" eyebrow="All posts" title="Latest from VGA" />
        <CategoryTabs active="all" counts={counts} />
        <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {rest.map((p) => (
            <li key={p.slug}>
              <NewsCard post={p} />
            </li>
          ))}
        </ul>
      </Section>

      {advocacy.length ? (
        <Section tone="raised" labelledBy="advocacy">
          <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr]">
            <div>
              <p className="eyebrow mb-4">Advocacy</p>
              <h2 id="advocacy" className="text-display-md uppercase text-ink-50">
                Speaking up for Veterans and families
              </h2>
              <p className="mt-4 text-lg text-ink-200">VGA’s public statements and submissions to the Department of Veterans’ Affairs, published in full with the original documents attached.</p>
            </div>
            <ul className="divide-y divide-ink-700 border-y border-ink-700">
              {advocacy.map((p) => (
                <li key={p.slug}>
                  <Link href={`/news/${p.slug}`} className="group flex items-start gap-4 py-4">
                    <Icon name="shield" className="mt-1 h-5 w-5 shrink-0 text-gold-500" />
                    <span className="min-w-0 flex-1">
                      <span className="block font-display text-xl font-bold uppercase leading-tight text-ink-50 transition group-hover:text-gold-200">{p.title}</span>
                      <span className="mt-1 block text-sm text-ink-300">
                        {formatDate(p.date, { month: "long" })}
                        {p.attachments?.length ? ` · ${p.attachments.length} attachment${p.attachments.length > 1 ? "s" : ""}` : ""}
                      </span>
                    </span>
                    <Icon name="arrow-right" className="mt-1 h-5 w-5 shrink-0 text-ink-500 transition group-hover:translate-x-1 group-hover:text-gold-200" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </Section>
      ) : null}

      <Section labelledBy="education-title">
        <SectionHeader id="education-title" eyebrow="Education" title="Guides for healthy, safe gaming" action={<Button href="/education" variant="secondary" icon="arrow-right">All guides</Button>} />
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {guides.map((g) => {
            const img = images[g.image];
            return (
              <li key={g.slug}>
                <Link href={`/education/${g.slug}`} className="card card-hover group block h-full overflow-hidden">
                  <div className="aspect-[16/10] overflow-hidden bg-ink-800">
                    <Image src={img.src} alt={img.alt} width={img.width} height={img.height} sizes="(min-width: 1024px) 20vw, 50vw" className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
                  </div>
                  <div className="p-4">
                    <p className="font-display text-xl font-bold uppercase leading-none text-ink-50 transition group-hover:text-gold-200">{g.title}</p>
                    <p className="mt-2 text-sm text-ink-300">{g.subtitle}</p>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </Section>

      <section className="container pb-16 sm:pb-20" aria-labelledby="subscribe-title">
        <div className="chamfer-frame">
          <div className="chamfer grid gap-8 bg-ink-950 px-6 py-10 sm:px-12 lg:grid-cols-[1.2fr_1fr] lg:items-center">
            <div>
              <p className="eyebrow mb-3">Newsletter</p>
              <h2 id="subscribe-title" className="text-display-md uppercase text-ink-50">
                Get the VGA newsletter
              </h2>
              <p className="mt-3 text-ink-200">Activities, events, advocacy and community updates — straight to your inbox.</p>
            </div>
            <NewsletterForm />
          </div>
        </div>
      </section>

      <CtaBand
        eyebrow="Follow along"
        title="Every day, on socials."
        body="Day-to-day updates, event listings and streams live on VGA’s Facebook, Instagram, YouTube, Twitch and Discord."
        ctas={[
          { label: "Facebook", href: site.socials.facebook, icon: "external" },
          { label: "Join Discord", href: site.socials.discord, variant: "discord", icon: "discord" },
        ]}
      />
    </>
  );
}
