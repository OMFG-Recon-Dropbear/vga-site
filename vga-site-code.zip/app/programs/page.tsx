import type { Metadata } from "next";
import Image from "next/image";
import { programs, programCategories } from "@/data/programs";
import { site } from "@/data/site";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/ui/PageHero";
import { Section } from "@/components/ui/Section";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { ProgramCard } from "@/components/programs/ProgramCard";
import { ProgramDetail } from "@/components/programs/ProgramDetail";
import { Button } from "@/components/ui/Button";
import { CtaBand } from "@/components/ui/CtaBand";
import { Reveal } from "@/components/ui/Reveal";

export const metadata: Metadata = buildMetadata({
  title: "Programs",
  description: "Everything Veteran Gaming Australia runs for Veterans and families: gaming and esports hubs, the Oceania Veteran Esports League, 24/7 game servers and digital socials, community events, care packages, the hospital loan program, Air Assault and creative programs — all free for members.",
  path: "/programs",
  image: images["programs/esports-arena"].src,
});

export default function ProgramsPage() {
  const inline = programs.filter((p) => ["tournaments", "creative-programs", "events"].includes(p.slug));
  return (
    <>
      <PageHero
        eyebrow="Programs"
        title={
          <>
            Free programs. Online and in person. <span className="gold-text">For Veterans and families.</span>
          </>
        }
        lead="Every program below is free for registered VGA members — from a game night on Discord tonight to a gaming hub on a Defence base near you."
        image="programs/esports-arena"
        imagePosition="center"
        crumbs={[{ name: "Programs", path: "/programs" }]}
      >
        <Button href="/become-a-member" icon="arrow-right">
          Join VGA — it’s free
        </Button>
        <Button href={site.socials.discord} variant="discord" icon="discord" iconPosition="left">
          Join Discord
        </Button>
      </PageHero>

      <Section labelledBy="all-programs">
        <SectionHeader id="all-programs" eyebrow="What VGA offers" title="Choose your way in" lead={`${programs.length} programs across ${programCategories.length} areas — online, in person, and in between.`} />
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {programs.map((p, i) => (
            <Reveal as="li" key={p.slug} delay={i * 40}>
              <ProgramCard program={p} />
            </Reveal>
          ))}
        </ul>
      </Section>

      <Section tone="raised" labelledBy="details">
        <SectionHeader id="details" eyebrow="In detail" title="Events, tournaments and creative programs" />
        <div className="space-y-16">
          {inline.map((p) => (
            <ProgramDetail key={p.slug} program={p} anchor />
          ))}
        </div>
      </Section>

      <Section labelledBy="hubs-cta">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div className="overflow-hidden rounded-lg border border-ink-700">
            <Image src={images["hubs/riverina-hub-setup-1"].src} alt={images["hubs/riverina-hub-setup-1"].alt} width={images["hubs/riverina-hub-setup-1"].width} height={images["hubs/riverina-hub-setup-1"].height} sizes="(min-width: 1024px) 50vw, 100vw" className="h-full w-full object-cover" />
          </div>
          <div>
            <p className="eyebrow mb-4">Retrofit</p>
            <h2 id="hubs-cta" className="text-display-md uppercase text-ink-50">
              Gaming hubs where Veterans already are
            </h2>
            <p className="mt-5 text-lg text-ink-200">
              VGA is facilitating and setting up social gaming hubs and esports hubs, information & resources to Veteran Hospitals and Veteran Support Organisations in enhancing social connections, health and wellbeing. Nineteen hubs are on the map today, on Defence bases, in Veteran and Family wellbeing centres, RSLs and hospitals.
            </p>
            <Button href="/gaming-hubs" icon="map-pin" iconPosition="left" className="mt-6">
              Find a hub near you
            </Button>
          </div>
        </div>
      </Section>

      <CtaBand
        eyebrow="Ready to jump in?"
        title="Membership is free."
        body="Current and ex-serving ADF and NZDF members and their immediate family (18+) can join. One of the team will be in touch to get you connected."
        ctas={[
          { label: "Become a member", href: "/become-a-member", icon: "arrow-right" },
          { label: "Ask a question", href: "/contact", variant: "secondary" },
        ]}
      />
    </>
  );
}
