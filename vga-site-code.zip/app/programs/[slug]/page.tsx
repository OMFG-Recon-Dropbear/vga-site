import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { programs } from "@/data/programs";
import { images } from "@/data/generated/images";
import { buildMetadata } from "@/lib/seo";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { ProgramDetail } from "@/components/programs/ProgramDetail";
import { ProgramCard } from "@/components/programs/ProgramCard";
import { CtaBand } from "@/components/ui/CtaBand";
import { GameServersSection } from "@/components/programs/GameServersSection";
import { CarePackageStories } from "@/components/programs/CarePackageStories";

type Params = { slug: string };
const detailSlugs = ["game-servers", "care-packages", "hospital-loan-program", "air-assault"];

export function generateStaticParams(): Params[] {
  return detailSlugs.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const p = programs.find((x) => x.slug === slug);
  if (!p || !detailSlugs.includes(slug)) return {};
  return buildMetadata({ title: p.title, description: p.short, path: `/programs/${p.slug}`, image: images[p.image].src });
}

export default async function ProgramPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  const p = programs.find((x) => x.slug === slug);
  if (!p || !detailSlugs.includes(slug)) notFound();
  const related = programs.filter((x) => x.slug !== p.slug && x.category === p.category).slice(0, 3);
  const others = related.length ? related : programs.filter((x) => x.slug !== p.slug).slice(0, 3);
  return (
    <>
      <div className="container pt-10 sm:pt-12">
        <Breadcrumbs items={[{ name: "Programs", path: "/programs" }, { name: p.title, path: `/programs/${p.slug}` }]} />
      </div>
      <section className="container py-10 sm:py-14">
        <ProgramDetail program={p} headingLevel={1} />
      </section>
      {slug === "game-servers" ? <GameServersSection /> : null}
      {slug === "care-packages" ? <CarePackageStories /> : null}
      <section className="container py-12" aria-labelledby="more-programs">
        <h2 id="more-programs" className="font-display text-2xl font-bold uppercase text-ink-50">
          More programs
        </h2>
        <ul className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {others.map((o) => (
            <li key={o.slug}>
              <ProgramCard program={o} />
            </li>
          ))}
        </ul>
      </section>
      <CtaBand eyebrow="Get involved" title="Join VGA — it’s free." body="Current and ex-serving ADF and NZDF members and their immediate family (18+)." ctas={[{ label: "Become a member", href: "/become-a-member", icon: "arrow-right" }, { label: "Contact us", href: "/contact", variant: "secondary" }]} />
    </>
  );
}
